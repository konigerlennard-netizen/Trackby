# Was in 4REPS 1.26.0 steckt

Stand: 30.10.2026. Weiterentwicklung des vorhandenen Quellcodes 1.25.0.

## Neu in 1.26.0

Fortschrittsfilter aufklappen und gemeinsam zurücksetzen, Einzelwerte und gleiche Leistungswerte besser ablesen, neue Pläne vor dem Speichern anpassen und Körpergewichtskorrekturen oder Löschungen zehn Sekunden lang zurücknehmen. Die optionale Gewichtsnotiz ist eingeklappt; reine Notizänderungen erhalten exakte Messwerte und Zeitpunkte. Doppelte Änderungsanzeigen und unpassende 1RM-Karten entfallen. [Kurzanleitung](FORTSCHRITT-BEARBEITEN.md).

## Seit 1.25.0

Pläne suchen, sortieren und archivieren; einzelne Pläne als eigene Datei exportieren/importieren; eine vorherige Planfassung wiederherstellen; ganze abgeschlossene Workouts bearbeiten und Korrekturen/Löschungen zurücknehmen; eigene Übungen direkt beim Hinzufügen erstellen. Plan- und Verlauf-Editoren zeigen zusätzliche Angaben erst nach dem Aufklappen. [Kurzanleitung](PLAENE-UND-VERLAUF.md).

## Seit 1.24.0

Eigene Übungen lassen sich nachträglich bearbeiten. Der gemeinsame Editor für Anlegen, Bearbeiten und Gerätevarianten zeigt zuerst vier Grundangaben. Weitere Muskelgruppen, Ausführungshinweise und Suchnamen bleiben aufklappbar. Eigene Gerätenamen werden in Suche und Filter übernommen. Satzwerte bleiben erhalten; bestehende Verknüpfungen nutzen weiterhin dieselbe Übungs-ID. Änderungen an Namen und Muskelzuordnung gelten auch rückwirkend für die Anzeige/Auswertung. Die Messart bereits verwendeter Übungen bleibt fest. [Kurzanleitung](EIGENE-UEBUNGEN.md).

## Bereits seit 1.23.0 umgesetzt

| Bereich | Änderung |
| --- | --- |
| Training unterbrechen | Trainingszeit und laufende Satzpause anhalten und bewusst fortsetzen. Der Zustand übersteht das Schließen der App. Unterbrechungen zählen nicht zur Trainingsdauer; gewöhnliche Satzpausen weiterhin schon. |
| Workout aufräumen | Timer und Unterbrechen direkt sichtbar. Layout, Einzelansicht und Check-in unter „Ansicht & Check-in“. Verwerfen oben, genau ein Abschlussknopf unten. |
| Trainingsabschluss | Kompakte Zusammenfassung mit Trainingszeit, abgeschlossenen Sätzen und tatsächlich trainierten Übungen. Im gespeicherten Verlauf auch vorhandene Bestwerte. Übungen und Sätze sind dort aufklappbar. |
| Verlauf | Suche nach Training, Übung, englischem Namen, Alias und Notizen; Filter für Zeitraum, Übung und Plan. Auch gelöschte Pläne bleiben auffindbar. Zunächst 30 Einheiten, weitere auf Wunsch. |
| Layoutwahl | Startseite und Workout direkt in der Auswahl umschaltbar. Kleine Bilder berücksichtigen Kartenbreiten. Alte Plus/Minus-Bedienung verschwindet auch aus diesen Bildern. Unveränderte Entwürfe haben keinen aktiven Speicherknopf. |
| Backups | Einheitliche Dateinamen mit lokalem Datum, beispielsweise 4REPS-Backup-29-10-2026.json. Demo-, Cloud- und lokale Stände sind gekennzeichnet. |
| Weniger Text | Kürzere leere Ansichten. Selten benötigte Details bleiben erreichbar, ohne den Trainingseinstieg zu überladen. |

## Bereits vorhanden und weiterverwendet

| Vorschlag | Bestehender Stand |
| --- | --- |
| Training wieder aufnehmen | Laufendes Workout wird lokal gespeichert; Zugang über Workout und Fortsetzen. |
| Weniger Satzeingaben | Abweichende Werte vom vorherigen Satz oder letzten Training übernehmen; automatischer Wechsel zum nächsten offenen Satz abschaltbar. |
| Eigene Reihenfolge | Übungen über das Menü und per Ziehen verschieben; Karten und Workout-Bereiche im Layout mit Pfeilen. |
| Notizen und Vergleich | Übungs-, Satz- und Trainingsnotizen sowie Vergleich zur vorherigen Einheit. |
| Persönliche Übungsbibliothek | Favoriten, eigene Übungen/Varianten und Verlauf je Übung. Seit 1.24.0 mit nachträglichem Editor für eigene Übungsangaben. |
| Trainingspläne | Pläne kopieren, aus letzter Einheit oder Grundvorlage beginnen, Startplan festlegen. |
| Satzarten und Korrektur | Aufwärm-, Arbeits-, Back-off- und Drop-Sätze; einzelne abgeschlossene Sätze im Verlauf korrigieren. Seit 1.25.0 zusätzlich vollständiger Editor und Rückgängig. |
| Fortschritt | Gewichtsverlauf, übungsbezogene Entwicklungen, Bestwerte und aufklappbarer Wochenvergleich. |
| Kalender | Interner Wochenplan und freie Tage. Keine Verbindung zum Geräte- oder Google-Kalender. |
| Eingabeschutz | Wertevalidierung, Bestätigung auffälliger Satzwerte und Warnung vor dem Ersetzen einer Übung. |
| Speicherung | Lokale Speicherung, Statusanzeige, Offline-Ausgabe, JSON-Backups, lokale Rückfallsicherungen und gezieltes Rückgängig. |
| Bedienung | Größere Schrift, Kontrast und reduzierte Bewegung; Gewicht bleibt in einer Zeile. |
| Pause und Layout | Dauerhaft gespeicherte drei Minuten als Standard; Einfach, Standard, Detailliert und eigener individueller Platz mit Bildbeispielen. |

## Bewusst nicht zusätzlich eingebaut

| Vorschlag | Entscheidung |
| --- | --- |
| Automatisch umsortierte Startseite | Würde das selbst gewählte Layout verändern. Die bestehende manuelle Anordnung bleibt maßgeblich. |
| Weitere Rest-/Satz-Zähler und Tab-Hinweise | Bestehende Anzeigen reichen; zusätzliche doppelte Anzeigen würden die Oberfläche wieder füllen. |
| Face ID und Sperrbildschirm-Widget | Nicht implementiert. Dafür wird kein funktionsloser Schalter angezeigt. |
| Garantierter Alarm im Stummmodus oder Sperrbildschirm | Nicht verfügbar. Vorhandene optionale Töne und Browser-Vibration hängen vom Gerät ab. |
| Automatisches Zusammenführen von Training | Konflikte bleiben eine bewusste Auswahl zwischen Datenständen; keine unbemerkte Zusammenführung. |
| Ziele, externe Kalender und mehrere Personenprofile | Zusätzlicher Funktionsumfang, der den jetzigen Trainingseinstieg nicht vereinfacht. |
| Automatischer Supersatz-Ablauf | Bestehende Supersatzkennzeichnungen bleiben; keine neue automatische Reihenfolge. |

## Datenerhalt und Grenzen

Die neue Zeitangabe ist optional. Datenbank- und Backupversion bleiben unverändert, bisherige Einheiten behalten ihre Dauer. Ein gesonderter lokaler Speicherwert schützt die Unterbrechung vor älteren offenen App-Tabs. Trägt ein älterer Tab währenddessen neue Satzaktivität ein, endet die Unterbrechung am ersten bekannten Aktivitätszeitpunkt. Ein unbekannter tatsächlicher Wiederbeginn lässt sich nicht rückwirkend ermitteln.

App-Wechsel, Bildschirmabschalten und normale Satzpausen lösen keine automatische Trainingsunterbrechung aus. Nur die bewusste Taste tut dies. Beim Import/Reset werden entfernte Einheiten nicht wiederhergestellt; „Letzten Import rückgängig machen“ bringt den vorherigen Stand zurück.

Automatisierte Ergebnisse stehen in TESTING.md und RELEASE_VALIDATION.json. Kein interaktiver Browser- oder realer iPhone-/Android-Test dieser Version. Die ZIP-Dateien sind nicht veröffentlicht.
