# Coachingregeln 1.0.0

Literatur geprüft: 22.–23.09.2026. Ausführung: `features/forma/coach.ts`. Jede Ausgabe enthält `rule`, `title`, `why`, `detail`, `confidence`, `tone`, `sources` und optional `weight` (kg). Sie verändert niemals selbst einen Trainingsplan oder einen Satz.

## Reihenfolge der Regeln

Die erste zutreffende Regel gewinnt. Aktueller Check-in geht vor einem maximal sieben Tage alten Check-in. Übungsspezifische Schmerzen werden ebenfalls berücksichtigt. Freitext wird **nicht** medizinisch oder per KI interpretiert; Beschwerden deshalb zusätzlich mit dem entsprechenden Schalter markieren.

| Regel | Bedingungen | Verhalten / Beispiel | Grundlage |
|---|---|---|---|
| safety | Aktuelle Schmerzen oder jüngster relevanter Schmerzeintrag | Schmerzhafte Bewegung beenden, keine Steigerung; starke/anhaltende Beschwerden abklären | E18/E19; Vorsichtsregel, keine Diagnose |
| illness | Krankheit/Wiedereinstieg angekreuzt | Keine automatische Steigerung oder Trainingsfreigabe | E19 |
| readiness | Mindestens zwei: Schlaf/Energie ≤2, Muskelkater/Stress ≥4 | Heute nichts steigern; Reduzieren oder Pausieren ist eine Option | E14/E17; Schwellen nicht validiert |
| return | Übung mehr als 14 Tage nicht abgeschlossen | Ruhig wieder einsteigen, keine konkrete Lastvorgabe | E01/E19; 14 Tage sind Heuristik |
| baseline | Kein abgeschlossener Verlauf | Ausgangspunkt mit kontrollierbarer Belastung erfassen | E02/E18 |
| context | Geänderte Zielvorgaben/Technik/Reihenfolge | Vergleichbare Einheiten sammeln | E01/E08/E12 |
| effort | Ein Arbeitssatz unter Mindestwiederholungen oder RIR 0 | Last zunächst halten, bei Bedarf leichter | E02/E05 |
| rest | Gleiche Last, mindestens zwei Sätze, ≥25 % Wiederholungsabfall, bekannte mittlere Folgepausen <120 s, kein Supersatz | 30–60 s mehr Pause prüfen, andere Ursachen offenlassen | E06; konkrete Schwellen Heuristik |
| double | Letzte 2 vergleichbaren Einheiten (bei Anfänger-Einstellung 3) erfüllen alle Ziele, siehe unten | Kleine optionale Gewichtssteigerung | E03/E14; keine direkt validierte App-Regel |
| step | Bedingungen für double, verfügbarer Schritt >5 % | Kleinere Schritte abwarten, Leistung beibehalten | Konservative Produktgrenze |
| plateau | 4 vergleichbare Einheiten über ≥14 Tage; gleiche Last, passende Satzanzahl, Gesamtwdh. unterscheiden sich höchstens um 1, keine Verbesserung der mittleren RIR um ≥1 | Stabile Leistung, Kontext prüfen; kein bewiesenes Plateau | E14/E15/E06; Heuristik |
| data | Weniger als 2 vergleichbare abgeschlossene Einheiten | Weitere Daten sammeln | Unsicherheit offen zeigen |
| missing | Mindestens ein Arbeitssatz ohne RIR/RPE | Heute nichts ändern, keine konkrete Laststeigerung | E14 |
| repeat | Sonst | Wiederholungen, Reserve und Kontrolle stabilisieren | E03/E05 |

## Vergleichbarkeit

Nur abgeschlossene Workouts und abgeschlossene Sätze vom Typ `work` zählen. Aufwärm-, Back-off- und Drop-Sets sind in Historie und Belastungsübersichten sichtbar, gehen aber nicht in diese Progressionsregel ein. Verglichen wird die **ununterbrochene jüngste Folge** derselben Übung bei identischer Ziel-Satzanzahl, Min/Max-Wiederholungen, Ziel-RIR, vorgesehener Pause, Supersatz-Gruppe, Technik-/Gerätenotiz, Position im Workout sowie Tempo-/ROM-Notizen der Arbeitssätze. Fehlende Notizen beweisen keine identische Technik. Bei neuen Workouts werden frühere Tempo-/ROM-Werte übernommen, Reserve jedoch neu erfasst.

Double Progression verlangt in jeder Vergleichseinheit exakt die Zielzahl an Arbeitssätzen, alle bei derselben positiven externen Last, alle mindestens am oberen Range-Ende und mit `RIR >= max(1, Ziel-RIR)`. Keine Schmerzen oder Krankheit in diesen Einheiten. RPE wird nur bei fehlendem RIR näherungsweise als `10 − RPE` übersetzt. Körpergewicht, Assistenz und Zeitübungen erhalten keine numerische Gewichtserhöhung.

Vorschlag: aktuelles Gewicht plus eingestellter kleinster Schritt; höchstens 5 % Zuwachs. Bei mindestens drei früheren Lastanstiegen mit weiterhin erreichten Mindestwiederholungen und Reserve begrenzt zusätzlich der Median dieser erfolgreichen Schritte den Vorschlag. Das ist eine kleine historische Anpassung, **kein trainiertes statistisches Modell** und kein Nachweis einer kausalen individuellen Reaktion. Lernende optimale Volumina und individuelle Ermüdungsmodelle sind noch nicht umgesetzt.

Beispiel 3×6–10: `80×10 / 80×10 / 80×9` → wiederholen/stabilisieren. Zwei vergleichbare abgeschlossene Einheiten mit `80×10 / 80×10 / 80×10`, jeweils RIR 2, Ziel-RIR 2, Einstellung „regelmäßig“, Schritt 2,5 kg → freiwillige Option 82,5 kg. Bei Schmerzen, Krankheit, ungünstigem Check-in oder geänderter Technik hat eine frühere Regel Vorrang.

## Datengrundlage

0–1 vergleichbare Einheiten: „Noch wenig Daten“. 2–5: „Mittlere Datengrundlage“. Ab 6: „Hohe Datengrundlage“. Frühe Schutzregeln geben bewusst keine hohe persönliche Sicherheit aus. Diese Stufe zählt Beobachtungen, sie ist **keine Wahrscheinlichkeit**, keine medizinische Sicherheit und kein Qualitätsnachweis der RIR-Schätzung.

## Plateau und Trainingsbelastung

Eine stagnierende Zahl kann Erhaltung, bessere Technik oder mehr Reserve bedeuten. Deshalb zuerst Pausen, Technik, Reihenfolge, Tagesform und andere Sportbelastungen prüfen. Mehr Sätze, mehr Trainingstage, Deload oder Übungswechsel werden niemals automatisch ausgelöst. Für Fußball oder andere Sportarten gibt es in v1 kein vollständiges Belastungsmodell; die Person muss diesen Kontext selbst berücksichtigen.

## Rekorde und Schätzwerte

PRs werden deterministisch aus dem Verlauf berechnet: höchste externe Last, Wiederholungen bei gleicher Last, Epley-Schätzung und Arbeitssatz-Lastvolumen. Mindestens eine frühere Vergleichseinheit ist erforderlich. Neue Geräte-/Techniknotizen begrenzen Vergleiche; Tempo und ROM sind keine vollständig normierten Messgrößen. Erste Einträge heißen nicht automatisch Rekord. Gespeichert sind die zugrunde liegenden Sätze, PRs werden daraus neu abgeleitet.

Epley: `kg × (1 + reps/30)`, nur freigegebene externe Übungen, 2–10 Wiederholungen, erledigter Arbeitssatz. Angegebene Reserve >3 schließt den Wert aus. Bei fehlender Reserve bleibt die Schätzung besonders unsicher; keine Reservekorrektur und keine Aufforderung zum 1RM-Test. PRs sind deskriptive Informationen, keine Trainingspflicht.

## Versionswechsel

Regeländerung → EVIDENCE aktualisieren → Tests anpassen → Versionsnummer erhöhen → CHANGELOG erklären → Nutzer über App-Aktualisierung informieren. Jeder gespeicherte Workout-Datensatz trägt die bei seiner Erstellung geltende Regelversion. Historische Empfehlungen werden nicht als damalige Originalentscheidung ausgegeben.
