## 4REPS · kompakte Widgets und eigener Hintergrund · 1.7.0

Auf Heute steht der Fortschritt zuerst. Auf iPhone folgen Kalender und Pläne darunter; ab 1100 px stehen Fortschritt und Kalender in zwei Spalten. Kein zusätzlicher Fortschrittsbutton in der Überschrift. Diagramm und Körpergewicht bleiben direkt antippbar. Karten sind flacher und kompakter, Eingaben und Aktionen behalten erreichbare Touchflächen. Die ausführliche Kraftübersicht zeigt fünf Einträge pro Schritt mit kleinen eigenen Gerätesymbolen; unter 360 px entfallen diese zugunsten lesbarer Zahlen.

Hintergrundwahl: Ohne, YOU VS YOU, Eigenes Bild. Das statische Foto füllt den Hintergrund proportional und mittig zugeschnitten. Eine feste dunkle beziehungsweise helle Ebene hält Texte lesbar; keine neue Blur- oder Scrollanimation. Unter reduzierter Transparenz und Forced Colors wird der App-Hintergrund ausgeblendet. Die Einstellung erklärt den lokalen Speicher und die Ausnahme bei Backups.

Das selbst erstellte Icon verwendet eine große 4, vier dezente mintfarbene Balken und REPS. PNGs sind deckend; die Maskable-Fassung setzt die Marke innerhalb des sicheren Innenbereichs. iOS-Icon und Manifest-Icons bekommen neue Dateipfade, die Installationsidentität bleibt erhalten.

## Absolute Änderung und Prozent 1.6.3 · 13.10.2026

Die wiederverwendbare Anzeige ChangeValue setzt den absoluten Wert (kg/lb oder Wdh.) an erste Stelle; die kleinere Prozentzahl steht direkt darunter. Beide folgen derselben anpassbaren Plus-/Minusfarbe. Die neutrale Beschriftung erklärt beim Übungsfortschritt die Kennzahl, auch in kompakten Listen. Beispielwerte in Dein Look verwenden dieselbe Komponente. Keine neue Animation, kein eigener Scrollbereich und keine neuen Eingaben.

## Gewichtsdetails und Änderungsfarben 1.6.2 · 12.10.2026

Die Gewichtskarte bietet zwei native Buttons: den aktuellen Messwert und die Diagrammvorschau. Beide öffnen dieselbe Detailseite innerhalb Mein Fortschritt. Keine neue Navigationsebene in der Bottom Bar, kein horizontaler Scrollbereich. Die große Grafik bleibt interaktiv; Messdaten sind zusätzlich als zugängliche Liste verfügbar. 20 Zeilen pro Nachladeschritt begrenzen den DOM-Umfang.

Plus und Minus werden anhand der angezeigten, gerundeten Änderung eingefärbt, nicht anhand einer Bewertung des Körpers. Standard: Grün/Rot, anpassbar unter Farben für Plus & Minus. Vorzeichen und Text bleiben als zusätzliche Kennzeichnung erhalten. Fehlende Daten und gerundete Nullwerte bleiben neutral; die Einordnung stabil/schwankend usw. ändert sich durch die Farbe nicht. Haupt- und Diagrammakzent sind unabhängig.

Mehr zeigt Einstellungen, Sicherung und Updates. Datenschutz und wissenschaftliche Hintergründe öffnen sich erst über Über Forma; Demo-Einstieg und Installationsanleitung entfallen. Bereits aktive Demo-Sitzungen können weiterhin über das Banner verlassen werden, ohne persönliche Daten zu ändern.

## Persönlicher Look 1.6.1 · 12.10.2026

Unter Mehr steht ein kompakter Bereich „Dein Look“. Die Detailauswahl öffnet ein vorhandenes Bottom Sheet. Hauptfarbe: Aktionen, Navigation und Auswahl. Zweite Farbe: Fortschritt, PRs und Diagramme. Warnung/Fehler bleiben davon unabhängig. Sechs Vorschläge sowie die native Farbauswahl; Dark/Light und Rücksetzen im selben Bereich. Kein Konto nötig.

Akzentfarben werden bei Bedarf in ihrer Helligkeit so angepasst, dass sie gegen die vier festen Theme-Ebenen mindestens 4,5:1 Kontrast erreichen. Buttonbeschriftungen werden je nach Hintergrund schwarz oder weiß. Individuelle Farben werden als RGB-Hexwerte gespeichert. Die Oberfläche erklärt die Helligkeitsanpassung. Diese Prüfung ersetzt keine vollständige WCAG-Abnahme der App.

„YOU VS YOU“ ist dekorativ, `aria-hidden`, ohne Zeigerereignisse und ohne Scroll-/Frame-Animation. Karten lassen 15 % des Hintergrundes durch; aktive Workout-Karten nur 4 %. Der Nutzer kann den Effekt abschalten. Bei `prefers-reduced-transparency` wird er automatisch ausgeblendet. Keine Aussage, dass das Betriebssystem-Wallpaper durch die Web-App sichtbar wird.

Der Switch hat eine 48 × 28 px Spur, einen 22 px Kreis mit 3 px Rand und 20 px Weg. Die berührbare Fläche ist 48 × 44 px. Kleine Variante: 40 × 24 px Spur, 18 px Kreis, 16 px Weg; nur für anderweitige kompakte Einsätze vorgesehen. Ein Transform, keine zusätzliche CSS-Translation. Bei Reduce Motion keine Schalterbewegung. Forced Colors erhält Systemfarben.

## Vereinfachung 1.6.0 · 09.10.2026

Heute priorisiert den Kalender (Woche, optional Monat), Starten/Fortsetzen, vorhandene Pläne und anschließend den persönlichen Fortschritt. Ein direkter Fortschrittsknopf bleibt oben. Frühere Rückblickkarten und Studienhinweise entfallen. Kein neuer Bottom-Tab und keine globale Seitenanimation.

Bibliothek und Workout-Picker zeigen fünf Treffer. Ein beschrifteter Pfeil öffnet alle. Suchbegriffe werden vor der Begrenzung ausgewertet. Änderung eines Filters beginnt wieder mit fünf Treffern. Metadaten, Favoriten, eigene Übungen und Detailfenster bleiben erhalten.

„Mehr“ enthält nur Statistik und Video als Zusatzbereiche; Quellen sind optionale Textlinks im eingeklappten Infobereich. Coach-Begründungen behalten Nutzen und Unsicherheit, ohne Studienliste.

# Forma 1.4.1 · Design und Interaktion

Stand: 07.10.2026. Ziel ist eine ruhige, mobile Trainingsoberfläche mit direkt bedienbaren Eingaben. Vorhandene Daten, Trainingsberechnungen und Seitenstruktur bleiben erhalten.

## Gemeinsame Materialien

| Token | Dunkel | Verwendung |
|---|---|---|
| Hintergrund | `#0b0c0e` | Ruhige Grundfläche |
| Fläche | `#17191d` | Karten und Daten |
| Zweite Ebene | `#22252a` | Eingaben und Auswahl |
| Text | `#f1f3f5` | Hauptinformationen |
| Sekundärtext | `#a8aeb8` | Erklärungen und Labels |
| Akzent | `#c2dfd2` | Wichtige Aktion, Aktivität, Fortschritt |
| Kartenradius | 24 px | Gemeinsame Flächen |
| Eingaberadius | 14 px | Buttons, Eingaben, Auswahl |

Die helle Palette benutzt dieselben semantischen Tokens. Glas wird auf Navigation, Timer, Sheets und kleine Menüs begrenzt. Karten und Diagramme bleiben weitgehend deckend. Transparenz hat einen deckenderen Fallback bei `prefers-reduced-transparency`.

## Wiederverwendbare Komponenten

- `BottomNavigation.tsx`: eine gemeinsame Glass Pill unter fünf Navigationszielen. Pointer Capture, direkte CSS-Transformation während des Ziehens, begrenzte Dehnung und sanftes Einrasten. Maße werden am Anfang/bei Resize gelesen; keine React-Neuberechnung je Bewegungsereignis. Tastatur und einfacher Tipp funktionieren ebenfalls.
- `ui.tsx`: gemeinsame Auswahl, Zahlenfelder, Sheets, Bestätigungen und Übungssuche. Die einfache Geräte-/Muskelwahl bleibt ein natives Select. Suche und Treffer verwenden einen gemeinsamen vertikalen Scrollbereich.
- `interactions.ts`: gemeinsame Zurück-Navigation für Ebenen, Fokuswechsel und Visual-Viewport-Anpassung. Bei Bildschirmtastatur werden schwebende Trainings-/Navigationsleisten ausgeblendet, Sheet-Höhe und Abstand angepasst.
- `Clocks.tsx`: Timer und Trainingsdauer aktualisieren ihre eigenen kleinen Ansichten. Ein Countdown erzwingt keine sekündliche Neuberechnung der Bibliothek oder aller Workout-Karten.
- `app/refinement.css`: semantische Farben, Rundungen, Abstände, aktive Zustände, responsive Anordnungen und Bewegung. Bewusst nach dem bestehenden Layout geladen; keine Vermischung mit Daten-/Coachlogik.

## Bewegung und Touch

Navigation rastet innerhalb ungefähr 380 ms ein. Seiteninhalt blendet in 280 ms mit maximal 4 px Bewegung ein; Sheets öffnen in 360 ms und schließen in 240 ms. Keine überschießenden Kurven. Seit 1.5.1 animiert Web Animations ausschließlich den lebenden Seiteninhalt. Dokumentweite View-Transition-Aufnahmen werden nicht mehr verwendet, weil sie die feste Navigation vorübergehend überdecken. Navigation und Timer bleiben außerhalb der Inhaltsanimation; ohne API oder bei reduzierter Bewegung erfolgt der Wechsel direkt. Die Zielansicht ist vor dem Übergang geladen, die letzte Navigationsabsicht gewinnt bei schnellen Eingaben. Beim Ziehen wird die Animation ausgesetzt und die Position folgt direkt dem Finger. Die Navigation unterscheidet einen Tipp von einer Bewegung ab 7 px. Schließende Sheets behalten ihren Inhalt bis zum Ende; nach einem abgebrochenen Drag wird die Öffnungsanimation nicht wiederholt. Der Griff kann zum Schließen gezogen werden; normales Scrollen im Inhalt schließt das Sheet nicht. Ein eigenständiger großer Schließen-Button bleibt vorhanden.

Häufige Satzeingaben warten nicht auf eine Animation. Plus/Minus rechnet mit dem zuletzt gespeicherten Wert in einer atomaren Transaktion. Beim Drücken werden Bedienelemente geringfügig skaliert. `prefers-reduced-motion` reduziert Übergänge auf praktisch sofortige Zustandswechsel und entfernt Skalierung.

Touchziele sind überwiegend mindestens 44 px; Zahlenfelder mindestens 16 px Schriftgröße. Bei 320 px steht die vorherige Satzleistung in einer zusätzlichen Zeile, damit alle aktuellen Eingaben und die Abschlusstaste innerhalb der Karte liegen. Pinch-Zoom wird nicht pauschal deaktiviert. Safe-Area-Abstände sind für Header, Navigation, Sheets und Inhaltsende vorgesehen.

## Informationshierarchie

„Heute“ zeigt eine kompakte Gewichtskurve und die wichtigsten Übungen. Ein gemeinsamer Button darunter öffnet die vollständige Fortschrittsansicht. Auch Übungsanalysen gehören zur Heute-Navigation; der Zeitraum bleibt beim Zurückgehen erhalten. „Mehr“ enthält Einstellungen und die zusätzlichen Werkzeuge Statistik und Videoanalyse. Quellen sind im eingeklappten Infobereich erreichbar. Trainingspläne gehören zu „Workout“.

## Grenzen

Dies ist eine Weboberfläche mit eigenem Glasmaterial, keine native Apple-Implementierung und keine optische Echtzeitbrechung. Es gibt dezente Ansichts-/Sheet-Übergänge, aber kein aufwendiges echtes Geometrie-Morphing zwischen allen Übungskarten und Detailseiten. Die Testläufe prüfen Verhalten und Layout in Chromium/WebKit, keine feste Bildrate oder native iPhone-Gesten. Eine physische iPhone-Abnahme ist weiterhin sinnvoll.

Technische Grundlagen: [Pointer Events](https://developer.mozilla.org/en-US/docs/Web/API/Pointer_events), [VisualViewport](https://developer.mozilla.org/en-US/docs/Web/API/VisualViewport), [Reduced Motion](https://developer.mozilla.org/en-US/docs/Web/CSS/Reference/At-rules/@media/prefers-reduced-motion). Keine übernommenen Grafiken oder kopierten App-Layouts.
