## Vereinfachung 1.6.0 · 09.10.2026

Heute priorisiert den Kalender (Woche, optional Monat), Starten/Fortsetzen, vorhandene Pläne und anschließend den persönlichen Fortschritt. Ein direkter Fortschrittsknopf bleibt oben. Frühere Rückblickkarten und Studienhinweise entfallen. Kein neuer Bottom-Tab und keine globale Seitenanimation.

Bibliothek und Workout-Picker zeigen fünf Treffer. Ein beschrifteter Pfeil öffnet alle. Suchbegriffe werden vor der Begrenzung ausgewertet. Änderung eines Filters beginnt wieder mit fünf Treffern. Metadaten, Favoriten, eigene Übungen und Detailfenster bleiben erhalten.

„Mehr“ enthält nur Statistik und Video als Zusatzbereiche; Quellen sind optionale Textlinks im eingeklappten Infobereich. Coach-Begründungen behalten Nutzen und Unsicherheit, ohne Studienliste.

# Forma 1.4.1 · Design und Interaktion

Stand: 07.10.2026. Ziel ist eine ruhige, mobile Trainingsoberfläche mit direkt bedienbaren Eingaben. Vorhandene Daten, Trainingsberechnungen und Seitenstruktur bleiben erhalten.

## Gemeinsame Materialien

| Token | Dunkel | Verwendung |
|---|---|---|
| Hintergrund | `#0b0c0e` | Ruhige Grundfläche |
| Fläche | `#17191d` | Karten und Daten |
| Zweite Ebene | `#22252a` | Eingaben und Auswahl |
| Text | `#f1f3f5` | Hauptinformationen |
| Sekundärtext | `#a8aeb8` | Erklärungen und Labels |
| Akzent | `#c2dfd2` | Wichtige Aktion, Aktivität, Fortschritt |
| Kartenradius | 24 px | Gemeinsame Flächen |
| Eingaberadius | 14 px | Buttons, Eingaben, Auswahl |

Die helle Palette benutzt dieselben semantischen Tokens. Glas wird auf Navigation, Timer, Sheets und kleine Menüs begrenzt. Karten und Diagramme bleiben weitgehend deckend. Transparenz hat einen deckenderen Fallback bei `prefers-reduced-transparency`.

## Wiederverwendbare Komponenten

- `BottomNavigation.tsx`: eine gemeinsame Glass Pill unter fünf Navigationszielen. Pointer Capture, direkte CSS-Transformation während des Ziehens, begrenzte Dehnung und sanftes Einrasten. Maße werden am Anfang/bei Resize gelesen; keine React-Neuberechnung je Bewegungsereignis. Tastatur und einfacher Tipp funktionieren ebenfalls.
- `ui.tsx`: gemeinsame Auswahl, Zahlenfelder, Sheets, Bestätigungen und Übungssuche. Die einfache Geräte-/Muskelwahl bleibt ein natives Select. Suche und Treffer verwenden einen gemeinsamen vertikalen Scrollbereich.
- `interactions.ts`: gemeinsame Zurück-Navigation für Ebenen, Fokuswechsel und Visual-Viewport-Anpassung. Bei Bildschirmtastatur werden schwebende Trainings-/Navigationsleisten ausgeblendet, Sheet-Höhe und Abstand angepasst.
- `Clocks.tsx`: Timer und Trainingsdauer aktualisieren ihre eigenen kleinen Ansichten. Ein Countdown erzwingt keine sekündliche Neuberechnung der Bibliothek oder aller Workout-Karten.
- `app/refinement.css`: semantische Farben, Rundungen, Abstände, aktive Zustände, responsive Anordnungen und Bewegung. Bewusst nach dem bestehenden Layout geladen; keine Vermischung mit Daten-/Coachlogik.

## Bewegung und Touch

Navigation rastet innerhalb ungefähr 380 ms ein. Seiteninhalt blendet in 280 ms mit maximal 4 px Bewegung ein; Sheets öffnen in 360 ms und schließen in 240 ms. Keine überschießenden Kurven. Seit 1.5.1 animiert Web Animations ausschließlich den lebenden Seiteninhalt. Dokumentweite View-Transition-Aufnahmen werden nicht mehr verwendet, weil sie die feste Navigation vorübergehend überdecken. Navigation und Timer bleiben außerhalb der Inhaltsanimation; ohne API oder bei reduzierter Bewegung erfolgt der Wechsel direkt. Die Zielansicht ist vor dem Übergang geladen, die letzte Navigationsabsicht gewinnt bei schnellen Eingaben. Beim Ziehen wird die Animation ausgesetzt und die Position folgt direkt dem Finger. Die Navigation unterscheidet einen Tipp von einer Bewegung ab 7 px. Schließende Sheets behalten ihren Inhalt bis zum Ende; nach einem abgebrochenen Drag wird die Öffnungsanimation nicht wiederholt. Der Griff kann zum Schließen gezogen werden; normales Scrollen im Inhalt schließt das Sheet nicht. Ein eigenständiger großer Schließen-Button bleibt vorhanden.

Häufige Satzeingaben warten nicht auf eine Animation. Plus/Minus rechnet mit dem zuletzt gespeicherten Wert in einer atomaren Transaktion. Beim Drücken werden Bedienelemente geringfügig skaliert. `prefers-reduced-motion` reduziert Übergänge auf praktisch sofortige Zustandswechsel und entfernt Skalierung.

Touchziele sind überwiegend mindestens 44 px; Zahlenfelder mindestens 16 px Schriftgröße. Bei 320 px steht die vorherige Satzleistung in einer zusätzlichen Zeile, damit alle aktuellen Eingaben und die Abschlusstaste innerhalb der Karte liegen. Pinch-Zoom wird nicht pauschal deaktiviert. Safe-Area-Abstände sind für Header, Navigation, Sheets und Inhaltsende vorgesehen.

## Informationshierarchie

„Heute“ zeigt eine kompakte Gewichtskurve und die wichtigsten Übungen. Ein gemeinsamer Button darunter öffnet die vollständige Fortschrittsansicht. Auch Übungsanalysen gehören zur Heute-Navigation; der Zeitraum bleibt beim Zurückgehen erhalten. „Mehr“ enthält Einstellungen und die zusätzlichen Werkzeuge Statistik und Videoanalyse. Quellen sind im eingeklappten Infobereich erreichbar. Trainingspläne gehören zu „Workout“.

## Grenzen

Dies ist eine Weboberfläche mit eigenem Glasmaterial, keine native Apple-Implementierung und keine optische Echtzeitbrechung. Es gibt dezente Ansichts-/Sheet-Übergänge, aber kein aufwendiges echtes Geometrie-Morphing zwischen allen Übungskarten und Detailseiten. Die Testläufe prüfen Verhalten und Layout in Chromium/WebKit, keine feste Bildrate oder native iPhone-Gesten. Eine physische iPhone-Abnahme ist weiterhin sinnvoll.

Technische Grundlagen: [Pointer Events](https://developer.mozilla.org/en-US/docs/Web/API/Pointer_events), [VisualViewport](https://developer.mozilla.org/en-US/docs/Web/API/VisualViewport), [Reduced Motion](https://developer.mozilla.org/en-US/docs/Web/CSS/Reference/At-rules/@media/prefers-reduced-motion). Keine übernommenen Grafiken oder kopierten App-Layouts.
