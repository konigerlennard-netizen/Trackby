# Prüfprotokoll

## Geräteauswahl und Update 1.3.2 (05.10.2026)

- TypeScript, Produktionsbuild, PWA-Artefaktprüfung und alle **79 automatischen Tests erfolgreich**. Neue Prüfungen betreffen Suchaliase, getrennte eGym-/Griffvarianten, Planvorgaben im Backup und fehlende Referenz-/1RM-/Laststeigerungswerte bei elektronischen Geräten.
- Formular in Chromium und WebKit bei 390 × 844 sowie 320 × 568 geprüft: native Geräte-, Muskel- und Messartauswahl, Scrollbereich nach unten und oben, keine zusätzlichen Auswahl-Portale und kein horizontaler Überlauf. Eigene eGym-Übung speichern, neu laden und per JSON unverändert exportieren. Suchbegriffe für Überkopf-Trizeps und Reverse Preacher Curls sowie Gerätefilter erfolgreich.
- Den vollständigen Chromium-Test für Workout, einzelne Satzwerte, RIR, Timer, JSON-Import/-Export/-Rücknahme, Browserneustart, Offlinebetrieb und Desktop erneut erfolgreich ausgeführt.
- Echter Service-Worker-Versionswechsel im Browser: alten Produktionsbuild 1.3.1 geöffnet, Testplan mit individuellen Satzvorgaben und Gewichtseintrag gespeichert, Serverdateien auf 1.3.2 gewechselt und „Jetzt aktualisieren“ verwendet. Plan, Vorgaben, Gewichtseintrag und Notizen blieben erhalten. Anschließend Backup aus 1.3.1 importiert und neue Version offline geöffnet. Ausschließlich künstliche Testdaten; keine persönlichen Daten verwendet.
- Der öffentliche Trackby-Workflow wurde gelesen: Er entpackt bei jedem Push `Forma-GitHub-Pages.zip` und veröffentlicht den Inhalt. Das neue Paket muss vom Nutzer dort hochgeladen werden; keine Veröffentlichung durch diesen lokalen Test.

Reproduzieren (nach Installation der Testbrowser und ihrer Systembibliotheken):

```sh
npm run verify
npm run test:browser
node scripts/test-exercise-update.mjs
FORMA_PREVIOUS_BUILD=/pfad/zum/entpackten/alten/build node scripts/test-exercise-update.mjs
```

**Grenzen:** Linux-WebKit ist kein physisches iPhone. Der native iOS-Auswahldialog, reale Touch-Bildrate, Tastatur, Home-Bildschirm-Installation und iOS-Speicherbereinigung wurden nicht auf Hardware gemessen. Die geänderte Auswahl vermeidet das verschachtelte Scrollmenü; das Scrollgefühl muss auf dem Gerät bestätigt werden. Frühere Protokolle unten beschreiben ihren damaligen Stand.

## Standalone-Export 1.3.1 (01.10.2026)

- Saubere Installation aus dem enthaltenen npm-Lockfile erfolgreich. Kein Sites-/Next-/Vinext-Server oder privater Paketserver erforderlich.
- TypeScript-Prüfung und **76 automatische Tests erfolgreich**. Zehn zusätzliche Tests verwenden fake-indexeddb für echte IndexedDB-Transaktionsabläufe: neu öffnen, parallele Eingaben, abgewiesene Änderungen, Backup/Import/Rücknahme, getrennte Demo-Daten, Projektpfade und beschädigte gespeicherte Daten. Das Testdouble ersetzt keine Prüfung der Speicherung auf Datenträger.
- Produktionsbuild und Service-Worker-Prüfung erfolgreich: Root-Pfad, `/forma/`, verschachtelter Projektpfad, Cache-Bereinigung nur für das eigene Projekt, keine Navigation außerhalb des Scopes umgeleitet.
- **Zusätzlicher echter Chromium-Browsertest mit persistentem Profil**, mobilem Viewport 390 × 844 und Desktop 1440 × 1000: Erststart; Körpergewicht speichern; Workout starten; Übung suchen; zwei verschiedene Satzgewichte und Wiederholungen, RIR, Abschluss, Timer; aktives Workout nach Reload; Workout abschließen; JSON-Datei herunterladen und Inhalte prüfen; vollständiger Import einschließlich eigener Übungen, Satzvorgaben, Plänen, Gewicht, Einstellungen und Video-Metadaten; fehlerhafte Datei abweisen; Import zurücknehmen; Browserprozess schließen; denselben Profilordner offline wieder öffnen; alle Daten erneut als JSON vergleichen.
- Fortschrittsseite, Übungsbibliothek und Video-Oberfläche offline geöffnet. Getrennte Daten unter `/zweite-app/`; identische Daten unter `/forma/` und `/forma/index.html`. Kein horizontaler Überlauf in beiden geprüften Breiten. Keine JavaScript-Laufzeitfehler und keine externen Netzabrufe im geprüften Kernablauf.
- Testdaten waren künstliche QA-Einträge in einem temporären Profil. Die vorhandene veröffentlichte Website und ihre Nutzerdaten wurden nicht verändert.

Reproduzieren:

```sh
npm ci
npm run verify
npx playwright install chromium
npm run test:browser
```

Der Browsertest startet seinen lokalen statischen Server selbst, verwendet ausschließlich `dist/`, räumt sein Profil auf und schreibt Bericht/Screenshots nach `test-results/`. Diese temporären Dateien gehören nicht zum Export. Unter Linux können Browser-Systembibliotheken erforderlich sein (`npx playwright install-deps chromium`).

**Offen:** echter iPhone-/Safari-Test, Installation auf dem Home-Bildschirm, iOS-Speicherdruck und Hintergrundtimer, VoiceOver, Posequalität auf echten Trainingsaufnahmen. Ein WebKit-Start war hier wegen fehlender Systembibliotheken nicht verfügbar; es wird kein Safari-Test behauptet. Der automatische Modelldownload ist nicht Teil des Offline-Kerns. Die folgenden Abschnitte sind die historischen Testprotokolle der übernommenen App-Versionen.


## Ergänzung: Bibliothek und Leistungsvergleich 1.3 (30.09.2026)

66 automatische Tests erfolgreich, Typprüfung erfolgreich. Neue Prüfungen: 275 eindeutige Übungen und gültige Muskel-/Geräte-/Bewegungsdaten, Körpergewichts-/Zeit-/Unterstützungsmodi, deutsche/englische Varianten- und Kürzelsuche, unvermischt erhaltene Deadlift-Historien und Backups. Vergleich: Quellenanker und Tabellenzuordnung, Alters-/Gewichtsklassengrenzen, Jugendliche, nicht vorhandene oder widersprüchliche Referenzen, Trainingserfahrungsfilter, Ausschluss unpassender Übungsvarianten, Epley-/RIR-/RPE-Grenzen, keine künstlich präzisen Ränge und zeitlich passende Körpergewichtseinträge.

Die neue Vergleichskomponente wurde außerdem als SSR-Bundle gerendert: Übung, Eingaben, Quelleninformation und der Zustand einer nicht unterstützten Variante erscheinen ohne Renderfehler. Das ist kein Nachweis interaktiver Bedienung oder mobilen Layouts.

Die Referenzdaten werden reproduzierbar aus dem Original-PDF extrahiert; Gruppen- und Spaltenstruktur sowie ausgewählte Ankerwerte geprüft. Die publizierten Stichprobengrößen wurden zwischen Alters- und Gewichtstabellen abgeglichen und widersprüchliche Alterszellen ausgeschlossen. Keine eigenmächtige Zahlenkorrektur. Auswahl und Limits stehen in COMPARISON_METHOD.md.

Ein echter iPhone-/Safari-Test dieser Erweiterung ist noch offen. Die früheren Browserprüfungen unten belegen nicht die neue Vergleichsansicht. Auf dem iPhone prüfen: Suche „Sumo“, „Stiff Leg“, „Hex Bar“, „Smith RDL“; Übung zum Workout hinzufügen und getrennte Sätze speichern; „Mehr → Leistungsvergleich“ öffnen; Langhantel-Bankdrücken männlich, Alter 17 mit passendem vorhandenen Satz und Körpergewicht auswählen; grobe Jugendreferenz prüfen. Maschine, gleiche Trainingsjahre oder gemeinsamer Alter-/Gewichtsfilter müssen eine begründete Meldung ohne erfundene Perzentile liefern. Wechsel kg/lb sowie hell/dunkel prüfen. Ein tatsächlicher Maximalversuch ist für diese Abnahme nicht nötig.

## Ergänzung: Satzvorgaben 1.2 (30.09.2026)

56 automatische Tests erfolgreich, darunter fünf neue Prüfungen für individuelle Satzwerte, feldweise Übernahme aus der Historie, explizite 0 kg, unabhängige Satzdaten, Vergrößern/Verkleinern der Satzanzahl, Datenmigration 2 → 3, kg/lb, JSON-Roundtrip und Workout-Übernahme als Plan. Typprüfung erfolgreich. Der direkte Aufruf `node .test-build/core.test.js` zeigt alle 56 Fälle; der übergeordnete Node-Testlauf fasst die Datei in dieser Umgebung als einen Test zusammen.

Die neue Oberfläche wurde noch nicht auf einem echten iPhone oder im Browser geprüft. Die bisherigen Browserprüfungen weiter unten beziehen sich auf frühere Versionen. Zusätzlich auf dem iPhone prüfen: Plan bearbeiten → pro Satz unterschiedliche Werte eingeben → Plan speichern und wieder öffnen → starten → einen Satz ändern und abschließen → App neu öffnen. Leere Planfelder sollen historische Werte übernehmen; feste Vorgaben haben Vorrang.

Stand 28.09.2026. Browserprüfungen vom 24.09.2026 und für Fortschritt 1.1 vom 28.09.2026. Keine Behauptung einer vollständigen Gerätefreigabe.

## Automatisch ausgeführt

`pnpm typecheck`: erfolgreich. `pnpm test`: 51 Tests erfolgreich, darunter 20 Fortschrittstests und 6 Prüfungen der erweiterten Übungsbibliothek. Regeln prüfen insbesondere fehlende Daten, Beschwerden/Krankheit/Tagesform, Trainingserfahrung, ausbleibende Laststeigerung bei 10/10/9, RIR/RPE, zu große Lastsprünge, Warm-up-Ausschluss, Technikwechsel, aktive Wiederaufnahme, Pausen/Supersätze, Plateau versus mehr Reserve, Trainingspause, Epley-Grenzen, PRs, Importvalidierung, kg/lb und synthetische Videozyklen/Fehlerfälle.

Bibliothek 1.1.1: enge/breite Rudervarianten und Muskelzuordnung; deutsche/englische Suchbegriffe, beliebige Wortreihenfolge, Umlaute und T-Bar-Schreibweisen; eigene Übungen ohne Suchaliase; verlustfreier Backup-/Import-Roundtrip mit bisherigen und neuen Übungen, Plänen, Favoriten und Notizen. Vorherige Satzwerte, Historie, PRs und Coaching wurden auf Trennung der Griffvarianten geprüft. Diese Ergänzung wurde nicht erneut auf einem echten iPhone oder im Browser getestet.

Neue Prüfungen: Datenmigration 1 → 2, Gewicht im Backup-Roundtrip, ungültige/doppelte Einträge, Kalendertage und Sommerzeit, Monatsenden, eigene Zeiträume, einzelner Gewichtspunkt ohne Trend, Tagesmediane, getrennte Messwochen, Mindestdaten für Prozentwerte, Gewicht-/Wiederholungsvergleich, einzelne schlechte Einheit versus anhaltender Rückgang, Pausen-/Technik-/Satzkontext, Reserve, gleiche Last bei Wiederholungsvergleichen, ungeeignete Lastmodi, Planfilter und genaue Rekordsätze.

`node scripts/check-pwa.mjs` nach Build prüft Manifest, Icons, Cachedateien und Offline-Navigation/Chunks in einer simulierten Service-Worker-Umgebung. Das ist kein echter Browser-Offline- oder iOS-Installationsnachweis.

## Browserprüfung

Der Produktionsbuild vom 28.09.2026 ist erfolgreich. Die PWA-Artefaktprüfung findet 33 lokale Cachedateien einschließlich Fortschrittscode und Dokumentation; Navigation und App-Chunks sind aus dem simulierten Offline-Cache lesbar.

Durchgeführt in Chrome mit betreuter Entwicklungs-Vorschau. Nur eigens angelegte Testdaten, keine importierten Nutzerdaten. Visuell geprüft: Desktop, 390-Pixel-Mobilansicht im eingebetteten Viewport. Diese Mobilansicht emuliert weder iOS noch dessen Tastatur oder Speicherregeln.

Beobachtet: erstes Öffnen, freies Workout, Übungssuche nach englischem Begriff „Smith“, Übung hinzufügen, Gewicht/Wiederholungen/RIR ändern, Satz abschließen, Timer und Wiederaufnahme nach Neuladen, letzten Satz übernehmen, Satzstart markieren, weitere Sätze abschließen, Workout beenden, offene Sätze korrekt getrennt, Historie mit 70 kg × 9 und 1.260 kg Lastvolumen aus zwei erledigten Sätzen. Zusätzlich beobachtet: Workout als Plan speichern, Plan umbenennen, Latzug hinzufügen und umsortieren, gespeicherten Plan öffnen; JSON-Export mit anschließend validierter Datei; Demo-Modus, mobiles Push-Workout mit vorherigen Leistungen, Satzerfassung und Timer; Desktop-Statistiken mit Balken- und Liniendiagramm sowie Bestwerten. Der Dateiauswahl-Dialog für den Import wurde geöffnet; der vollständige Importablauf wurde im Browser noch nicht bestätigt. Backup-Parsing und Validierung sind durch automatisierte Tests abgedeckt.

Behobene Befunde: UUID-Erzeugung brauchte eine getRandomValues-Alternative für die HTTP-Vorschau; 1,25-Schritte wurden anfangs auf 1,3 gerundet; ungültige Modellversion 0.10.22 auf tatsächlich erreichbare 0.10.21 geändert; manuell eingetragene Satzpause wird beim Abschluss erhalten; neue Vergleichskontexte unterbrechen die Progressionshistorie; Speicherfehler zeigen keinen Erfolgstatus; Service Worker unterscheidet App-Navigation von Dokument- und ZIP-Downloads.

Fortschritt 1.1 im Browser am 28.09.2026: Gewicht mit Dezimalkomma gespeichert, Seite neu geladen und denselben Eintrag wieder geöffnet; Diagrammpunkt ausgewählt, Gewicht bearbeitet und gespeichert; einzelner Wert ohne Trend, Tagesfilter mit Datumseingabe per Tastatur und leerem Vortag; Beispielverläufe, Sortierung, englische Suche „Smith“, Übungsdetails, genauer Datenpunkt mit RIR/Pause, Wechsel zu Trainingsvolumen, Wochenansicht mit einem Workout, mobile Favoritenänderung. Bei 390 Pixel breitem Iframe (375 Pixel Nutzbreite wegen Scrollbar) weder auf Startseite noch Übungsdetails horizontales Überlaufen. Screenshots zeigen Beispieldaten. Native Datumseingabe reagierte auf Tastatur; programmatisches Befüllen allein löste in der Browser-Testumgebung keine Änderung aus. Der erneute Downloadversuch im Iframe wurde ausgelöst, die Testverbindung lief beim Warten auf das Downloadereignis in ein Timeout; daher kein zusätzlicher Browsernachweis für Backup-Restore. Die neuen Formate sind automatisch geprüft.

## Noch nicht auf realer Hardware bestätigt

- Safari/iPhone/iPad, tatsächliche Home-Bildschirm-Installation und Splashscreen.
- Echter Offline-Kaltstart unter HTTPS, Update bei mehreren offenen PWA-Instanzen und iOS-Speicherdruck.
- iOS-Tastatur, VoiceOver, Vibration/Ton nach Sperren des Bildschirms.
- Belastbarer Pose-/Wiederholungsbenchmark auf echten Trainingsvideos, unterschiedliche Kleidung, Licht, Verdeckungen und Kamerawinkel.
- Mehrjährige Datenbestände und Browserquoten; Absturz genau während eines Schreibvorgangs.
- Vollständiger Accessibility-Audit, unabhängige anatomische und trainingswissenschaftliche Fachprüfung.

## Reproduzierbare iPhone-Abnahme

1. Auf finalem HTTPS-Link installieren; Home-Bildschirm-App mit Internet starten. Unter Mehr Offlinebereitschaft abwarten.
2. Freies Testworkout → Übung hinzufügen → zwei Sätze erfassen; zwischen den Sätzen App schließen/öffnen. Werte und Timerdeadline müssen erhalten bleiben.
3. Flugmodus aktivieren, App vollständig schließen, neu öffnen, Satz ergänzen und beenden. Historie und Charts prüfen. Flugmodus wieder ausschalten.
4. Neues Template erstellen, zwei Übungen hinzufügen, mit Pfeilen sortieren, eine entfernen; speichern und starten. Früheren Workout als Template sichern und erneut starten.
5. JSON exportieren, Datei prüfen, testweise importieren; Vorschau und Bestätigung beachten. Rücknahme prüfen. Nicht mit ungesicherten echten Daten experimentieren.
6. Helles/dunkles Theme, kg/lb, optional RPE, Satztypen, Timer +30 s und „Reduce Motion“ prüfen.
7. Kurzes seitliches MP4 auswählen, Modell bewusst laden, Ausgabe mit manuell gezählten Wiederholungen vergleichen. Ungeeignete Aufnahme muss Unsicherheit/Fehler zeigen. Abbruch und manuelle Markierung prüfen.
8. Erst nach erfolgreichen Checks die persönliche Alltagsnutzung mit regelmäßigen Backups beginnen.

Offene Punkte sind explizite Grenzen der Abnahme und werden nicht als bestandene Tests ausgegeben.
