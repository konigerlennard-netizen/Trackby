# Abnahme 1.6.0 · 09.10.2026

## Vor der Überarbeitung

Der Quellcode unter `features/` und `app/` stimmt mit der gespeicherten Version 1.5.1 überein. TypeScript und alle 86 bisherigen Kernprüfungen bestanden. Der vollständige Chromium-Workout-Ablauf wurde gegen das unveränderte 1.5.1-Produktionspaket geprüft: Planbearbeitung, schnelle Satzeingaben, Historie, Fortschritt, Diagramme und Navigation bestanden. Festgestellt wurden die vom Nutzer beschriebenen Bedienprobleme: überladene Startseite, vollständige 300er-Listen und ein unhilfreicher separater Leistungsvergleich.

## Nach der Überarbeitung

- 91 Kernprüfungen: bestehende 86 sowie Kalendergrenzen, Schaltjahr, Zeitumstellung, Monatswechsel und mehrere abgeschlossene Einheiten pro Tag.
- Chromium und Linux-WebKit: Workout-Regression einschließlich Plan erstellen/umsortieren/kopieren/löschen, Entwurfschutz, Gewicht/Wiederholungen/RIR/RPE, acht schnelle neue Sätze, Duplizieren/Löschen, Pausentimer, Ersetzen, Supersatz, Abschluss, Korrektur, Wiederverwendung, PRs und Körpergewicht/Diagramme.
- Navigation in beiden Engines: Pixeltest während des Seitenübergangs, 61 schnelle Wechsel, Glass-Pill-Drag, Tastatur-Simulation, 320/390/430 px, Desktop, Reduced Motion. Auch frühere Sheet-/Scroll-Lock-Prüfungen bestanden.
- Neue Oberflächenprüfungen: Reihenfolge Kalender → Pläne → Fortschritt auf dem iPhone; Wochen-/Monatswechsel; Datumsauswahl; wiederholtes Blättern; fünf Treffer; vollständige Suche und Filter; Aufklappen/Zuklappen; Übungsauswahl; direkte Fortschrittsnavigation; entfernte Vergleichszugänge; alter `#comparison`-Link führt zum persönlichen Fortschritt; Quellen nur auf Nachfrage.
- Chromium: JSON-Export/Import, ungültiger Import, Rücknahme, vollständig geschlossener Browser und echter Offline-Neustart, getrennte GitHub-Pages-Unterverzeichnisse bestanden.
- Echtes Service-Worker-Update 1.5.1 → 1.6.0 in Chromium: Workoutdaten mit RIR, Pausen, Tempo und Notizen; eigene Übungen; Favoriten; Pläne mit individuellen Satzvorgaben; Körpergewicht; Video-Metadaten und Einstellungen erhalten. Ein Backup der Vorversion bleibt importierbar. Anschließend offline neu geladen.
- Datenbank, Schema, Speicherpfad, Coach, Fortschrittsberechnung, Übungs-IDs, Cloud-Module und Workout-Satzeingabe sind gegenüber 1.5.1 bytegleich. Keine neue Migration.

## Grenzen

Kein physisches iPhone, keine echte PWA-Installation, VoiceOver oder Bildratenmessung. Linux-WebKit 18.4 erlaubt im hier eingesetzten Testtreiber keinen Offline-Dokument-Neustart (`WebKit encountered an internal error`). Derselbe Fehler wurde isoliert gegen 1.5.1 und 1.6.0 bei aktivem Service Worker und vorhandenem Cache bestätigt. Deshalb wird dieser einzelne WebKit-Schritt ausdrücklich nicht als bestanden ausgegeben; Online-Neustart und Offline-Navigation innerhalb der geöffneten App sind separat geprüft. Echte Offline-Neustarts sind in Chromium abgedeckt.

Keine neuen Behauptungen zur Pose-Genauigkeit oder zu externen Cloud-Diensten; beide wurden in dieser UI-Version nicht verändert. Hauptbundle weiterhin ungefähr 603 kB unkomprimiert (Build-Warnung >500 kB); große Zusatzbereiche bleiben dynamisch geladen.

Befehle: `npm run verify`, `npm run test:simplicity`, `npm run test:refinement`, `npm run test:navigation`, `npm run test:motion`, `npm run test:browser`, `npm run test:update`. Für WebKit `FORMA_ENGINE=webkit`; für den Versionswechsel zusätzlich `FORMA_PREVIOUS_VERSION=1.5.1` und `FORMA_PREVIOUS_BUILD=<entpackter 1.5.1-Build>`.

---

# Prüfprotokoll

## Navigationskorrektur 1.5.1 (08.10.2026)

Ausgangspunkt: Produktionsbuild 1.5.0. Der neue Pixeltest scheitert vor der Korrektur reproduzierbar: Eine Probe innerhalb der Navigation wird während der Seitenaufnahme überzeichnet, obwohl CSS-Sichtbarkeit und Position korrekt sind. Nach der Korrektur bleibt sie unverändert sichtbar.

| Bereich | Ergebnis |
|---|---|
| Navigation, Chromium und Linux-WebKit | Pixelprüfung bei angehaltener Inhaltsanimation erfolgreich. Navigation bleibt dasselbe DOM-Element; Scrollen, 61 schnelle Wechsel, direkter Glass-Pill-Drag, Übungsfenster und Fortschritts-Rückweg geprüft. |
| Mobil und Tastatur | 320/390/430 px ohne Überlauf; Navigation im sichtbaren Bereich und per Hit-Test erreichbar. Simulierte Visual-Viewport-Verkleinerung blendet sie nur während der Texteingabe aus; nach Blur wieder sichtbar. Kein Ersatz für eine echte iOS-Tastaturprüfung. |
| Animationen | Beide Engines: 41 schnelle Wechsel, stabil schließende Sheets, kurze/lange Ziehbewegungen, reduzierte Bewegung und direkter Fallback ohne Element.animate erfolgreich. |
| Workout-Regression | Beide Engines: Pläne, Reihenfolge, Entwurfschutz, Satzgewichte/Wiederholungen, RIR/RPE, Timer, acht schnelle Satzergänzungen, Duplizieren/Löschen, Übungsersatz, Workout-Abschluss, Historie, PRs, Körpergewicht und Diagramme erfolgreich. |
| Speicherung | Chromium: vollständige JSON-Rundreise, ungültigen Import abweisen, Rücknahme; Browserprozess schließen und offline erneut öffnen. Workouts, Pläne, eigene Übungen, Körpergewicht, Einstellungen und Video-Metadaten erhalten. |
| Update | Chromium: Service-Worker-Wechsel 1.5.0 → 1.5.1, gespeicherte Daten vor/nach exakt verglichen (Backup-Zeitpunkt ausgenommen), altes Backup wieder importiert und offline geöffnet. |
| Kern und Build | TypeScript, 86 Logik-/Speichertests und PWA-Artefaktprüfung bestanden. Speicher-, Schema-, Übungs-, Coaching-, Fortschritts- und Cloud-Dateien byteweise unverändert gegenüber dem Quellcodepaket 1.5.0. |

Neue gezielte Prüfung: `npm run test:navigation`, zusätzlich `FORMA_ENGINE=webkit npm run test:navigation`. Die bisherigen Befehle bleiben bestehen; für den Update-Test `FORMA_PREVIOUS_VERSION=1.5.0` und einen entpackten 1.5.0-Build angeben.

Grenzen: kein physisches iPhone, keine echte Home-Bildschirm-Installation oder native Bildschirmtastatur in diesem Test. WebKit 18.4 auf Linux ist Safari-nah, nicht iOS. Touch-Bildrate und Verhalten bei eingeblendeter Safari-Adressleiste bleiben auf Hardware zu prüfen. Cloud-Anbindung und Poseanalyse wurden nicht verändert oder neu gegen externe Dienste geprüft. Ausschließlich künstliche Testdaten; keine persönlichen Trainingsdaten verwendet.

## Abschlussprüfung 1.5.0 (07.10.2026)

Ausgangspunkt: gesichertes Quellcodepaket 1.4.1 byteweise abgeglichen, 79 bestehende Tests vor Änderungen erfolgreich. Ausschließlich künstliche Trainingsdaten und temporäre Browserprofile.

| Bereich | Ergebnis |
|---|---|
| Logik, Speicher, Typen | TypeScript und 86 Tests erfolgreich, darunter sieben neue Prüfungen für Konfliktentscheidung, Fingerabdruck, geheime Schlüssel, getrennte Tokens, atomare Cloud-Übernahme, aktives Workout und einzelne Plansätze. |
| Workout-Regression | Chromium und Linux-WebKit: Pläne, Reihenfolge, Entwurfschutz, Workout, Gewicht, Wiederholungen, RIR/RPE, Timer, schnelle +/- Eingaben, acht Sätze in Folge, Duplizieren/Löschen, Übungsauswahl, Abschluss, historische Korrektur, Wiederverwendung, PRs, Körpergewicht und interaktive Diagramme erfolgreich. |
| Neue Planansicht | Beide Engines: individuelles Gewicht/Wiederholungen, mittlere Zeile entfernen ohne Datenverschiebung, Range standardmäßig eingeklappt, nach Neustart identische gespeicherte Werte. |
| Cloud-Ablauf | Beide Engines, offizieller Supabase-Client gegen lokalen simulierten Endpoint: Code-Anmeldung, Upload, explizite Übernahme auf neuem Gerät, Offline-Eingaben, automatischer Online-Abgleich, beidseitiger Konflikt, Version exportieren, Abmelden ohne Datenverlust, abweichendes Konto vor Upload blockiert. |
| SQL-Sicherheit | Mit PGlite/PostgreSQL: Setup zweimal ausführbar, anonyme Zugriffe gesperrt, zwei Auth-Benutzer getrennt, fremde Zeilen nicht les-/schreibbar, veraltete Version abgewiesen, vorige Daten archiviert, zehn Versionen behalten. |
| Persistenz, Export/Import | Chromium mit geschlossenem Browserprozess und erneutem Offline-Start: vollständige Daten erhalten; vollständiger JSON-Import, ungültiger Import und Rücknahme erfolgreich. |
| Update | Chromium, echter Service-Worker-Wechsel 1.4.1 → 1.5.0: Workouts/Satzdetails, Pläne/Satzvorgaben, Körpergewicht, eigene Übungen, Einstellungen, Favoriten, Notizen und Video-Metadaten vor/nach Update verglichen; altes Backup importiert, offline geöffnet. |
| Navigation/Animation | Beide Engines: 41 schnelle Tab-Aktionen, Glass-Pill ohne Sprung, stabile Sheet-Inhalte beim Schließen, kurze/lange Drag-Gesten, Reduce Motion, View-Transition-Fallback. Im WebKit-Lauf gefundenes Sheet/Hash-Rennen bei Start/Abschluss korrigiert und vollständigen Ablauf danach erneut bestanden. |
| Darstellung | 320/390 px und Desktop ohne horizontalen Dokumentüberlauf in den geprüften Abläufen. Dark/Light, Dropdowns, Scrollen und Screenshots geprüft. |

Reproduzierbare Befehle zusätzlich zu den bisherigen Tests:

```sh
npm run verify
npm run test:cloud:sql
npm run test:cloud
FORMA_ENGINE=webkit npm run test:cloud
npm run test:refinement
FORMA_ENGINE=webkit npm run test:refinement
npm run test:motion
FORMA_ENGINE=webkit npm run test:motion
npm run test:browser
FORMA_ENGINE=chromium FORMA_PREVIOUS_VERSION=1.4.1 FORMA_PREVIOUS_BUILD=/pfad/zum/build-1.4.1 npm run test:update
python3 scripts/package-release.py
```

Grenzen: kein physisches iPhone, kein Live-Supabase-Projekt und keine echte Mailzustellung getestet. Der simulierte Cloud-Test läuft ohne Service Worker auf demselben Test-Origin, weil WebKits Testumgebung native CORS-Preflights nicht abfängt; produktive Provider-Konfiguration/CORS muss nach Einrichtung geprüft werden. PWA-Offline- und Update-Abläufe werden separat mit echtem Service Worker geprüft. Kein Anspruch auf E2E-Verschlüsselung oder Synchronisierung bei geschlossener App. Pose-Genauigkeit und wissenschaftliche Regeln wurden in dieser Version nicht verändert. Der bestehende Build-Hinweis zum großen Haupt-Chunk bleibt; Supabase wird erst nach vorhandener Cloud-Konfiguration dynamisch geladen.

## Abschlussprüfung 1.4.1 (07.10.2026)

Vorher: bestehender Bedienungs-Regressionslauf auf 1.4.0 erfolgreich. Nach der Verfeinerung wurden die nachfolgenden Prüfungen ausgeführt. Ausschließlich künstliche Daten und temporäre Browserprofile; kein Zugriff auf persönliche Trainingsdaten.

| Bereich | Ergebnis |
|---|---|
| Typprüfung und Logik | TypeScript, 79 Logik-/Speichertests und Produktions-/PWA-Artefaktprüfung erfolgreich. |
| Bestehende Funktionen | Chromium und WebKit: Plan erstellen/umsortieren/Entwurf schützen; Workout starten, Gewicht/Wiederholungen/RIR/RPE, acht Sätze schnell ergänzen, duplizieren/löschen, Timer, Übungsauswahl/Ersetzen/Anordnung, Abschluss, Historie, Wiederverwendung, PR, Körpergewicht, Diagrammpunkte und Statistiken erfolgreich. |
| Persistenz und Backups | Chromium: vollständiger JSON-Export/Import, ungültiger Import, Rücknahme; Browserprozess mit persistentem Profil geschlossen und offline wieder geöffnet; Daten danach erneut unverändert exportiert. |
| Navigation | Chromium und WebKit: Fortschritt unter Heute, drei ergänzende Werkzeuge unter Mehr, korrekter Rückweg und erhaltener Zeitraum. 41 schnelle Tab-Aktionen enden bei der zuletzt gewählten Ansicht. |
| Animationen und Sheets | Beide Engines: kein Pill-Sprung beim Pointer-down, Drag-Schwelle, Inhalt und Höhe beim Schließen erhalten, kurzer Drag federt zurück ohne erneute Öffnungsanimation, langer Drag schließt von der aktuellen Position, keine hängenden Dialoge/Scroll-Sperren. |
| Fallbacks | Beide Engines: reduzierte Bewegung sowie Navigation mit ausgeschalteter View-Transition-API bedienbar. Hell/dunkel und manuelle Update-Prüfung erfolgreich. |
| Responsive Layout | Heute mit Demo-Daten bei 320 × 568, 390 × 844 und 1440 × 1000 ohne horizontalen Dokumentüberlauf. Bibliothek und eigenes Übungsformular bei 320/390 px geprüft; Gerätewahl und Scrollen in beide Richtungen, speichern und erneut laden erfolgreich. Während der Prüfung gefundene Überläufe wurden behoben und erneut getestet. |
| Echtes Update | Chromium: unveränderter Produktionsbuild 1.4.0 → 1.4.1 über wartenden Service Worker und „Jetzt aktualisieren“. Workouts mit Satzdetails, Pläne mit individuellen Zielwerten, eigene Übungen, Körpergewicht, Notizen, Favoriten, Einstellungen und Video-Metadaten vor/nach Update exakt verglichen; Backup-Zeitpunkt separat berücksichtigt. Altes Backup importiert, aktualisierte App offline geöffnet. |

Keine Laufzeitfehler in den bestandenen Abläufen. Kein externer Netzabruf im geprüften Offline-Kern. Die Speicher-, Datenformat-, Übungskatalog- und Coachingdateien wurden zusätzlich mit dem Quellcodepaket 1.4.0 auf unveränderten Inhalt geprüft.

Reproduzierbar nach `npm ci` und Installation der Playwright-Browser/Systembibliotheken:

```sh
npm run verify
npm run test:browser
npm run test:refinement
FORMA_ENGINE=webkit npm run test:refinement
npm run test:motion
FORMA_ENGINE=webkit npm run test:motion
FORMA_PREVIOUS_BUILD=/pfad/zum/entpackten/1.4.0-build npm run test:update
```

**Grenzen:** Linux-WebKit ist kein physischer iPhone-/Safari-Test. Native Bildschirmtastatur, tatsächliche Touch-Bildrate, VoiceOver und Home-Bildschirm-Installation bleiben auf dem Gerät zu prüfen. Die optionale Poseanalyse wurde bei diesem Oberflächenupdate nicht neu auf Genauigkeit geprüft. Es gibt keine Garantie gegen die Löschung lokaler Browserdaten durch Nutzer oder Betriebssystem. Die folgenden Protokolle beschreiben frühere Versionen.

## Abschlussprüfung 1.4.0 (07.10.2026)

Vor Änderungen wurde 1.3.2 vollständig in den vorhandenen Tests geprüft und um gezielte Bedienversuche ergänzt. Die dabei reproduzierten Fehler stehen in [AUDIT.md](AUDIT.md). Nach den Änderungen wurde die folgende zweite Prüfung ausgeführt; Testdaten sind künstlich und von persönlichen Daten getrennt.

| Bereich | Ergebnis und Umfang |
|---|---|
| Typen, Logik, Speicher | TypeScript und 79 Tests erfolgreich: atomare Änderungen, konkurrierende Eingaben, unzulässige Daten, Backup-Rundreise/Rücknahme, Migration, Coaching, Plateau, PRs, Fortschrittsregeln, Übungsvarianten und synthetische Videozyklen. |
| Bestehender Workout-Ablauf | Chromium: Erststart, freies Workout, unterschiedliche Satzgewichte/Wiederholungen, RIR, Timer, aktives Workout nach Reload, Abschluss, Historie und JSON mit exakten Satzwerten. |
| Vollständige Datensicherung | Chromium: Import einschließlich Plänen, individuellen Satzvorgaben, eigenen Übungen, Einstellungen, Körpergewicht und Video-Metadaten; ungültige Datei abgewiesen; Import verlustfrei zurückgenommen. Browserprozess geschlossen, Profil offline neu geöffnet und Daten erneut exportiert/verglichen. |
| Neue Bedienabläufe | Chromium und Linux-WebKit: Plan mit zwei Übungen erstellen, umsortieren, Ziel-Sätze ändern, Entwurf beim Schließen und Browser-Zurück schützen, speichern und starten. Verschachtelte Auswahl bleibt bedienbar. |
| Schnelle Eingaben | Beide Engines: zehn Gewichts- und Wiederholungsschritte ohne verlorene Änderungen; acht Sätze schnell hinzufügen, Satz duplizieren/löschen, RIR/RPE wechseln, Timer +30 s/Schließen. Acht schnelle Klicks auf Plan kopieren erzeugen genau eine Kopie; diese lässt sich kontrolliert löschen. |
| Workout und Historie | Beide Engines: Übung hinzufügen/entfernen/umsortieren, Ersatzwarnung abbrechen ohne Verlust, Pause/Supersatz/Coach-Erklärung, Workout beenden, historischen RIR korrigieren, als Plan speichern, erneut starten mit vorheriger Leistung und neuen PR erkennen. |
| Fortschritt und Charts | Beide Engines: Gewicht mit Dezimalkomma, einzelner Punkt ohne Trend, exakte Diagrammpunkte, Zeitraum Gesamt, Leistungskennzahl wechseln, Satzdetails, Zurück zur Übungsliste und Statistik nach zwei Einheiten. Weitere Zeitraum-/Trendregeln durch die Logiktests abgedeckt. |
| Bibliothek und Auswahl | Beide Engines: native Geräte-/Muskel-/Messartwahl, eigenes eGym-Gerät speichern, in beide Richtungen scrollen, Suchaliase/Equipmentfilter, Daten nach Reload unverändert. |
| Navigation und Bewegung | Beide Engines: sechs schnelle Detailwechsel, Zurück schließt die Ebene, Sheet am Griff herunterziehen, kein hängender Scroll-Lock; Glass Pill direkt ziehen, zehn Tabwechsel, aktive Auswahl, reduzierte Bewegung, hell/dunkel, manuelle Update-Prüfung. |
| Layout | 320 × 568 und 390 × 844, Desktop 1440 × 1000: kein horizontaler Dokumentüberlauf; bei 320 px liegen alle Satzfelder und Abschlusstasten innerhalb ihrer Karte. Screenshots visuell geprüft. |
| Echtes PWA-Update | Chromium: Produktionsdateien 1.3.2 durch 1.4.0 ersetzt, wartenden Service Worker über die App aktiviert. Workouts mit Satz-/ROM-/Tempo-/Pausendaten, Pläne mit Satzvorgaben, eigene Übungen, Gewicht, Favoriten, Einstellungen und Video-Metadaten exakt vor/nach Update verglichen. Altes Backup importierbar; neue Version offline erreichbar. |
| Videooberfläche | Chromium, synthetischer 4-s-WebM-Clip: Upload, drei manuelle Markierungen, acht schnelle Speicherklicks erzeugen genau einen Datensatz, nach Reload erhalten. Defekte MP4-Datei verständlich abgewiesen. Kontrollierter Worker prüft sofortigen Abbruch und Modellfehler ohne erfundene Ergebnisse. |
| Produktion | Statischer Build und PWA-Artefaktprüfung erfolgreich. Relative Pfade, Manifest, Icons, eigene Cachegrenze und Offline-Navigation geprüft. Keine Sites- oder Backend-Abhängigkeit im Kern. |

Keine JavaScript-Laufzeitfehler in den bestandenen Abläufen. Die Kernprüfung ohne automatische Videoanalyse erzeugte keine externen Netzabrufe.

### Reproduzieren

```sh
npm ci
npm run verify
npx playwright install --with-deps chromium webkit
npm run test:browser
npm run test:refinement
FORMA_ENGINE=webkit npm run test:refinement
npm run test:update
FORMA_PREVIOUS_BUILD=/pfad/zum/entpackten/1.3.2-build npm run test:update
node scripts/test-video-ui.mjs
```

Die Video-UI-Prüfung benötigt FFmpeg mit VP8-Encoder. Sie lädt bewusst kein Pose-Modell: der Worker wird nur für deterministische Fehler-/Abbruchantworten ersetzt. Das Testvideo enthält keine Person. Eine erfolgreiche Oberfläche ist deshalb kein Nachweis biomechanischer Genauigkeit. H.264- oder HEVC-Unterstützung auf einem iPhone wurde nicht mit diesem Linux-Test gemessen.

Linux-WebKit ist keine iOS-Safari-Freigabe. Home-Bildschirm-Installation, echtes iPhone mit Notch/Dynamic Island, native Tastatur, Touchgefühl/Bildrate, VoiceOver, Hintergrundtimer, mehrere gleichzeitig geöffnete PWA-Instanzen und iOS-Speicherdruck bleiben auf Hardware zu prüfen. Keine formale Vollabdeckung jeder Kombination und keine Garantie gegen Betriebssystem-Speicherbereinigung. Die weiter unten stehende iPhone-Checkliste dient dazu.

Die folgenden Protokolle beschreiben historische Versionen und werden nicht rückwirkend als aktuelle Hardwaretests ausgegeben.

## Geräteauswahl und Update 1.3.2 (05.10.2026)

- TypeScript, Produktionsbuild, PWA-Artefaktprüfung und alle **79 automatischen Tests erfolgreich**. Neue Prüfungen betreffen Suchaliase, getrennte eGym-/Griffvarianten, Planvorgaben im Backup und fehlende Referenz-/1RM-/Laststeigerungswerte bei elektronischen Geräten.
- Formular in Chromium und WebKit bei 390 × 844 sowie 320 × 568 geprüft: native Geräte-, Muskel- und Messartauswahl, Scrollbereich nach unten und oben, keine zusätzlichen Auswahl-Portale und kein horizontaler Überlauf. Eigene eGym-Übung speichern, neu laden und per JSON unverändert exportieren. Suchbegriffe für Überkopf-Trizeps und Reverse Preacher Curls sowie Gerätefilter erfolgreich.
- Den vollständigen Chromium-Test für Workout, einzelne Satzwerte, RIR, Timer, JSON-Import/-Export/-Rücknahme, Browserneustart, Offlinebetrieb und Desktop erneut erfolgreich ausgeführt.
- Echter Service-Worker-Versionswechsel im Browser: alten Produktionsbuild 1.3.1 geöffnet, Testplan mit individuellen Satzvorgaben und Gewichtseintrag gespeichert, Serverdateien auf 1.3.2 gewechselt und „Jetzt aktualisieren“ verwendet. Plan, Vorgaben, Gewichtseintrag und Notizen blieben erhalten. Anschließend Backup aus 1.3.1 importiert und neue Version offline geöffnet. Ausschließlich künstliche Testdaten; keine persönlichen Daten verwendet.
- Der öffentliche Trackby-Workflow wurde gelesen: Er entpackt bei jedem Push `Forma-GitHub-Pages.zip` und veröffentlicht den Inhalt. Das neue Paket muss vom Nutzer dort hochgeladen werden; keine Veröffentlichung durch diesen lokalen Test.

Reproduzieren (nach Installation der Testbrowser und ihrer Systembibliotheken):

```sh
npm run verify
npm run test:browser
node scripts/test-exercise-update.mjs
FORMA_PREVIOUS_BUILD=/pfad/zum/entpackten/alten/build node scripts/test-exercise-update.mjs
```

**Grenzen:** Linux-WebKit ist kein physisches iPhone. Der native iOS-Auswahldialog, reale Touch-Bildrate, Tastatur, Home-Bildschirm-Installation und iOS-Speicherbereinigung wurden nicht auf Hardware gemessen. Die geänderte Auswahl vermeidet das verschachtelte Scrollmenü; das Scrollgefühl muss auf dem Gerät bestätigt werden. Frühere Protokolle unten beschreiben ihren damaligen Stand.

## Standalone-Export 1.3.1 (01.10.2026)

- Saubere Installation aus dem enthaltenen npm-Lockfile erfolgreich. Kein Sites-/Next-/Vinext-Server oder privater Paketserver erforderlich.
- TypeScript-Prüfung und **76 automatische Tests erfolgreich**. Zehn zusätzliche Tests verwenden fake-indexeddb für echte IndexedDB-Transaktionsabläufe: neu öffnen, parallele Eingaben, abgewiesene Änderungen, Backup/Import/Rücknahme, getrennte Demo-Daten, Projektpfade und beschädigte gespeicherte Daten. Das Testdouble ersetzt keine Prüfung der Speicherung auf Datenträger.
- Produktionsbuild und Service-Worker-Prüfung erfolgreich: Root-Pfad, `/forma/`, verschachtelter Projektpfad, Cache-Bereinigung nur für das eigene Projekt, keine Navigation außerhalb des Scopes umgeleitet.
- **Zusätzlicher echter Chromium-Browsertest mit persistentem Profil**, mobilem Viewport 390 × 844 und Desktop 1440 × 1000: Erststart; Körpergewicht speichern; Workout starten; Übung suchen; zwei verschiedene Satzgewichte und Wiederholungen, RIR, Abschluss, Timer; aktives Workout nach Reload; Workout abschließen; JSON-Datei herunterladen und Inhalte prüfen; vollständiger Import einschließlich eigener Übungen, Satzvorgaben, Plänen, Gewicht, Einstellungen und Video-Metadaten; fehlerhafte Datei abweisen; Import zurücknehmen; Browserprozess schließen; denselben Profilordner offline wieder öffnen; alle Daten erneut als JSON vergleichen.
- Fortschrittsseite, Übungsbibliothek und Video-Oberfläche offline geöffnet. Getrennte Daten unter `/zweite-app/`; identische Daten unter `/forma/` und `/forma/index.html`. Kein horizontaler Überlauf in beiden geprüften Breiten. Keine JavaScript-Laufzeitfehler und keine externen Netzabrufe im geprüften Kernablauf.
- Testdaten waren künstliche QA-Einträge in einem temporären Profil. Die vorhandene veröffentlichte Website und ihre Nutzerdaten wurden nicht verändert.

Reproduzieren:

```sh
npm ci
npm run verify
npx playwright install chromium
npm run test:browser
```

Der Browsertest startet seinen lokalen statischen Server selbst, verwendet ausschließlich `dist/`, räumt sein Profil auf und schreibt Bericht/Screenshots nach `test-results/`. Diese temporären Dateien gehören nicht zum Export. Unter Linux können Browser-Systembibliotheken erforderlich sein (`npx playwright install-deps chromium`).

**Offen:** echter iPhone-/Safari-Test, Installation auf dem Home-Bildschirm, iOS-Speicherdruck und Hintergrundtimer, VoiceOver, Posequalität auf echten Trainingsaufnahmen. Ein WebKit-Start war hier wegen fehlender Systembibliotheken nicht verfügbar; es wird kein Safari-Test behauptet. Der automatische Modelldownload ist nicht Teil des Offline-Kerns. Die folgenden Abschnitte sind die historischen Testprotokolle der übernommenen App-Versionen.


## Ergänzung: Bibliothek und Leistungsvergleich 1.3 (30.09.2026)

66 automatische Tests erfolgreich, Typprüfung erfolgreich. Neue Prüfungen: 275 eindeutige Übungen und gültige Muskel-/Geräte-/Bewegungsdaten, Körpergewichts-/Zeit-/Unterstützungsmodi, deutsche/englische Varianten- und Kürzelsuche, unvermischt erhaltene Deadlift-Historien und Backups. Vergleich: Quellenanker und Tabellenzuordnung, Alters-/Gewichtsklassengrenzen, Jugendliche, nicht vorhandene oder widersprüchliche Referenzen, Trainingserfahrungsfilter, Ausschluss unpassender Übungsvarianten, Epley-/RIR-/RPE-Grenzen, keine künstlich präzisen Ränge und zeitlich passende Körpergewichtseinträge.

Die neue Vergleichskomponente wurde außerdem als SSR-Bundle gerendert: Übung, Eingaben, Quelleninformation und der Zustand einer nicht unterstützten Variante erscheinen ohne Renderfehler. Das ist kein Nachweis interaktiver Bedienung oder mobilen Layouts.

Die Referenzdaten werden reproduzierbar aus dem Original-PDF extrahiert; Gruppen- und Spaltenstruktur sowie ausgewählte Ankerwerte geprüft. Die publizierten Stichprobengrößen wurden zwischen Alters- und Gewichtstabellen abgeglichen und widersprüchliche Alterszellen ausgeschlossen. Keine eigenmächtige Zahlenkorrektur. Auswahl und Limits stehen in COMPARISON_METHOD.md.

Ein echter iPhone-/Safari-Test dieser Erweiterung ist noch offen. Die früheren Browserprüfungen unten belegen nicht die neue Vergleichsansicht. Auf dem iPhone prüfen: Suche „Sumo“, „Stiff Leg“, „Hex Bar“, „Smith RDL“; Übung zum Workout hinzufügen und getrennte Sätze speichern; „Mehr → Leistungsvergleich“ öffnen; Langhantel-Bankdrücken männlich, Alter 17 mit passendem vorhandenen Satz und Körpergewicht auswählen; grobe Jugendreferenz prüfen. Maschine, gleiche Trainingsjahre oder gemeinsamer Alter-/Gewichtsfilter müssen eine begründete Meldung ohne erfundene Perzentile liefern. Wechsel kg/lb sowie hell/dunkel prüfen. Ein tatsächlicher Maximalversuch ist für diese Abnahme nicht nötig.

## Ergänzung: Satzvorgaben 1.2 (30.09.2026)

56 automatische Tests erfolgreich, darunter fünf neue Prüfungen für individuelle Satzwerte, feldweise Übernahme aus der Historie, explizite 0 kg, unabhängige Satzdaten, Vergrößern/Verkleinern der Satzanzahl, Datenmigration 2 → 3, kg/lb, JSON-Roundtrip und Workout-Übernahme als Plan. Typprüfung erfolgreich. Der direkte Aufruf `node .test-build/core.test.js` zeigt alle 56 Fälle; der übergeordnete Node-Testlauf fasst die Datei in dieser Umgebung als einen Test zusammen.

Die neue Oberfläche wurde noch nicht auf einem echten iPhone oder im Browser geprüft. Die bisherigen Browserprüfungen weiter unten beziehen sich auf frühere Versionen. Zusätzlich auf dem iPhone prüfen: Plan bearbeiten → pro Satz unterschiedliche Werte eingeben → Plan speichern und wieder öffnen → starten → einen Satz ändern und abschließen → App neu öffnen. Leere Planfelder sollen historische Werte übernehmen; feste Vorgaben haben Vorrang.

Stand 28.09.2026. Browserprüfungen vom 24.09.2026 und für Fortschritt 1.1 vom 28.09.2026. Keine Behauptung einer vollständigen Gerätefreigabe.

## Automatisch ausgeführt

`pnpm typecheck`: erfolgreich. `pnpm test`: 51 Tests erfolgreich, darunter 20 Fortschrittstests und 6 Prüfungen der erweiterten Übungsbibliothek. Regeln prüfen insbesondere fehlende Daten, Beschwerden/Krankheit/Tagesform, Trainingserfahrung, ausbleibende Laststeigerung bei 10/10/9, RIR/RPE, zu große Lastsprünge, Warm-up-Ausschluss, Technikwechsel, aktive Wiederaufnahme, Pausen/Supersätze, Plateau versus mehr Reserve, Trainingspause, Epley-Grenzen, PRs, Importvalidierung, kg/lb und synthetische Videozyklen/Fehlerfälle.

Bibliothek 1.1.1: enge/breite Rudervarianten und Muskelzuordnung; deutsche/englische Suchbegriffe, beliebige Wortreihenfolge, Umlaute und T-Bar-Schreibweisen; eigene Übungen ohne Suchaliase; verlustfreier Backup-/Import-Roundtrip mit bisherigen und neuen Übungen, Plänen, Favoriten und Notizen. Vorherige Satzwerte, Historie, PRs und Coaching wurden auf Trennung der Griffvarianten geprüft. Diese Ergänzung wurde nicht erneut auf einem echten iPhone oder im Browser getestet.

Neue Prüfungen: Datenmigration 1 → 2, Gewicht im Backup-Roundtrip, ungültige/doppelte Einträge, Kalendertage und Sommerzeit, Monatsenden, eigene Zeiträume, einzelner Gewichtspunkt ohne Trend, Tagesmediane, getrennte Messwochen, Mindestdaten für Prozentwerte, Gewicht-/Wiederholungsvergleich, einzelne schlechte Einheit versus anhaltender Rückgang, Pausen-/Technik-/Satzkontext, Reserve, gleiche Last bei Wiederholungsvergleichen, ungeeignete Lastmodi, Planfilter und genaue Rekordsätze.

`node scripts/check-pwa.mjs` nach Build prüft Manifest, Icons, Cachedateien und Offline-Navigation/Chunks in einer simulierten Service-Worker-Umgebung. Das ist kein echter Browser-Offline- oder iOS-Installationsnachweis.

## Browserprüfung

Der Produktionsbuild vom 28.09.2026 ist erfolgreich. Die PWA-Artefaktprüfung findet 33 lokale Cachedateien einschließlich Fortschrittscode und Dokumentation; Navigation und App-Chunks sind aus dem simulierten Offline-Cache lesbar.

Durchgeführt in Chrome mit betreuter Entwicklungs-Vorschau. Nur eigens angelegte Testdaten, keine importierten Nutzerdaten. Visuell geprüft: Desktop, 390-Pixel-Mobilansicht im eingebetteten Viewport. Diese Mobilansicht emuliert weder iOS noch dessen Tastatur oder Speicherregeln.

Beobachtet: erstes Öffnen, freies Workout, Übungssuche nach englischem Begriff „Smith“, Übung hinzufügen, Gewicht/Wiederholungen/RIR ändern, Satz abschließen, Timer und Wiederaufnahme nach Neuladen, letzten Satz übernehmen, Satzstart markieren, weitere Sätze abschließen, Workout beenden, offene Sätze korrekt getrennt, Historie mit 70 kg × 9 und 1.260 kg Lastvolumen aus zwei erledigten Sätzen. Zusätzlich beobachtet: Workout als Plan speichern, Plan umbenennen, Latzug hinzufügen und umsortieren, gespeicherten Plan öffnen; JSON-Export mit anschließend validierter Datei; Demo-Modus, mobiles Push-Workout mit vorherigen Leistungen, Satzerfassung und Timer; Desktop-Statistiken mit Balken- und Liniendiagramm sowie Bestwerten. Der Dateiauswahl-Dialog für den Import wurde geöffnet; der vollständige Importablauf wurde im Browser noch nicht bestätigt. Backup-Parsing und Validierung sind durch automatisierte Tests abgedeckt.

Behobene Befunde: UUID-Erzeugung brauchte eine getRandomValues-Alternative für die HTTP-Vorschau; 1,25-Schritte wurden anfangs auf 1,3 gerundet; ungültige Modellversion 0.10.22 auf tatsächlich erreichbare 0.10.21 geändert; manuell eingetragene Satzpause wird beim Abschluss erhalten; neue Vergleichskontexte unterbrechen die Progressionshistorie; Speicherfehler zeigen keinen Erfolgstatus; Service Worker unterscheidet App-Navigation von Dokument- und ZIP-Downloads.

Fortschritt 1.1 im Browser am 28.09.2026: Gewicht mit Dezimalkomma gespeichert, Seite neu geladen und denselben Eintrag wieder geöffnet; Diagrammpunkt ausgewählt, Gewicht bearbeitet und gespeichert; einzelner Wert ohne Trend, Tagesfilter mit Datumseingabe per Tastatur und leerem Vortag; Beispielverläufe, Sortierung, englische Suche „Smith“, Übungsdetails, genauer Datenpunkt mit RIR/Pause, Wechsel zu Trainingsvolumen, Wochenansicht mit einem Workout, mobile Favoritenänderung. Bei 390 Pixel breitem Iframe (375 Pixel Nutzbreite wegen Scrollbar) weder auf Startseite noch Übungsdetails horizontales Überlaufen. Screenshots zeigen Beispieldaten. Native Datumseingabe reagierte auf Tastatur; programmatisches Befüllen allein löste in der Browser-Testumgebung keine Änderung aus. Der erneute Downloadversuch im Iframe wurde ausgelöst, die Testverbindung lief beim Warten auf das Downloadereignis in ein Timeout; daher kein zusätzlicher Browsernachweis für Backup-Restore. Die neuen Formate sind automatisch geprüft.

## Noch nicht auf realer Hardware bestätigt

- Safari/iPhone/iPad, tatsächliche Home-Bildschirm-Installation und Splashscreen.
- Echter Offline-Kaltstart unter HTTPS, Update bei mehreren offenen PWA-Instanzen und iOS-Speicherdruck.
- iOS-Tastatur, VoiceOver, Vibration/Ton nach Sperren des Bildschirms.
- Belastbarer Pose-/Wiederholungsbenchmark auf echten Trainingsvideos, unterschiedliche Kleidung, Licht, Verdeckungen und Kamerawinkel.
- Mehrjährige Datenbestände und Browserquoten; Absturz genau während eines Schreibvorgangs.
- Vollständiger Accessibility-Audit, unabhängige anatomische und trainingswissenschaftliche Fachprüfung.

## Reproduzierbare iPhone-Abnahme

1. Auf finalem HTTPS-Link installieren; Home-Bildschirm-App mit Internet starten. Unter Mehr Offlinebereitschaft abwarten.
2. Freies Testworkout → Übung hinzufügen → zwei Sätze erfassen; zwischen den Sätzen App schließen/öffnen. Werte und Timerdeadline müssen erhalten bleiben.
3. Flugmodus aktivieren, App vollständig schließen, neu öffnen, Satz ergänzen und beenden. Historie und Charts prüfen. Flugmodus wieder ausschalten.
4. Neues Template erstellen, zwei Übungen hinzufügen, mit Pfeilen sortieren, eine entfernen; speichern und starten. Früheren Workout als Template sichern und erneut starten.
5. JSON exportieren, Datei prüfen, testweise importieren; Vorschau und Bestätigung beachten. Rücknahme prüfen. Nicht mit ungesicherten echten Daten experimentieren.
6. Helles/dunkles Theme, kg/lb, optional RPE, Satztypen, Timer +30 s und „Reduce Motion“ prüfen.
7. Kurzes seitliches MP4 auswählen, Modell bewusst laden, Ausgabe mit manuell gezählten Wiederholungen vergleichen. Ungeeignete Aufnahme muss Unsicherheit/Fehler zeigen. Abbruch und manuelle Markierung prüfen.
8. Erst nach erfolgreichen Checks die persönliche Alltagsnutzung mit regelmäßigen Backups beginnen.

Offene Punkte sind explizite Grenzen der Abnahme und werden nicht als bestandene Tests ausgegeben.
