# Prüfung 1.17.0 · 23.10.2026

Zwei neue Renderregressionen prüfen, ob die Vorschau Kartenauswahl, Reihenfolge, ausgeblendete Karten, eigene Namen mit sicherer Textdarstellung, Akzente, Einheiten, gespeicherte Pause, Fokus, Bereichsreihenfolge und gewählte Satzfelder korrekt abbildet. Der Entwurf bleibt beim Rendern unverändert, Pflichtaktionen erscheinen auch ohne Karten. Die bestehende Trainingsprüfung erwartet jetzt keine Bewegungszeichnung; der Test des entfernten Zeichnungsbausteins entfällt. Aus 335 Tests werden damit 336 je Plattform.

Ausgeführte Typ-, Test-, Build-, Startpfad-, PWA- und Paketprüfungen stehen in `RELEASE_VALIDATION.json`. Browserprüfung bleibt nach der zuvor beobachteten Sicherheitsblockade nicht verfügbar; keine Umgehung und kein echter Handytest. Serverseitige Renderprüfungen ersetzen keine Sichtprüfung oder Prüfung der Dialogbedienung.

Am Handy noch prüfen: Layout bearbeiten → Vorlagen → Startseite/Workout wechseln → alle drei Beispiele groß ansehen → zusätzliche Satzangaben aufklappen → zurück → Vorlage übernehmen → anpassen → speichern. Eigene Vorlage anlegen und wieder öffnen; für einen Plan nur dessen Workout-Ansicht übernehmen. Bei schmalem Bildschirm und großer Schrift müssen Vorschautexte, Gewichte, Übernehmen und Layout speichern erreichbar bleiben. Prüfen, dass reine Vorschauaktionen keine Trainingswerte ändern und die Liste ohne Bewegungszeichnungen klar lesbar bleibt.

# Prüfung 1.16.0 · 23.10.2026

14 neue Regressionen ergänzen die bisherigen 321 Tests. Sie decken doppelte bzw. verspätete Abschlussaktionen, alte Wiederöffnen-Aktionen nach erneutem Abschluss, ältere Sätze bei neuer laufender Pause, verlängerte und zeitlich mehrdeutige Timer, Rückgängig mit parallelen Feldänderungen, spätere Abschlüsse, gelöschte/beendete Workouts, ausgeschaltete Timerautomatik, erneutes Speichern nach Fehler, Übungsreihenfolge, Fokusansicht und dauerhaftes Speichern mit JSON-Roundtrip ab.

Die ausgeführten Ergebnisse stehen in `RELEASE_VALIDATION.json`. Der Sprung wird über Auswahl- und Renderprüfungen abgesichert; die tatsächlichen Touch-, Scroll- und Fokusabläufe wurden hier nicht in einem Browser oder auf einem Handy geprüft. Die bereits bekannte Browser-Sperre wurde nicht umgangen.

Am Gerät prüfen: Satz abhaken → Rückgängig → Werte noch vorhanden; zwei Sätze nacheinander abhaken → älteren Satz wieder öffnen → neuere Pause läuft weiter. +30s und anschließend Rückgängig sollen den verlängerten Countdown erhalten. Einen Haken schnell doppelt antippen; der Satz soll abgehakt bleiben. In einem längeren Workout „Nächster offener Satz“ drücken und die Fokusansicht verlassen/erneut öffnen. Bildschirmtastatur soll beim Sprung geschlossen bleiben. Die nächsten Sätze verwenden weiter deine gespeicherte Pausendauer.

# Prüfung 1.15.0 · 22.10.2026

13 neue Regressionen ergänzen die bisherigen 308 Tests: Bildschirm-Wachhaltung nur bei aktivem sichtbarem Timer, normale Freigabe, verspätete Zusage nach Abbruch, Betriebssystemfreigabe und erneute Anfrage, Ablehnung, atomare Einstellungsänderung einschließlich Konflikten und Validierung, Neustart/JSON/Cloud-Payload/Alt-Tab/Import-Rücknahme. Hinzu kommen synthetische Kamera-Geometrie samt Spiegelung und Bildformat, Unsicherheit bei fehlenden/wechselnden Daten, bevorzugte Körperseite mit Fallback, eingeschränkte Hinweise bei Widerspruch sowie Wert-/Zeitabbildung und Grenzfälle des kleinen Gewichtsdiagramms.

`node scripts/audit-startup.mjs` und zusätzlich `--android` bauen ohne Ausgabeordner und prüfen die tatsächlich enthaltenen Module des Startpfads einschließlich Heute-Fortschritt. Recharts, cmdk und Floating-UI dürfen dort nicht enthalten sein. Messergebnisse: `benchmarks/startup-1.15.0-ios.json` und `-android.json`. Keine echte Startzeitmessung; die PWA lädt Offline-Dateien weiterhin im Hintergrund.

Die ausgeführten Plattform-, Typ-, Build-, PWA- und Video-Asset-Prüfungen stehen in `RELEASE_VALIDATION.json`. Eine Browserprüfung wurde versucht, konnte aber wegen einer Sicherheitsrichtlinie nicht durchgeführt werden. Kein erfolgreicher interaktiver Browserlauf, kein echter iPhone-/Android-Test und keine Validierung des Kamerachecks mit realen Videos. Die Bildschirm-API wurde mit kontrollierten Testobjekten geprüft, nicht am Betriebssystem.

Am Gerät noch prüfen: Display-Option speichern → Satz abhaken → Anzeige bleibt während der Pause an → App wechseln und zurückkehren → Pause beenden → normale automatische Displaysperre wieder möglich. Energiesparmodus und API-Ablehnung testen. Sperrbildschirmalarm nicht erwarten. Gewicht erfassen, Detaildiagramm öffnen und Messpunkt bearbeiten; bei Kamera links/rechts die Seite manuell prüfen und die Zählung am Original vergleichen. Anschließend offline neu öffnen und gespeicherte Timer-/Layoutwerte prüfen.

# Prüfung 1.14.0 · 21.10.2026

Elf neue Regressionen ergänzen die bisherigen 297 Tests. Geprüft werden Eingabegrenzen, dauerhaftes Speichern nach Neustart, JSON-/Cloud-Payload, Schreiben durch ältere Tabs, Import/Rücknahme/Reset, atomare Fehlerbehandlung, konkurrierende Änderungen, Nutzung in alten und neuen Workouts, laufende Timeraktionen, Hintergrundwechsel und zugängliche Beschriftungen.

Die Ergebnisse für beide Plattformen stehen im aktuellen `RELEASE_VALIDATION.json`. Keine interaktive Browser- oder echte Handyprüfung dieser Überarbeitung. Am Gerät prüfen: Pause: 3:00 öffnen → 2:30 speichern → Satz abhaken → App neu öffnen → nächster Satz startet erneut bei 2:30. Danach auf 3:00 zurückstellen. +30s soll die gespeicherte Standarddauer nicht ändern; beim Wechsel zurück zur App soll ein inzwischen abgelaufener Timer erkannt werden.

# Prüfung 1.13.0 · 21.10.2026

Neun neue Regressionen ergänzen die bisherigen 288 Tests: alte und neue Pläne, Backup-Import, neue volle Pausen nach jedem Satz und Übungswechsel, unveränderte historische und gemessene Pausen, Wiederöffnen, ausgeschaltete Automatik, ungültige oder abgeschlossene Sätze sowie zugängliche reduzierte Eingabe, kg/lb-Darstellung, Zeitübungen und Bewegungssymbole.

Ergebnisse der Plattform-Builds und automatisierten Logik-, Speicher-, Render- und PWA-Prüfungen stehen in `RELEASE_VALIDATION.json`. Die Illustration ist ein schematisches Bewegungssymbol, keine vollständige Ausführungsanleitung. Es gab keinen interaktiven Browser- oder echten Handytest dieser Überarbeitung.

Am Gerät gezielt prüfen: in einem älteren Plan einen Satz abhaken → 3:00; weitere Übung abhaken → erneut 3:00; „Weitere Satzangaben“ und „Mit + / − anpassen“ öffnen; 82,5 kg mit großer Schrift eingeben; nach App-Update offline neu öffnen. Ein zuvor gestarteter Timer wird durch das Update nicht zurückgesetzt.

# Prüfung 1.12.0 · 21.10.2026

15 neue Regressionen ergänzen die bisherigen 273 Tests. Sie prüfen Gewichtsschritte und lb-Auswahl, schnelle Mehrfachtipps nach einer manuellen Eingabe, Wertebereiche und unveränderte Zusatzdaten, Zeitübungen, veraltete Aktionen, gleiche Satztypen beim Kopieren, geschütztes Rückgängig und zugängliche Beschriftungen. Dazu kommen gezielte Prüfungen der Ersteinrichtung einschließlich paralleler Änderungen, Alt-Tab/Neustart/Backup/Import-Rücknahme sowie des Wochenvergleichs bei Zeitumstellungen, offenen Einheiten und fehlenden Daten.

Die ausführbaren Ergebnisse für beide Plattformen sowie Build-, PWA- und Video-Asset-Prüfungen stehen im aktuellen `RELEASE_VALIDATION.json`. Alle Tests verwenden synthetische Daten. Es gab keinen echten Browser-/Handytest der neuen Oberfläche. Am Gerät gezielt prüfen: Gewicht direkt eingeben und danach mehrmals Plus tippen; Schritt ändern; Werte übernehmen und rückgängig machen; Satz abschließen; eine Zeitübung erfassen; Ersteinrichtung abbrechen und speichern; App offline erneut öffnen. Bei großer Schrift und geöffneter Tastatur auf Erreichbarkeit der Tasten achten.

# Prüfung 1.11.0 · 21.10.2026

Typprüfung und je 273 automatisierte Tests in iOS-/Android-Konfiguration bestanden, ohne übersprungene Tests. Acht neue Regressionen ergänzen die bisherigen 265: validierte Kartennamen und Akzente, sichere Textdarstellung, vererbte und unabhängige Planansichten, scoped Vorlagen, Kopieren/Löschen/Wiederholen von Plänen, gerenderte Workout-Ansicht, Schreiben durch einen simulierten 1.10-Tab sowie Neustart/Backup/Import-Rücknahme und explizites Zurücksetzen.

Unveränderter Ausgangscode 1.9.3 erneut gebaut: alle 114 App-Dateien sind bytegleich mit der ursprünglich gelieferten GitHub-Pages-ZIP. Die zwei zusätzlichen ZIP-Dateien README und SHA256SUMS gehören zur Verpackung. Details: `benchmarks/source-provenance-193.json`.

Build- und PWA-Prüfungen, Paketintegrität sowie Video-Asset-Prüfungen sind im aktuellen `RELEASE_VALIDATION.json` dokumentiert. Kein echter Browser-/Handytest der neuen Oberfläche. Am Gerät noch prüfen: einen Kartennamen und Akzent speichern, bei zwei Plänen unterschiedliche Satzfelder einstellen, beide starten, App neu öffnen und eine Planansicht wieder auf das allgemeine Layout zurückstellen. Freies Workout soll weiterhin das allgemeine Layout verwenden.

# Prüfung 1.10.0 · 21.10.2026

Ausgangsstand 1.9.3: Typprüfung und 250 Tests bestanden. 15 neue Regressionen prüfen Layout-Vorlagen, valide Grenzen, Datenbestand bei parallelen Satzeingaben, Konflikte zwischen Layout-Editoren, alte Tabs, Neustart/JSON-Roundtrip, Import-Rücknahme, Sperre mehrfacher Bestätigung, erneuten Versuch nach Fehlern und Erreichbarkeit von Trainingsaktionen bei ausgeblendeten Feldern. Tests verwenden synthetische Daten.

Ergebnis: Typprüfung, jeweils 265 Tests für iPhone/Android, beide Produktionsbuilds, PWA-/Reparaturprüfungen und Video-Asset-Integrität bestanden. Details stehen in `RELEASE_VALIDATION.json`. Prüfung im echten Browser und auf einem Handy ist für diese Überarbeitung nicht verfügbar. Auf dem Gerät gezielt: Heute → Layout bearbeiten → Kalender nach oben ziehen → ausblenden → speichern → App neu öffnen; Workout-Felder wählen; Vorlage anlegen und erneut laden; Schließen eines geänderten Entwurfs; schmale Anzeige mit Tastatur und großer Schrift.

# Regression 1.9.3 · 20.10.2026

Ausgangsstand: 230 bestandene Tests. Danach: je **250 bestandene Tests in iOS- und Android-Konfiguration, 0 Fehler**. 20 neue gezielte Prüfungen ergänzen:

- Korrigierte Anzahl/Dauer unabhängig von unveränderten Rohzyklen und Technikhinweisen; Nullzählung ohne erfundene Dauer.
- Ungültige, fehlende, überlappende und außerhalb des Ausschnitts liegende Zeiten; Dezimalkomma und Sortierung eingefügter Wiederholungen.
- Synchroner Eingabesnapshot ohne Blur, parallele/nachlaufende Doppeltipps, Speicherfehler und erneuter Versuch.
- Neue Analyse genau einmal speichern; neuere Notizen erhalten; gelöschte oder parallel korrigierte Datensätze nicht überschreiben.
- JSON, IndexedDB-Neustart, Sicherungsstand, Import/Rücknahme, ältere Tabs und explizites Zurücksetzen einschließlich Sidecar.
- Korrigierte und automatische Auswertungen nicht in einem scheinbar vergleichbaren Videovergleich vermischen.
- Nachladen dedupliziert parallele Navigation und erlaubt Wiederholung nach Ladefehler.
- Serverseitig gerenderte Korrektur- und Eingabeelemente für beide Plattformkonfigurationen.

Zusätzlich: externe Zählprüfung auf 38 annotierten Sätzen, siehe VIDEO_BENCHMARK.md. Die Zählqualität wird nicht als bestanden/fehlerfrei bezeichnet. Bundle-Größen sind durch zwei Builds mit demselben lokalen Compiler gemessen; Berichte in `benchmarks/startup-192.json` und `startup-193.json`. Diese Zahlen sind keine Geräte-Zeitmessung. Modell-/WASM-Hashes, Produktions-Builds, PWA-Artefakte, statische Importpfade, ZIP-Integrität und unveränderte Icon-Dateien werden geprüft.

**Prüfgrenzen:** kein Browser-QA-Zugang, keine echte iPhone-/Android-Interaktion, keine PWA-Installation, VoiceOver/TalkBack oder Videodecodierung auf einem Gerät. Am Gerät nach Update prüfen: Satz analysieren; falsche Wdh. entfernen; mit pausiertem Video Start/Ende „Hier“ setzen; einmal speichern; Original ansehen; erneut öffnen; korrigierte Zählung prüfen. Danach Reset und einen kurzen Offline-Workout-Durchlauf prüfen. Bestehende automatisierte Trainings-/PR-/Fortschritts-/Backup-Tests bleiben unverändert aktiv. Verbindliche ausgeführte Ergebnisse: RELEASE_VALIDATION.json im Quellpaket.

---

# Regression 1.9.2 · 19.10.2026

Ausgangsstand: 219 bestandene Tests. Die neue Testsuite enthält 11 zusätzliche gezielte Prüfungen (230 insgesamt je Plattform):

- Erster Submit liest den vollständigen aktuellen Entwurf ohne Blur, einschließlich Pause, Satzanzahl, RIR, Wiederholungszielen, Technik, Supersatz, Schmerzangabe und Notiz.
- Allein geänderte Pause/Notiz bei unveränderter Satzzahl; schnelle parallele sowie nachlaufende Bestätigungen; keine Erfolgsmeldung vor Abschluss.
- Fehlgeschlagener Speicheraufruf und Exception behalten den Entwurf, sperren falsche Erfolgsmeldungen und erlauben einen erneuten Versuch.
- Keine stille Rundung oder Rücksetzung ungültiger Felder; gültige Nullwerte und Dezimalkomma.
- Neuere Satzwerte und unveränderte Felder werden nicht aus einem älteren Entwurf überschrieben. Neu begonnene Sätze blockieren unzulässige Reduktionen.
- Genau eine IndexedDB-Revision für die gemeinsame Änderung, aktualisierte Workout-Zeilen, Neustart, JSON-Roundtrip und unveränderte übrige Nutzerdaten. Vollständiger Rollback bei ungültiger Reduktion.
- Serverseitiges Rendern der einzigen Bestätigung unter allen Feldern in iOS-/Android-Konfiguration.

Die konkrete Gerätesequenz „Tippen bei geöffneter Tastatur“ ist hier nicht als Browser-/Touchtest ausgeführt worden. Die Tests rufen den tatsächlich verwendeten Submit-Controller mit einem zuletzt bearbeiteten Entwurf auf, ohne Blur auszulösen. Das prüft Speicherlogik und Reihenfolge, nicht Safari-/Chrome-Ereigniszustellung. Nach Veröffentlichung am Gerät prüfen: 3→2 offene Sätze, Pause 180, Notiz ändern, ohne vorheriges Schließen der Tastatur einmal „Alles übernehmen“; Dialog soll nach Erfolg schließen und zwei Zeilen/180s zeigen. Danach erneut öffnen, Eingaben prüfen und einen Entwurf verwerfen.

Alle vorhandenen 219 Regressionstests bleiben aktiv. TypeScript, Video-Asset-Hashes, WASM, beide Builds, PWA-/Service-Worker-Checks und ZIP-CRC/SHA-256 werden separat geprüft. Verbindliche Ergebnisse und Grenzen: RELEASE_VALIDATION.json.

---

# Regression 1.9.1 · 19.10.2026

Vor Änderungen: 194 bestandene Tests. Danach: **je 219 Tests in iOS- und Android-Konfiguration, 0 Fehler**. TypeScript ohne Fehler. Die 25 zusätzlichen Tests prüfen:

- Kameraauswahl, Perspektivmatrix, nicht abgestimmte Bewegungen und abgewandte Körperseite.
- Kürzere/längere/wechselhafte Zyklen, unauffällige Verläufe, Schwellen, geringe Abdeckung, Sichtlücken, ungültige Zeiten, fehlende Punkte, manuelle Ergebnisse.
- Vergleich mit bekannter Perspektive; alte Aufnahmen bleiben unverändert und werden nicht nachträglich umgedeutet.
- Sichtbare Erklärung und Technikhinweise, deaktivierte Wiedergabe ohne Original, beide UI-Konfigurationen über serverseitiges Rendern.
- Vollständiger JSON-Roundtrip, IndexedDB-Neustart, lokale Sicherung, Alt-Tab-Zugriff einschließlich Überschreiben des alten Personalisierungsschlüssels, Löschen, Import-Rücknahme und fehlerhafte Importmetadaten.

Alle bestehenden Workout-, Plan-, PR-, Fortschritts-, Backup-, Coach-, Navigations- und Update-Logiktests bleiben Bestandteil der Regression. Die bestehende Videovergleichs-Fixture enthält jetzt ausdrücklich eine Kameraperspektive; unbekannte Perspektiven werden separat auf Ausschluss geprüft.

Die bestehenden Modell-/WASM-Dateien wurden per SHA-256 geprüft; beide WASM-Varianten wurden technisch kompiliert. Die Produktionspakete werden mit den unten stehenden Build-, Service-Worker- und ZIP-Prüfungen validiert. Aktuelle Release-Zusammenfassung: RELEASE_VALIDATION.json im Quellpaket; Prüfsummen: SHA256SUMS.txt in jedem Paket.

**Prüfgrenzen:** Kein verfügbarer Browser-QA-Zugang in dieser Umgebung, deshalb keine echte Safari-/Chrome-Interaktion, PWA-Installation, VoiceOver/TalkBack, Touch-/Scrollprüfung oder Codec-/Kameratest. Kein Trainingseffekt und keine reale Pose-Genauigkeit gemessen. Auf einem echten Gerät nach dem Update einen kurzen bekannten Satz analysieren, Zählung am Original prüfen, Perspektive wechseln und einen gespeicherten Analyse-Eintrag nach App-Neustart öffnen.

---

# Regression 1.9.0 · 18.10.2026

Ausgangsstand: 170 bestandene Tests. Neue Regression: **je 194 bestandene Tests in iOS- und Android-Konfiguration, 0 Fehler**, einschließlich aller alten Tests, ohne entfernte Assertions. TypeScript ohne Fehler. Video-Asset-Hashes geprüft und beide WASM-Varianten kompiliert. Produktions- und ZIP-Prüfungen laufen mit den unten dokumentierten Release-Befehlen; Paketprüfsummen stehen in SHA256SUMS.txt.

24 zusätzliche Prüfungen decken ab: optionales Schema, JSON/Neustart, ungültige Einstellungen, Snapshot-Rotation, gültige Sicherungen, Revisionskonflikte, aktive Workouts, Rückfallsicherung, automatische Sicherung nach Abschluss, getrennte Demo-Daten, ältere Tabs, simulierte Snapshot-QuotaExceededError, 25 parallele Satzänderungen, individueller Gewichtsschritt, schwierige Lastsprünge, mehr Reserve, persönliche Pausen, Schmerzvorrang, Einzelwert-/Tagesmedian-Darstellung, Videovergleich, Analysegrößen, fehlende Cache-API, datensparsames Diagnoseprotokoll, Home-Reihenfolge und Workout-Fokus.

Release-Befehle:

```sh
node node_modules/typescript/bin/tsc --noEmit
node scripts/test.mjs
node scripts/test.mjs --android
node scripts/verify-video-assets.mjs
node scripts/build-pwa.mjs
node scripts/check-pwa.mjs
node scripts/build-pwa.mjs --android
node scripts/check-pwa.mjs --android
python3 scripts/package-release.py
```

Tests für iOS/Android beziehen sich auf jeweilige Build-Verzweigungen und SSR, **nicht auf echte Betriebssysteme**. PWA-Prüfungen verwenden simulierte Service-Worker-Abläufe; WASM wird technisch kompiliert, keine Echtvideo-Genauigkeit gemessen. Keine WCAG-Zertifizierung. Vor breitem Einsatz auf realen Geräten prüfen: große Schrift, VoiceOver/TalkBack, Tastatur in Satzzeilen, Sheet-Zurücknavigation, Hintergrund/Resume, Offline-Video und Filmmaterial verschiedener Kamerawinkel.

---

# Prüfung 1.8.11 · 17.10.2026

## Vorher / nachher

- Unveränderte Basis 1.8.10: TypeScript und 149 automatisierte Tests erfolgreich.
- Neue Version: TypeScript sowie **170 Tests je iOS- und Android-Konfiguration** erfolgreich.
- Bestehende Tests decken Speicherung, konkurrierende Eingaben, Workouts, Satzvorgaben, RIR/RPE, Timerwerte, Templates, Verlauf, Fortschrittsmetriken, PRs, Übungssuche, Favoriten, Körpergewicht, Backup/Restore, Cloud-Konflikte, Darstellung per SSR, Navigation und Update-Aktivierung ab. Keine Behauptung realer Touch-/Gestentests.
- 19 neue Video-Tests: beide Startpositionen, Rauschen/Ausreißer, halbe/statische Bewegungen, Sichtlücken, ungültige Zeitstempel, Seitenverhältnis, verdeckte Gelenke, feste automatische Seitenwahl, Mehrpersonen-/Abdeckungsfehler, Portrait-4K, Dateien ohne MIME, Ausschnittgrenzen, Abbruch/Neustart mit verspäteten Antworten, Worker-Fehler/Timeout, dekodierte Frames, Seek-Abbruch, späte Ressourcenfreigabe, Backup-Kompatibilität und initiales UI.
- Zwei neue Update-Tests: Download abwarten, bereit/aktuell/laufend/fehlgeschlagen auseinanderhalten.
- Modellpaket als ZIP mit zwei TFLite-Dateien und CRC geprüft. Originaldateien gegen gespeicherte SHA-256-Werte geprüft; npm-Tarball zuvor mit Registry-SHA-512 verifiziert. Beide WASM-Varianten in Node validiert und kompiliert.
- Tatsächliche gepatchte Telemetriesender-Klasse ausgeführt: keine Timer, keine Requests, keine Warteschlange. Kein vollständiger Netzwerkmitschnitt eines echten Analyse-Durchlaufs.
- Repository, Schema, Typen, Workout, Coach, Bottom Navigation und Manifest bytegleich zur Basis. Alle 189-Icondateien unverändert. Keine Datenmigration.

## Produktionsprüfung

Beide Produktionsbuilds erfolgreich. Je 95 lokale Precache-Dateien; Root- und verschachtelte Projektpfade, Referenzen, Manifest/Icon-Dateien, Offline-Navigation, frühere App-Chunks und Rettungsseite per VM geprüft. Optionales Modell nicht im Precache; erfolgreicher Abruf danach simuliert offline verfügbar. Beide WASM-Varianten validiert/kompiliert. Die normale große Hauptchunk-Warnung bleibt (~618 kB unkomprimiert / 187 kB gzip); Video-UI und SDK bleiben dynamisch geladen. Diese Warnung wurde nicht durch pauschale Bündeländerungen kaschiert.

## Prüfgrenze und Geräteabnahme

Kein unterstütztes Browser-QA-Werkzeug und keine physischen Mobilgeräte verfügbar. Daher keine aktuelle UI-/Safari-/Chrome-/PWA-Abnahme, keine HEVC-Hardwareprüfung und keine Messung der Erkennungsgenauigkeit auf echten Personen. Die Originalaufnahme des Nutzers lag nicht vor; ihr konkreter Fehler ist nicht reproduziert. Vorhandene Browser-Skripte wurden nicht ausgeführt. Frühere Protokolle weiter unten gehören zu den dort genannten älteren Versionen.

Auf beiden Plattformen nach Veröffentlichung bitte:

1. Versionsanzeige 1.8.11 und bestehende Workouts/Pläne prüfen, ohne Websitedaten zu löschen.
2. Seitlichen 10–20-s-Clip mit 4–6 deutlichen Curls wählen. Automatische Seite belassen, starten; erkannte Wiederholungen antippen und Zählung kontrollieren.
3. Analyse abbrechen und erneut starten; Optionen während des Laufs gesperrt. App kurz in Hintergrund bringen, danach erneut starten.
4. Start/Ende auswählen; Beginn/Ende der Wiederholungen beziehen sich auf diesen Ausschnitt. Formatfehler und stark verdeckte/ungeeignete Aufnahme prüfen.
5. Ergebnis speichern; Ansicht schließen, App neu öffnen. Alte und neue Analysen sowie JSON-Export/Import überprüfen.
6. Manuell markieren, letzte Markierung zurücknehmen, mehrmals schnell speichern: nur ein Datensatz.
7. Nach erfolgreicher automatischer Analyse offline wiederholen; verfügbar nur solange Browser Modellcache behält. Normales Offline-Workout separat prüfen.

Weitere Methoden, Grenzen und Primärquellen: VIDEO_ANALYSIS.md.

# Prüfung 1.8.10 · 17.10.2026

„Alles übernehmen“ ersetzt die bisherige Satzanzahl-Beschriftung. Die Bestätigung ist auch ohne geänderte Satzanzahl aktiv. Vor dem Übernehmen wird das fokussierte Eingabefeld explizit verlassen, damit die bestehenden onBlur-Speicheraktionen für Pause, Coach-Ziele und Notizen vor dem Satzabgleich eingeordnet werden. Sperre gegen Mehrfachklicks, Validierung und Schutz begonnener/abgeschlossener Sätze bleiben erhalten. Der neue untere Abschlussbutton öffnet denselben bestehenden Dialog wie „Beenden“ oben; er beendet oder speichert das Workout nicht unmittelbar.

TypeScript und alle 149 vorhandenen automatisierten Tests je Plattform bestanden. Darunter Satzanzahl-Abgleich, Schutz bestehender Sätze, parallele schnelle Änderungen, IndexedDB-Wiederöffnung und Backup. Feature-Änderungen auf Workout.tsx und WorkoutSetCount.tsx beschränkt; Speicherschicht, Schema, Berechnungen und Icons bytegleich zum Vorgänger.

Release-Abnahme: iOS- und Android-Build, PWA-/Offline-/Reparaturprüfungen und CRC/SHA-256 aller ZIP-Inhalte. Keine echten Mobilgeräte oder unterstützte Browser-Prüfung verfügbar. Neue Button-Berührungen und Tastaturverhalten sind nicht auf einem realen iPhone/Android getestet. Geräteabnahme: nur Pause auf 180 ändern und „Alles übernehmen“ antippen; Satzzahl 3→2 bei offenen Sätzen bestätigen; unten „Workout beenden“ öffnen, abbrechen und erneut öffnen, dann speichern.

---

# Prüfung 1.8.9 · 16.10.2026

Ausgeliefertes Icon enthält das Original-JPEG direkt in einer SVG-Clippingmaske, ohne generative Neuzeichnung. Positionsänderung exakt -50 px horizontal. Masterbild innen mindestens fünf Pixel vom Rand entfernt pixelgenau gegen das um 50 px versetzte Original verglichen: maximale Kanalabweichung 0. Hintergrund RGBA 0/0/0/166 (65 % Deckkraft). PNG-Alpha in regulären PWA-, Apple- und Browser-Icons geprüft. Maskierbare Android-Ausgabe deckend schwarz; Motiv innerhalb des sicheren Kreisradius von 40 %. Apple-Icon visuell geprüft.

Feature-Dateien bytegleich zu 1.8.8. Keine Speicheränderung. TypeScript und 149 Tests je Plattform erfolgreich. Release-Abnahme: beide Builds, PWA-/Offline-/Reparaturprüfungen und CRC/SHA-256 der ZIP-Inhalte. Keine echten Mobilgeräte verfügbar; Darstellung halbtransparenter Icons und Icon-Wechsel am Gerät nicht bestätigt.

---

# Prüfung 1.8.8 · 16.10.2026

Die Originaldatei stimmt bytegenau mit dem erneut hochgeladenen Nutzerbild überein. Alle sechs neuen PNG-Ausgaben stimmen pixelgenau mit der Ausgabe des unveränderten Originalbilds aus 1.8.5 überein. Apple-Touch-Icon visuell geprüft. Kein Bildgenerierungs- oder Retuscheschritt für 1.8.8. Feature-Dateien bytegleich zu 1.8.7; keine Speicher- oder Schemaänderung. TypeScript und jeweils 149 Tests für iOS und Android erfolgreich.

Release-Abnahme: beide Produktionsbuilds, PWA-/Offline-/Startreparaturprüfungen sowie ZIP-CRC und SHA-256 aller Inhalte. Keine Prüfung auf echten Mobilgeräten. Bereits installierte Icons werden vom Betriebssystem verwaltet; kein sofortiger Wechsel zugesichert. Website-Daten nicht löschen.

---

# Prüfung 1.8.7 · 16.10.2026

Icon nach links versetzt, helle Eisglas-Optik und dunkler Hintergrund. Alle Feature-Dateien bytegleich zu 1.8.6; keine Speicher- oder Schemaänderung. TypeScript und 149 automatisierte Prüfungen je Plattform erfolgreich. Apple-Touch-Icon und maskierbares Icon visuell geprüft; alle neuen PNGs dekodierbar und deckend. Sichtbares Motiv innerhalb des zentralen sicheren Kreisradius von 40 %.

Release-Abnahme: beide Produktionsbuilds, PWA-/Offline-/Startreparaturprüfungen und vollständige ZIP-CRC-/SHA-256-Prüfung. Keine echte Geräteinstallation und keine Bestätigung eines sofortigen Icon-Wechsels bei bereits installierten Apps. Website-Daten nicht löschen.

---

# Prüfung 1.8.6 · 16.10.2026

Icon-Anpassung mit dunklem Hintergrund und gläsernem Zeichen. Feature-Code bytegleich zu 1.8.5; keine Änderungen am Datenspeicher. TypeScript sowie 149 Tests je Plattform erfolgreich. Beide Produktionsbuilds und PWA-/Offline-/Reparaturprüfungen erfolgreich. PNGs dekodierbar und deckend; Apple-Touch- und maskierbares Icon visuell geprüft.

Keine echte Geräteinstallation getestet. Das Icon hat einen dunklen Hintergrund, keine Transparenz zum Home-Bildschirm. Bereits installierte Icons werden vom Betriebssystem verwaltet. Website-Daten nicht löschen.

---

# Prüfung 1.8.5 · 15.10.2026

Die Änderung betrifft ausschließlich Icon-Assets, ihre HTML-/Manifest-Verknüpfung, Versionsmetadaten und Dokumentation. Der komplette Feature-Code ist bytegleich zu 1.8.4; dessen Korrektur für Gewicht und Wiederholungen aus demselben Satz bleibt erhalten. Keine Speicher- oder Schemaänderung und kein Zugriff auf echte Nutzerdaten.

Das Originalbild ist per SHA-256 als unveränderte Kopie geprüft. Alle ausgegebenen PNGs lassen sich dekodieren, sind vollständig deckend und haben die vorgesehenen 32/64/180/192/512 Pixel. Apple-Touch-Icon und maskierbare Ausgabe wurden als Dateien visuell geprüft. Die erkennbaren Motivpixel der maskierbaren Ausgabe liegen innerhalb des sicheren Kreisradius von 40 % (gemessener maximaler Radius bei mindestens 20 Helligkeitsstufen Abstand zu Weiß: 36,62 %).

Release-Abnahme: TypeScript, bestehende 149 automatisierte Prüfungen je Plattform, beide Produktionsbuilds und PWA-/Offline-/Startreparaturprüfungen. Die PWA-Abnahme prüft jetzt auch PNG-Signatur, echte Bildmaße und Vorhandensein der verknüpften Dateien statt nur deren Namen. Beide ZIPs werden vollständig auf CRC und SHA-256 geprüft.

**Prüfgrenze:** Keine echte Installation oder Prüfung des Icon-Wechsels auf einem iPhone-/Android-Home-Bildschirm möglich. Das Betriebssystem verwaltet bestehende Verknüpfungsicons selbst; ein neues PNG und ein App-Update sind keine Garantie für einen sofortigen Wechsel. Die bisherigen Einschränkungen der Geräteabnahme gelten weiter. Keine Trainingsdaten oder Website-Daten löschen, um ein Symbol zu erneuern.

---

# Prüfung 1.8.4 · 15.10.2026

Der gemeldete Fehler wurde im Quellcode bestätigt: Die Übungsdetails berechneten höchste Last und höchste Wiederholungszahl unabhängig voneinander. Die Anzeige wählt jetzt einen vorhandenen abgeschlossenen Arbeitssatz nach höchster Last, dann höchster Wiederholungszahl bei dieser Last. Die vorhandene Übersicht bleibt erhalten; „Wdh. im selben Satz“ verdeutlicht die Zuordnung.

TypeScript sowie jeweils 149 automatisierte Prüfungen für iOS und Android bestanden. Sechs neue Regressionen prüfen den gemeldeten Fall 65 kg × 6 / 60 kg × 8, Gleichstand beim Gewicht und lb-Anzeige, unabhängige 1RM-Schätzung, Ausschluss offener Workouts/offener Sätze/anderer Übungen/Zusatzsatztypen, fehlende Daten sowie Null Zusatzgewicht und Zeitmessung. Die Tests vergleichen die gerenderte Kennzahlenansicht mit konkreten Sollwerten und prüfen, dass der gesamte synthetische Datenstand unverändert bleibt. Bestehende Speicher-, Workout-, Satz-, Plan-, Backup-, Fortschritts-, Navigations- und Updateprüfungen bleiben enthalten.

Alle bisherigen Feature-Dateien außer `Exercises.tsx` sind bytegleich zu 1.8.3. Die neue reine Anzeigekomponente enthält die Satzauswahl und Kennzahlen. Speicherschema, Datenbankkennung, Import/Export, PR- und Coachinglogik sind unverändert. Kein Zugriff auf echte Nutzerdaten. Keine Datenmigration.

Release-Abnahme: beide Produktionsbuilds, PWA-/Offline-/Reparaturprüfungen sowie CRC-Entpacktest und SHA-256-Prüfung sämtlicher ZIP-Inhalte.

**Prüfgrenze:** Kein unterstütztes Browser-QA-Werkzeug und keine echten Mobilgeräte verfügbar. Die Korrektur ist automatisiert einschließlich serverseitigem UI-Markup geprüft, nicht auf einem realen iPhone oder Android-Gerät. Zur Geräteabnahme die Übung mit 65 kg × 6 und 60 kg × 8 öffnen: erster Wert 65, daneben 6 mit „Wdh. im selben Satz“. Auf beiden Ausgaben sowie nach App-Neustart prüfen. Keine Websitedaten löschen.

---

# Prüfung 1.8.3 · 14.10.2026

Navigation wird im Handy-Querformat rechts angeordnet, weiterhin nur bei Touch-Zeigern und bis 600 CSS-Pixel Höhe. Dieselben fünf Buttons werden umgeordnet, nicht neu aufgebaut. Der Auswahlindikator nutzt die gemessene X- bzw. Y-Achse. Drehwechsel verwerfen laufende Pointer-Erfassung; bei weniger als der nötigen Mindesthöhe sind alle Einträge durch Scrollen erreichbar.

Die automatisierte Suite umfasst nun 143 Prüfungen je Plattform. Neue Regressionen prüfen alle fünf Trefferbereiche in beiden Ausrichtungen, Begrenzung über die Enden hinaus, Ziehen vorwärts/rückwärts, Achsenwechsel, Safe-Area-Offsets und noch verborgene Navigation. Bestehende Markup-, Speicher-, Satz-, Fortschritts-, Backup- und Updateprüfungen bleiben enthalten. Release-Abnahme: TypeScript, beide Testsuiten und Builds, PWA-/Offline-Prüfungen und vollständige ZIP-CRC-/SHA-256-Prüfung.

Speicher-, Schema-, Workout-, Coach-, Fortschritts-, Update- und Zeitraumcode sind bytegleich zu 1.8.2. Kein Zugriff auf echte Nutzerdaten. Keine Datenmigration.

**Prüfgrenze:** Kein unterstütztes Browser-QA-Werkzeug und keine echten Geräte verfügbar. Daher keine bestätigte visuelle/Touch-Abnahme. Am Gerät noch prüfen: 568×320, 844×390 und 932×430 px; iOS und Android; alle fünf Tabs, vertikales Ziehen auf iOS, mehrfach drehen, laufende Geste beim Drehen, Scrollen, sehr geringe Browserhöhe, Tastatur, Timer/Workout-Zugang und Updatehinweise, Reduced Motion. Hochformat und Desktop sollen ihre bisherige Navigation behalten. Die automatisierten Geometrietests ersetzen keine Prüfung der gerenderten Oberfläche.

---

# Prüfung 1.8.2 · 14.10.2026

Die gemeldeten Probleme wurden im Quellcode eingegrenzt: `PeriodPicker` erzwang auf beiden Plattformen ein Sheet; mehrere CSS-Regeln gaben der Zeitraumwahl unterschiedliche feste Breiten, während das Label wortweise umbrechen durfte. Ab 821 CSS-Pixeln wurde auch auf quer gehaltenen Handys die Desktop-Seitenleiste aktiviert. Die einzelne „4“ war ein als Einstellungen beschrifteter Profilbutton.

TypeScript und jeweils 139 automatisierte Tests für iOS und Android bestehen. Die Plattformtests prüfen native iOS-Auswahl bzw. Android-Sheet für alle acht Zeiträume, korrekt ausgewählte Werte, native Datumsfelder mit Grenzen und Beschriftung, leere Datumswerte, unveränderte Auswahl beim Umschalten sowie die fünf Haupttabs einschließlich Zuordnung von Unterseiten. Die vorhandenen Speicher-, Import-/Export-, Workout-/Satz-, Fortschritts-, Coach- und Updateprüfungen laufen weiterhin mit synthetischen Daten.

Speicherkennung, Schema, IndexedDB, Import/Export, Satzänderungslogik aus 1.8.1, Übungsbibliothek, Berechnungen, Coach und Updatecode sind unverändert. Kein Zugriff auf echte Nutzerdaten und keine Migration.

Die Release-Abnahme umfasst zusätzlich beide Produktionsbuilds, PWA-/Reparaturprüfungen, relative Assetpfade, Offline-Dateien und CRC-/SHA-256-Prüfung aller ZIP-Inhalte. Die beiden Varianten enthalten identische Funktionen und denselben Datenkern; die Auswahlkomponenten sind weiterhin plattformspezifisch.

**Prüfgrenze:** In dieser Umgebung fehlt ein unterstütztes Browser-QA-Werkzeug. Kein echter iPhone-/Android-Test und keine visuelle Vermessung; CSS-/Markup- und Buildprüfungen ersetzen diese Abnahme nicht. Am Gerät prüfen: 320/375/390/430 px, alle acht Zeiträume, Datum bei „1 Tag“ sowie „Von/Bis“, native iOS-Auswahl bzw. Android-Sheet, Hoch-/Querformatwechsel bei 844×390 und 932×430 px, alle fünf Tabs samt aktiver Markierung, Safe Areas, Scrollen, Tastatur und Updatehinweise mit Timer. Breite Inhalte dürfen Raum nutzen; die Telefon-Navigation bleibt bei Touch-Zeigern und Querformat bis 600 CSS-Pixel Höhe unten. Desktop-Einstellungen zeigen ein Zahnrad statt „4“.

---

# Prüfung 1.8.1 · 14.10.2026

Ausgangsarchive 1.8.0: Prüfsummen und vollständiger CRC-Entpacktest ohne Fehler. Der gemeldete Satzfehler wurde im Quellcode eingegrenzt: Die bisherige Änderung von `targetSets` passte die tatsächlichen `sets` nicht an. Die Hinweisposition war `top-center`.

Gezielte Regressionen prüfen 3 → 2 sichtbare Satzzeilen einschließlich Workout-Zähler, alte abweichende Zielvorgaben, Ergänzen unabhängiger Satzzeilen, geschützte begonnene/abgeschlossene Sätze, unveränderte Zusatzsatztypen, Einzelvorgaben mit 0 kg, Eingabegrenzen und unveränderte Daten bei Abweisung. Ein IndexedDB-Test kombiniert schnelle Satzänderungen mit Gewicht/Wiederholungen/RIR, erneutes Öffnen und JSON-Roundtrip; Pläne, vergangene Workouts, Körpergewicht und übrige Daten bleiben erhalten.

Abnahme: TypeScript, 136 Tests je Plattform, beide Produktionsbuilds, PWA-/Reparaturprüfungen und ZIP-Prüfsummen. Die Prüfungen verwenden synthetische Daten. Kein Zugriff auf Daten des Nutzers.

Speicherkennung, IndexedDB-Version, Schema, Import/Export, Cloud-Synchronisation, Coach und Fortschrittsberechnung bleiben unverändert gegenüber 1.8.0. Beide Ausgaben verwenden denselben Workout-Code und dieselben Prüfungen.

Prüfgrenze: Kein unterstütztes Browser-QA-Werkzeug oder echtes iPhone/Android-Gerät. Die neue Position der Meldungen wurde strukturell und anhand der vorhandenen Safe-Area-/Viewport-Regeln geprüft, nicht auf realen Geräten vermessen. Geräteabnahme: 3 Sätze auf 2 übernehmen, erhöhen, abgeschlossene Sätze schützen, App schließen/öffnen, Updatehinweis in Safari/Chrome und Home-Bildschirm-App mit/ohne Timer/Tastatur prüfen. Die allgemeine GitHub-Meldung „Something went really wrong“ ist damit nicht reproduziert oder als behoben bestätigt. Bestehende Bundle-Größenwarnung bleibt.

---

# Prüfung 1.8.0 · 14.10.2026

Ausgangsstand vor der Überarbeitung: TypeScript und 123 bestehende Tests bestanden. Nach der Überarbeitung: Typprüfung sowie jeweils 129 Tests für iPhone- und Android-Buildkonfiguration bestanden. Die neuen Prüfungen decken Zeitraumwahl und Plattformauswahl im serverseitig gerenderten Markup sowie Updateaktivierung, ausbleibendes Browserereignis, Timeout und doppelte Ereignisse ab. Vorhandene Tests prüfen weiter Workouts, einzelne Sätze, Pläne, PRs, Fortschritt, RIR/RPE, JSON-Import/-Export und IndexedDB-Neuöffnung mit unveränderten gespeicherten Werten.

Beide Produktionsbuilds und `check-pwa.mjs` bestanden: vollständige lokale Assets, relative Pfade für Root und verschachtelte GitHub-Pages-Verzeichnisse, Offline-Navigation, ältere App-Chunks für noch offene Tabs, begrenzte Cachebereinigung, gemeinsame Manifest-ID und eigenständige Reparaturseite. `check-recovery.mjs` führt die tatsächlich ausgelieferten Inline-Skripte in einer isolierten JavaScript-Umgebung aus: Startfehler, Zeitüberschreitung, erfolgreicher Mount, drei App-Pfade sowie Offline-/HTTP-/falsche-Seite-Fehler. Reparatur berührt keine Datenbank und keine Caches/Service Worker anderer App-Pfade.

Speichercode, Schema, Satz-/Übungsdatenformat, Hintergrundspeicher, Coach und Fortschrittsberechnung sind bytegleich mit Version 1.7.2. Es gibt keine Migration. ZIPs werden auf Prüfsummen und fehlerfreies Entpacken geprüft; `index.html`, relative Assets, Service Worker und Reparaturseite liegen jeweils auf der richtigen Ebene.

**Prüfgrenzen:** Keine Browser- oder echten Gerätetests in dieser Umgebung. Damit sind reale Darstellung bei 320–430 px, Touch-Scrollen, verschachtelte Sheets, Tastatur, Android-Zurück, TalkBack/VoiceOver und PWA-Installation weiterhin am Gerät zu prüfen. Die automatische Prüfung ist kein Nachweis visueller Fehlerfreiheit. Der konkret gemeldete weiße Bildschirm konnte weder am iPhone noch an der veröffentlichten GitHub-Seite reproduziert werden; diese Version enthält Absicherungen und einen unabhängigen Reparaturweg, keine bestätigte gerätespezifische Ursachenanalyse. Der Build meldet weiterhin einen bestehenden großen Haupt-Chunk; Videos und Analyseansichten bleiben dynamisch geladen.

Referenzen zur Updateimplementierung (14.10.2026): [Service-Worker-Updatecache](https://developer.mozilla.org/en-US/docs/Web/API/ServiceWorkerRegistration/updateViaCache), [controllerchange](https://developer.mozilla.org/en-US/docs/Web/API/ServiceWorkerContainer/controllerchange_event), [unregister](https://developer.mozilla.org/en-US/docs/Web/API/ServiceWorkerRegistration/unregister).

---

# Prüfung 1.7.2 · 13.10.2026

Gezielte Vereinfachung der Fotoauswahl: ein synchroner Klick auf „Eigenes Bild“ öffnet den bestehenden Datei-Input. Der zusätzliche Auswahl-/Ersetzen-Button wurde entfernt. Ohne gewählte Datei wird keine Speicheraktion ausgeführt; Bildverarbeitung, Sperre während des Speicherns, Fehlerbehandlung und Hintergrundspeicher sind unverändert. Keine neue Datenmigration.

Abnahme über `npm run verify`: TypeScript, bestehende 123 Tests, Produktionsbuild und PWA-Artefakte. Für diese kleine Darstellungsänderung keine neuen Tests, die nur die Implementierung spiegeln. Echter iPhone-Dateidialog und Touch-Abnahme sind in dieser Umgebung weiterhin nicht verfügbar und nicht als getestet zu verstehen.

---

# Prüfung 1.7.1 · 13.10.2026

Gezielte Darstellungskorrektur: zusammenhängender Schriftzug, neue Icon-Grafik und veränderte Icon-Dateipfade. Abnahme über `npm run verify` (Typen, bestehende 123 Tests, Produktionsbuild und PWA-Artefaktprüfung). Die PWA-Prüfung umfasst jetzt zusätzlich die konkrete Apple-Touch-Icon-Verknüpfung, den Namen 4REPS und die Existenz sämtlicher referenzierter Icon-Dateien. Manifest-ID, Startadresse und Scope bleiben unverändert.

Icons aus eigenem SVG in 32, 180, 192 und 512 px gerendert; 512-px-Fassung visuell geprüft. Keine Änderungen am Speichern oder an Nutzerdaten. Keine neuen Tests, die nur die Logoimplementierung nachbilden.

**Verifikationsgrenze:** Kein echtes iPhone und kein unterstütztes Browser-QA-Werkzeug verfügbar. Die Aktualisierung eines bereits installierten Home-Bildschirm-Icons ist deshalb nicht auf iOS geprüft. Für das Icon weder die App noch Website-Daten löschen.

---

# Prüfung 1.7.0 · 13.10.2026

Ausgangspunkt: unverändertes, erhaltenes 1.6.3-Projekt mit 113 bestandenen Prüfungen. Nach Änderungen: TypeScript und 123 Tests. Neue Prüfungen decken die folgenden Grenzen ab:

- Hintergrundfoto in separater IndexedDB, Lesen nach neuer Verbindung und nach Neuöffnung der Trainingsdatenbank; bestehende Workouts, Pläne, Einstellungen und JSON-Backups vor/nach identisch. Entfernen betrifft nur das Foto. Ungültige oder zu große Bildkopien lassen das bisherige Foto stehen.
- Foto-Datenbank getrennt nach App-Pfad und Demo. Bisherige App-Speicherkennung und Manifest-ID bleiben unverändert.
- Optionaler Hintergrundmodus: alte An/Aus-Einstellungen bleiben unverändert lesbar und exportierbar; eine fehlerhafte kosmetische Wahl verwirft keine Trainingsdaten.
- Fotoformat-/Dateigrößenprüfung und proportionsgetreue Verkleinerung. Die Pipeline wird mit gemockten Image-/Canvas-APIs geprüft: neue JPEG-Kodierung, Ressourcenfreigabe sowie verständlicher Fehler beim Dekodieren. Das prüft keine reale HEIC-Kompatibilität oder Bildausrichtung auf iOS.
- React-Struktur: Fortschritt vor Kalender vor Plänen, genau ein allgemeiner Fortschrittszugang auf Heute, große Körpergewichtsroute erhalten, fünf Übungen mit weiterem Nachladen und dekorativen Gerätesymbolen. Leerer Fotohintergrund verursacht keinen Renderfehler.

Produktionsbuild und Service-Worker-Artefaktprüfung bestanden: 55 lokale Dateien, 4REPS-Metadaten, vorhandene Icons, gleiche Manifest-ID und simulierte Offline-Nutzung unter Root- und verschachtelten Projektpfaden. Die PNGs wurden aus dem eigenen SVG gerendert und das Icon visuell geprüft; sämtliche PNGs haben einen vollständig deckenden Hintergrund. Die bisherigen Tests zu Speicherung, Import, Coach, PRs, Fortschritt und schneller Dateneingabe bestehen weiterhin. Der Hauptchunk liegt bei rund 610 kB unkomprimiert / 184 kB gzip; die bisherige Größenwarnung bleibt, die Bildverarbeitung wird erst bei Auswahl eines Fotos geladen.

Repository, Speicherpfad, Workout, Pläne, Verlauf, Coach, Fortschrittsberechnung und Bottom Navigation sind bytegleich zur Version 1.6.3. Für das Foto wurde ein separater Speicher ergänzt, für die Anzeige nur ein optionales kosmetisches Feld. Keine Migration oder Änderung bestehender Übungs-IDs.

**Verifikationsgrenze:** Kein Control-Browser-Werkzeug in dieser verwalteten Umgebung; daher keine neue Browser-Vorschau, keine realen Touch-/Layoutprüfungen und kein Test auf einem physischen iPhone. Die vorhandenen Browser-Skripte wurden für die geänderten Wege angepasst, hier aber nicht ausgeführt. Frühere Browser-Abnahmen gelten nur für ihre jeweilige Version.

Manuell auf dem iPhone prüfen: Anordnung und Scrollen; Kalender in Woche/Monat; Übungssuche, Nachladen und Zuklappen; Foto aus Galerie wählen, ersetzen, Modi wechseln, schließen/neu öffnen, offline öffnen; hell/dunkel und Lesbarkeit; Foto entfernen ohne Verlust von Workouts; App-Name/Icon nach Installation. Alte App nicht löschen und Website-Daten nicht leeren, um Icons zu aktualisieren.

---

# Prüfung 1.6.3 · 13.10.2026

Ausgangspunkt: erhaltene Quellen und Produktions-ZIP 1.6.2 mit 109 bestandenen Prüfungen. Nach der gezielten Anzeigeänderung bestehen TypeScript und alle 113 Prüfungen. Zusätzlich geprüft:

- Körpergewichtsdifferenz und Prozent beziehen sich auf dieselben ungerundeten ersten/letzten Messwerte im Zeitraum. Plus, Minus, Null, ungültige Referenzen und Einzelmessungen bleiben nachvollziehbar.
- Die lb-Ansicht ändert die absolute Zahl, nicht die Prozentbasis. Reine Wiederholungsvergleiche zeigen Wdh. und die Referenzlast, keine erfundene kg-Steigerung.
- Gerenderte Startseiten-/Detailstruktur: 70 kg × 10 gegenüber 75 kg × 6 ergibt anhand der bestehenden e1RM-Regeln einen Rückgang von ungefähr 3,3 kg und 3,6 %, obwohl das reine Trainingsgewicht steigt. Beide Zahlen und ihre Basis sind sichtbar. Kein Zustand wird beim Rendern verändert.
- Vorhandene Daten-, Backup-, Farbkontrast-, schnelle Speicheränderungs-, Coaching-, PR- und Fortschrittstests bestehen weiterhin. Die große Körpergewichtsroute, Zeitraumwahl und Eintragsliste bleiben enthalten.

Repository, Schema, Typen, Speicherpfad, Workout, Pläne, Verlauf, Coach, Leistungsalgorithmus, Cloud-Module und Navigation sind gegenüber 1.6.2 unverändert. Keine neue Datenstruktur, Migration oder Abhängigkeit. Produktionsbuild und PWA-Artefaktprüfung prüfen die vollständige Auslieferung und simulierte Cache-Nutzung; ZIP-Dateien enthalten geprüfte Einzeldatei-Prüfsummen.

**Verifikationsgrenze:** Wie bei 1.6.2 ist das für diese Umgebung vorgesehene Control-Browser-Werkzeug nicht verfügbar. Keine neue Browser-Vorschau, keine gemessene Darstellung oder Touch-Prüfung und kein echter iPhone-/Safari-Test. React-Strukturtests ersetzen diese Prüfungen nicht. Auf dem iPhone nach Update besonders die kleinere Prozentzeile, lange Übungsnamen, Hell/Dunkel, eigene Plus-/Minusfarben sowie Öffnen/Zurück der großen Gewichtsansicht prüfen. Ältere Browser-Abnahmen unten gelten ausschließlich für ihre jeweilige Version.

---

# Prüfung 1.6.2 · 12.10.2026

Vor Änderungen: TypeScript und alle 98 bestehenden Kernprüfungen aus 1.6.1 bestanden. Nach Änderungen: TypeScript und 109 Prüfungen bestanden. Die elf zusätzlichen Prüfungen umfassen:

- optionale Plus-/Minus-Farben: alte Datenstände einschließlich Look aus 1.6.1 bleiben beim Lesen und Export unverändert; neue Farben bleiben im Backup erhalten;
- lesbare Änderungsfarben auf dunklen/hellen Ebenen, unabhängig von Diagramm- und Warnfarben; Rundung auf null und fehlende Daten bleiben neutral;
- 20 schnelle Farbänderungen mit anschließender Schließung/Wiederöffnung der simulierten IndexedDB: Trainingsdaten, Pläne, Notizen, Gewichtseinträge, Videos und andere Einstellungen unverändert;
- gerenderte React-Struktur ohne Browser: Direktzugänge auf Heute/Mein Fortschritt, Gewichtsdetailroute, Zeitraum und lb, leere Ansicht, Einzelmessung ohne Trend, direkt sichtbare Notizen/Bearbeitungsaktionen und begrenzte Liste mit Nachladen;
- Prozentanzeigen mit positiven/negativen/stabilen/fehlenden Werten und aufgeräumte Einstellungen bei erhaltenem Export/Import und Updatezugang.

Vierzehn Kernmodule sind bytegleich zu 1.6.1: Repository, Speicherpfad, Workout, Pläne, Verlauf, Coach, Fortschrittsberechnung, Planlogik, Übungsbibliothek, drei Cloud-Module, Interaktionen und Bottom Navigation. Schema/Backup bleiben Version 3; nur zwei optionale kosmetische Felder sind ergänzt. Es werden keine bestehenden Daten beim Update gelöscht oder migriert.

Produktionsbuild und PWA-Artefaktprüfung bestanden: 48 lokale Dateien/Chunks, simuliertes Offline-Laden, Root- und verschachtelte Pages-Pfade. Die bisherige Bundlewarnung besteht weiter (Hauptchunk rund 606 kB unkomprimiert, 183 kB gzip); Detailbereiche bleiben dynamisch geladen.

**Verifikationsgrenze:** Für diese Umgebung ist gemäß Sites-Workflow Browser-QA nur mit dem Control-Browser-Werkzeug vorgesehen; dieses ist nicht verfügbar. Deshalb keine neue Browser-Vorschau, kein tatsächlich geklickter Ablauf, keine neuen Screenshots und kein echter Safari-/iPhone-Test dieser Version. React-Strukturtests sind kein Ersatz für Layout-, Gesten- oder Farbprüfungen im Browser. Die vorhandenen Browser-Skripte wurden an die neuen Wege angepasst, aber hier nicht ausgeführt. Ältere Abnahmen unten gelten nur für ihre jeweilige Version.

Gezielte iPhone-Abnahme nach dem Update:

1. Körpergewichtszahl und Diagramm auf Heute und Mein Fortschritt öffnen, großen Verlauf und Zurück prüfen.
2. Zeitraum zwischen Tag, Monat, Gesamt und eigenen Grenzen wechseln; einen Messpunkt wählen, Eintrag bearbeiten, neue Messung anlegen und nur einen Testeintrag nach Bestätigung löschen.
3. Plus/Minus in Gewicht und Übungsentwicklung prüfen; Mehr → Dein Look → Farben für Plus & Minus ändern, hell/dunkel wechseln, App neu öffnen.
4. JSON exportieren/importieren, bei Bedarf Weitere Datenoptionen → Letzten Import rückgängig machen. Nur künstliche Daten in einem separaten Testprofil verwenden.
5. Infofenster und native Farbauswahl schließen; wiederholte Tabwechsel, 320/390/430 px, Scrollen und sichtbare Bottom Navigation prüfen.

Keine Website-Daten löschen, um ein Update zu erzwingen.

---

# Prüfung 1.6.1 · 12.10.2026

Vor Änderungen: unveränderte 1.6.0-Quellen, TypeScript und 91 bestehende Kernprüfungen bestanden.

Nach Änderungen: TypeScript und 98 Kernprüfungen bestanden. Zusätzlich geprüft:

- alte Snapshots und JSON-Dateien bleiben vollständig gleich, wenn kein Aussehen gespeichert ist;
- Farbwahl und abgeschalteter Hintergrund überstehen Export/Import;
- fehlerhafte rein optische Werte verhindern nicht das Lesen gültiger Trainingsdaten;
- 24 parallele Look-/Timer-/Ton-Änderungen, Schließen und Wiederöffnen der simulierten IndexedDB: letzter Zustand korrekt und alle Workout-, Plan-, Körpergewichts-, Übungs- und Videodaten unverändert;
- 458 Kombinationen von Farbe und Theme gegen jeweils vier feste Ebenen mit mindestens 4,5:1 Textkontrast, außerdem Beschriftung auf Aktionsbuttons und Akzentflächen;
- Reset des Looks verändert weder Einheit, Timer, Ton noch Theme;
- bestehende Coach-, Fortschritts-, PR-, Kalender-, Such-, Video-Mathematik-, Speicher-, Import- und Cloud-Konflikttests weiterhin bestanden.

Produktionsbuild und Service-Worker-Artefaktprüfung bestanden: alle 48 lokalen Dateien und Chunks im simulierten Offline-Cache; Root- und verschachtelte GitHub-Pages-Pfade korrekt. Kein echter Browser-Lifecycle-Test. Zehn relevante Kernmodule, darunter Repository, Speicherpfad, Workout, Coach und Cloud, sind bytegleich zu 1.6.0.

**Verifikationsgrenze dieser Version:** Das vom Sites-Workflow für diese Umgebung vorgeschriebene Browser-Steuerungswerkzeug ist nicht verfügbar. Daher keine neue Browser-Vorschau, Screenshots, realen Safari-/WebKit-Tests oder echten iPhone-Tests in diesem Durchlauf. Die CSS-Ursache wurde anhand des vorhandenen Quellcodes behoben; die tatsächliche Darstellung und der native iOS-Farbdialog sind noch auf dem Gerät zu prüfen. Frühere Browser- und PWA-Berichte unten gelten ausschließlich für die dort genannten Versionen.

Auf dem iPhone nach dem Update prüfen: Mehr → Timer/Ton mehrfach ein/aus (Kreis bleibt in Spur); Dein Look → Farbkombination wählen, eigene Farbe, Dunkel/Hell, Hintergrund aus/ein, Reset; andere Tabs/Diagramme prüfen; App schließen und erneut öffnen. Bestehende Trainingsdaten sollen weiterhin unverändert sichtbar sein. Kein Löschen von Website-Daten.

---

# Abnahme 1.6.0 · 09.10.2026

## Vor der Überarbeitung

Der Quellcode unter `features/` und `app/` stimmt mit der gespeicherten Version 1.5.1 überein. TypeScript und alle 86 bisherigen Kernprüfungen bestanden. Der vollständige Chromium-Workout-Ablauf wurde gegen das unveränderte 1.5.1-Produktionspaket geprüft: Planbearbeitung, schnelle Satzeingaben, Historie, Fortschritt, Diagramme und Navigation bestanden. Festgestellt wurden die vom Nutzer beschriebenen Bedienprobleme: überladene Startseite, vollständige 300er-Listen und ein unhilfreicher separater Leistungsvergleich.

## Nach der Überarbeitung

- 91 Kernprüfungen: bestehende 86 sowie Kalendergrenzen, Schaltjahr, Zeitumstellung, Monatswechsel und mehrere abgeschlossene Einheiten pro Tag.
- Chromium und Linux-WebKit: Workout-Regression einschließlich Plan erstellen/umsortieren/kopieren/löschen, Entwurfschutz, Gewicht/Wiederholungen/RIR/RPE, acht schnelle neue Sätze, Duplizieren/Löschen, Pausentimer, Ersetzen, Supersatz, Abschluss, Korrektur, Wiederverwendung, PRs und Körpergewicht/Diagramme.
- Navigation in beiden Engines: Pixeltest während des Seitenübergangs, 61 schnelle Wechsel, Glass-Pill-Drag, Tastatur-Simulation, 320/390/430 px, Desktop, Reduced Motion. Auch frühere Sheet-/Scroll-Lock-Prüfungen bestanden.
- Neue Oberflächenprüfungen: Reihenfolge Kalender → Pläne → Fortschritt auf dem iPhone; Wochen-/Monatswechsel; Datumsauswahl; wiederholtes Blättern; fünf Treffer; vollständige Suche und Filter; Aufklappen/Zuklappen; Übungsauswahl; direkte Fortschrittsnavigation; entfernte Vergleichszugänge; alter `#comparison`-Link führt zum persönlichen Fortschritt; Quellen nur auf Nachfrage.
- Chromium: JSON-Export/Import, ungültiger Import, Rücknahme, vollständig geschlossener Browser und echter Offline-Neustart, getrennte GitHub-Pages-Unterverzeichnisse bestanden.
- Echtes Service-Worker-Update 1.5.1 → 1.6.0 in Chromium: Workoutdaten mit RIR, Pausen, Tempo und Notizen; eigene Übungen; Favoriten; Pläne mit individuellen Satzvorgaben; Körpergewicht; Video-Metadaten und Einstellungen erhalten. Ein Backup der Vorversion bleibt importierbar. Anschließend offline neu geladen.
- Datenbank, Schema, Speicherpfad, Coach, Fortschrittsberechnung, Übungs-IDs, Cloud-Module und Workout-Satzeingabe sind gegenüber 1.5.1 bytegleich. Keine neue Migration.

## Grenzen

Kein physisches iPhone, keine echte PWA-Installation, VoiceOver oder Bildratenmessung. Linux-WebKit 18.4 erlaubt im hier eingesetzten Testtreiber keinen Offline-Dokument-Neustart (`WebKit encountered an internal error`). Derselbe Fehler wurde isoliert gegen 1.5.1 und 1.6.0 bei aktivem Service Worker und vorhandenem Cache bestätigt. Deshalb wird dieser einzelne WebKit-Schritt ausdrücklich nicht als bestanden ausgegeben; Online-Neustart und Offline-Navigation innerhalb der geöffneten App sind separat geprüft. Echte Offline-Neustarts sind in Chromium abgedeckt.

Keine neuen Behauptungen zur Pose-Genauigkeit oder zu externen Cloud-Diensten; beide wurden in dieser UI-Version nicht verändert. Hauptbundle weiterhin ungefähr 603 kB unkomprimiert (Build-Warnung >500 kB); große Zusatzbereiche bleiben dynamisch geladen.

Befehle: `npm run verify`, `npm run test:simplicity`, `npm run test:refinement`, `npm run test:navigation`, `npm run test:motion`, `npm run test:browser`, `npm run test:update`. Für WebKit `FORMA_ENGINE=webkit`; für den Versionswechsel zusätzlich `FORMA_PREVIOUS_VERSION=1.5.1` und `FORMA_PREVIOUS_BUILD=<entpackter 1.5.1-Build>`.

---

# Prüfprotokoll

## Navigationskorrektur 1.5.1 (08.10.2026)

Ausgangspunkt: Produktionsbuild 1.5.0. Der neue Pixeltest scheitert vor der Korrektur reproduzierbar: Eine Probe innerhalb der Navigation wird während der Seitenaufnahme überzeichnet, obwohl CSS-Sichtbarkeit und Position korrekt sind. Nach der Korrektur bleibt sie unverändert sichtbar.

| Bereich | Ergebnis |
|---|---|
| Navigation, Chromium und Linux-WebKit | Pixelprüfung bei angehaltener Inhaltsanimation erfolgreich. Navigation bleibt dasselbe DOM-Element; Scrollen, 61 schnelle Wechsel, direkter Glass-Pill-Drag, Übungsfenster und Fortschritts-Rückweg geprüft. |
| Mobil und Tastatur | 320/390/430 px ohne Überlauf; Navigation im sichtbaren Bereich und per Hit-Test erreichbar. Simulierte Visual-Viewport-Verkleinerung blendet sie nur während der Texteingabe aus; nach Blur wieder sichtbar. Kein Ersatz für eine echte iOS-Tastaturprüfung. |
| Animationen | Beide Engines: 41 schnelle Wechsel, stabil schließende Sheets, kurze/lange Ziehbewegungen, reduzierte Bewegung und direkter Fallback ohne Element.animate erfolgreich. |
| Workout-Regression | Beide Engines: Pläne, Reihenfolge, Entwurfschutz, Satzgewichte/Wiederholungen, RIR/RPE, Timer, acht schnelle Satzergänzungen, Duplizieren/Löschen, Übungsersatz, Workout-Abschluss, Historie, PRs, Körpergewicht und Diagramme erfolgreich. |
| Speicherung | Chromium: vollständige JSON-Rundreise, ungültigen Import abweisen, Rücknahme; Browserprozess schließen und offline erneut öffnen. Workouts, Pläne, eigene Übungen, Körpergewicht, Einstellungen und Video-Metadaten erhalten. |
| Update | Chromium: Service-Worker-Wechsel 1.5.0 → 1.5.1, gespeicherte Daten vor/nach exakt verglichen (Backup-Zeitpunkt ausgenommen), altes Backup wieder importiert und offline geöffnet. |
| Kern und Build | TypeScript, 86 Logik-/Speichertests und PWA-Artefaktprüfung bestanden. Speicher-, Schema-, Übungs-, Coaching-, Fortschritts- und Cloud-Dateien byteweise unverändert gegenüber dem Quellcodepaket 1.5.0. |

Neue gezielte Prüfung: `npm run test:navigation`, zusätzlich `FORMA_ENGINE=webkit npm run test:navigation`. Die bisherigen Befehle bleiben bestehen; für den Update-Test `FORMA_PREVIOUS_VERSION=1.5.0` und einen entpackten 1.5.0-Build angeben.

Grenzen: kein physisches iPhone, keine echte Home-Bildschirm-Installation oder native Bildschirmtastatur in diesem Test. WebKit 18.4 auf Linux ist Safari-nah, nicht iOS. Touch-Bildrate und Verhalten bei eingeblendeter Safari-Adressleiste bleiben auf Hardware zu prüfen. Cloud-Anbindung und Poseanalyse wurden nicht verändert oder neu gegen externe Dienste geprüft. Ausschließlich künstliche Testdaten; keine persönlichen Trainingsdaten verwendet.

## Abschlussprüfung 1.5.0 (07.10.2026)

Ausgangspunkt: gesichertes Quellcodepaket 1.4.1 byteweise abgeglichen, 79 bestehende Tests vor Änderungen erfolgreich. Ausschließlich künstliche Trainingsdaten und temporäre Browserprofile.

| Bereich | Ergebnis |
|---|---|
| Logik, Speicher, Typen | TypeScript und 86 Tests erfolgreich, darunter sieben neue Prüfungen für Konfliktentscheidung, Fingerabdruck, geheime Schlüssel, getrennte Tokens, atomare Cloud-Übernahme, aktives Workout und einzelne Plansätze. |
| Workout-Regression | Chromium und Linux-WebKit: Pläne, Reihenfolge, Entwurfschutz, Workout, Gewicht, Wiederholungen, RIR/RPE, Timer, schnelle +/- Eingaben, acht Sätze in Folge, Duplizieren/Löschen, Übungsauswahl, Abschluss, historische Korrektur, Wiederverwendung, PRs, Körpergewicht und interaktive Diagramme erfolgreich. |
| Neue Planansicht | Beide Engines: individuelles Gewicht/Wiederholungen, mittlere Zeile entfernen ohne Datenverschiebung, Range standardmäßig eingeklappt, nach Neustart identische gespeicherte Werte. |
| Cloud-Ablauf | Beide Engines, offizieller Supabase-Client gegen lokalen simulierten Endpoint: Code-Anmeldung, Upload, explizite Übernahme auf neuem Gerät, Offline-Eingaben, automatischer Online-Abgleich, beidseitiger Konflikt, Version exportieren, Abmelden ohne Datenverlust, abweichendes Konto vor Upload blockiert. |
| SQL-Sicherheit | Mit PGlite/PostgreSQL: Setup zweimal ausführbar, anonyme Zugriffe gesperrt, zwei Auth-Benutzer getrennt, fremde Zeilen nicht les-/schreibbar, veraltete Version abgewiesen, vorige Daten archiviert, zehn Versionen behalten. |
| Persistenz, Export/Import | Chromium mit geschlossenem Browserprozess und erneutem Offline-Start: vollständige Daten erhalten; vollständiger JSON-Import, ungültiger Import und Rücknahme erfolgreich. |
| Update | Chromium, echter Service-Worker-Wechsel 1.4.1 → 1.5.0: Workouts/Satzdetails, Pläne/Satzvorgaben, Körpergewicht, eigene Übungen, Einstellungen, Favoriten, Notizen und Video-Metadaten vor/nach Update verglichen; altes Backup importiert, offline geöffnet. |
| Navigation/Animation | Beide Engines: 41 schnelle Tab-Aktionen, Glass-Pill ohne Sprung, stabile Sheet-Inhalte beim Schließen, kurze/lange Drag-Gesten, Reduce Motion, View-Transition-Fallback. Im WebKit-Lauf gefundenes Sheet/Hash-Rennen bei Start/Abschluss korrigiert und vollständigen Ablauf danach erneut bestanden. |
| Darstellung | 320/390 px und Desktop ohne horizontalen Dokumentüberlauf in den geprüften Abläufen. Dark/Light, Dropdowns, Scrollen und Screenshots geprüft. |

Reproduzierbare Befehle zusätzlich zu den bisherigen Tests:

```sh
npm run verify
npm run test:cloud:sql
npm run test:cloud
FORMA_ENGINE=webkit npm run test:cloud
npm run test:refinement
FORMA_ENGINE=webkit npm run test:refinement
npm run test:motion
FORMA_ENGINE=webkit npm run test:motion
npm run test:browser
FORMA_ENGINE=chromium FORMA_PREVIOUS_VERSION=1.4.1 FORMA_PREVIOUS_BUILD=/pfad/zum/build-1.4.1 npm run test:update
python3 scripts/package-release.py
```

Grenzen: kein physisches iPhone, kein Live-Supabase-Projekt und keine echte Mailzustellung getestet. Der simulierte Cloud-Test läuft ohne Service Worker auf demselben Test-Origin, weil WebKits Testumgebung native CORS-Preflights nicht abfängt; produktive Provider-Konfiguration/CORS muss nach Einrichtung geprüft werden. PWA-Offline- und Update-Abläufe werden separat mit echtem Service Worker geprüft. Kein Anspruch auf E2E-Verschlüsselung oder Synchronisierung bei geschlossener App. Pose-Genauigkeit und wissenschaftliche Regeln wurden in dieser Version nicht verändert. Der bestehende Build-Hinweis zum großen Haupt-Chunk bleibt; Supabase wird erst nach vorhandener Cloud-Konfiguration dynamisch geladen.

## Abschlussprüfung 1.4.1 (07.10.2026)

Vorher: bestehender Bedienungs-Regressionslauf auf 1.4.0 erfolgreich. Nach der Verfeinerung wurden die nachfolgenden Prüfungen ausgeführt. Ausschließlich künstliche Daten und temporäre Browserprofile; kein Zugriff auf persönliche Trainingsdaten.

| Bereich | Ergebnis |
|---|---|
| Typprüfung und Logik | TypeScript, 79 Logik-/Speichertests und Produktions-/PWA-Artefaktprüfung erfolgreich. |
| Bestehende Funktionen | Chromium und WebKit: Plan erstellen/umsortieren/Entwurf schützen; Workout starten, Gewicht/Wiederholungen/RIR/RPE, acht Sätze schnell ergänzen, duplizieren/löschen, Timer, Übungsauswahl/Ersetzen/Anordnung, Abschluss, Historie, Wiederverwendung, PR, Körpergewicht, Diagrammpunkte und Statistiken erfolgreich. |
| Persistenz und Backups | Chromium: vollständiger JSON-Export/Import, ungültiger Import, Rücknahme; Browserprozess mit persistentem Profil geschlossen und offline wieder geöffnet; Daten danach erneut unverändert exportiert. |
| Navigation | Chromium und WebKit: Fortschritt unter Heute, drei ergänzende Werkzeuge unter Mehr, korrekter Rückweg und erhaltener Zeitraum. 41 schnelle Tab-Aktionen enden bei der zuletzt gewählten Ansicht. |
| Animationen und Sheets | Beide Engines: kein Pill-Sprung beim Pointer-down, Drag-Schwelle, Inhalt und Höhe beim Schließen erhalten, kurzer Drag federt zurück ohne erneute Öffnungsanimation, langer Drag schließt von der aktuellen Position, keine hängenden Dialoge/Scroll-Sperren. |
| Fallbacks | Beide Engines: reduzierte Bewegung sowie Navigation mit ausgeschalteter View-Transition-API bedienbar. Hell/dunkel und manuelle Update-Prüfung erfolgreich. |
| Responsive Layout | Heute mit Demo-Daten bei 320 × 568, 390 × 844 und 1440 × 1000 ohne horizontalen Dokumentüberlauf. Bibliothek und eigenes Übungsformular bei 320/390 px geprüft; Gerätewahl und Scrollen in beide Richtungen, speichern und erneut laden erfolgreich. Während der Prüfung gefundene Überläufe wurden behoben und erneut getestet. |
| Echtes Update | Chromium: unveränderter Produktionsbuild 1.4.0 → 1.4.1 über wartenden Service Worker und „Jetzt aktualisieren“. Workouts mit Satzdetails, Pläne mit individuellen Zielwerten, eigene Übungen, Körpergewicht, Notizen, Favoriten, Einstellungen und Video-Metadaten vor/nach Update exakt verglichen; Backup-Zeitpunkt separat berücksichtigt. Altes Backup importiert, aktualisierte App offline geöffnet. |

Keine Laufzeitfehler in den bestandenen Abläufen. Kein externer Netzabruf im geprüften Offline-Kern. Die Speicher-, Datenformat-, Übungskatalog- und Coachingdateien wurden zusätzlich mit dem Quellcodepaket 1.4.0 auf unveränderten Inhalt geprüft.

Reproduzierbar nach `npm ci` und Installation der Playwright-Browser/Systembibliotheken:

```sh
npm run verify
npm run test:browser
npm run test:refinement
FORMA_ENGINE=webkit npm run test:refinement
npm run test:motion
FORMA_ENGINE=webkit npm run test:motion
FORMA_PREVIOUS_BUILD=/pfad/zum/entpackten/1.4.0-build npm run test:update
```

**Grenzen:** Linux-WebKit ist kein physischer iPhone-/Safari-Test. Native Bildschirmtastatur, tatsächliche Touch-Bildrate, VoiceOver und Home-Bildschirm-Installation bleiben auf dem Gerät zu prüfen. Die optionale Poseanalyse wurde bei diesem Oberflächenupdate nicht neu auf Genauigkeit geprüft. Es gibt keine Garantie gegen die Löschung lokaler Browserdaten durch Nutzer oder Betriebssystem. Die folgenden Protokolle beschreiben frühere Versionen.

## Abschlussprüfung 1.4.0 (07.10.2026)

Vor Änderungen wurde 1.3.2 vollständig in den vorhandenen Tests geprüft und um gezielte Bedienversuche ergänzt. Die dabei reproduzierten Fehler stehen in [AUDIT.md](AUDIT.md). Nach den Änderungen wurde die folgende zweite Prüfung ausgeführt; Testdaten sind künstlich und von persönlichen Daten getrennt.

| Bereich | Ergebnis und Umfang |
|---|---|
| Typen, Logik, Speicher | TypeScript und 79 Tests erfolgreich: atomare Änderungen, konkurrierende Eingaben, unzulässige Daten, Backup-Rundreise/Rücknahme, Migration, Coaching, Plateau, PRs, Fortschrittsregeln, Übungsvarianten und synthetische Videozyklen. |
| Bestehender Workout-Ablauf | Chromium: Erststart, freies Workout, unterschiedliche Satzgewichte/Wiederholungen, RIR, Timer, aktives Workout nach Reload, Abschluss, Historie und JSON mit exakten Satzwerten. |
| Vollständige Datensicherung | Chromium: Import einschließlich Plänen, individuellen Satzvorgaben, eigenen Übungen, Einstellungen, Körpergewicht und Video-Metadaten; ungültige Datei abgewiesen; Import verlustfrei zurückgenommen. Browserprozess geschlossen, Profil offline neu geöffnet und Daten erneut exportiert/verglichen. |
| Neue Bedienabläufe | Chromium und Linux-WebKit: Plan mit zwei Übungen erstellen, umsortieren, Ziel-Sätze ändern, Entwurf beim Schließen und Browser-Zurück schützen, speichern und starten. Verschachtelte Auswahl bleibt bedienbar. |
| Schnelle Eingaben | Beide Engines: zehn Gewichts- und Wiederholungsschritte ohne verlorene Änderungen; acht Sätze schnell hinzufügen, Satz duplizieren/löschen, RIR/RPE wechseln, Timer +30 s/Schließen. Acht schnelle Klicks auf Plan kopieren erzeugen genau eine Kopie; diese lässt sich kontrolliert löschen. |
| Workout und Historie | Beide Engines: Übung hinzufügen/entfernen/umsortieren, Ersatzwarnung abbrechen ohne Verlust, Pause/Supersatz/Coach-Erklärung, Workout beenden, historischen RIR korrigieren, als Plan speichern, erneut starten mit vorheriger Leistung und neuen PR erkennen. |
| Fortschritt und Charts | Beide Engines: Gewicht mit Dezimalkomma, einzelner Punkt ohne Trend, exakte Diagrammpunkte, Zeitraum Gesamt, Leistungskennzahl wechseln, Satzdetails, Zurück zur Übungsliste und Statistik nach zwei Einheiten. Weitere Zeitraum-/Trendregeln durch die Logiktests abgedeckt. |
| Bibliothek und Auswahl | Beide Engines: native Geräte-/Muskel-/Messartwahl, eigenes eGym-Gerät speichern, in beide Richtungen scrollen, Suchaliase/Equipmentfilter, Daten nach Reload unverändert. |
| Navigation und Bewegung | Beide Engines: sechs schnelle Detailwechsel, Zurück schließt die Ebene, Sheet am Griff herunterziehen, kein hängender Scroll-Lock; Glass Pill direkt ziehen, zehn Tabwechsel, aktive Auswahl, reduzierte Bewegung, hell/dunkel, manuelle Update-Prüfung. |
| Layout | 320 × 568 und 390 × 844, Desktop 1440 × 1000: kein horizontaler Dokumentüberlauf; bei 320 px liegen alle Satzfelder und Abschlusstasten innerhalb ihrer Karte. Screenshots visuell geprüft. |
| Echtes PWA-Update | Chromium: Produktionsdateien 1.3.2 durch 1.4.0 ersetzt, wartenden Service Worker über die App aktiviert. Workouts mit Satz-/ROM-/Tempo-/Pausendaten, Pläne mit Satzvorgaben, eigene Übungen, Gewicht, Favoriten, Einstellungen und Video-Metadaten exakt vor/nach Update verglichen. Altes Backup importierbar; neue Version offline erreichbar. |
| Videooberfläche | Chromium, synthetischer 4-s-WebM-Clip: Upload, drei manuelle Markierungen, acht schnelle Speicherklicks erzeugen genau einen Datensatz, nach Reload erhalten. Defekte MP4-Datei verständlich abgewiesen. Kontrollierter Worker prüft sofortigen Abbruch und Modellfehler ohne erfundene Ergebnisse. |
| Produktion | Statischer Build und PWA-Artefaktprüfung erfolgreich. Relative Pfade, Manifest, Icons, eigene Cachegrenze und Offline-Navigation geprüft. Keine Sites- oder Backend-Abhängigkeit im Kern. |

Keine JavaScript-Laufzeitfehler in den bestandenen Abläufen. Die Kernprüfung ohne automatische Videoanalyse erzeugte keine externen Netzabrufe.

### Reproduzieren

```sh
npm ci
npm run verify
npx playwright install --with-deps chromium webkit
npm run test:browser
npm run test:refinement
FORMA_ENGINE=webkit npm run test:refinement
npm run test:update
FORMA_PREVIOUS_BUILD=/pfad/zum/entpackten/1.3.2-build npm run test:update
node scripts/test-video-ui.mjs
```

Die Video-UI-Prüfung benötigt FFmpeg mit VP8-Encoder. Sie lädt bewusst kein Pose-Modell: der Worker wird nur für deterministische Fehler-/Abbruchantworten ersetzt. Das Testvideo enthält keine Person. Eine erfolgreiche Oberfläche ist deshalb kein Nachweis biomechanischer Genauigkeit. H.264- oder HEVC-Unterstützung auf einem iPhone wurde nicht mit diesem Linux-Test gemessen.

Linux-WebKit ist keine iOS-Safari-Freigabe. Home-Bildschirm-Installation, echtes iPhone mit Notch/Dynamic Island, native Tastatur, Touchgefühl/Bildrate, VoiceOver, Hintergrundtimer, mehrere gleichzeitig geöffnete PWA-Instanzen und iOS-Speicherdruck bleiben auf Hardware zu prüfen. Keine formale Vollabdeckung jeder Kombination und keine Garantie gegen Betriebssystem-Speicherbereinigung. Die weiter unten stehende iPhone-Checkliste dient dazu.

Die folgenden Protokolle beschreiben historische Versionen und werden nicht rückwirkend als aktuelle Hardwaretests ausgegeben.

## Geräteauswahl und Update 1.3.2 (05.10.2026)

- TypeScript, Produktionsbuild, PWA-Artefaktprüfung und alle **79 automatischen Tests erfolgreich**. Neue Prüfungen betreffen Suchaliase, getrennte eGym-/Griffvarianten, Planvorgaben im Backup und fehlende Referenz-/1RM-/Laststeigerungswerte bei elektronischen Geräten.
- Formular in Chromium und WebKit bei 390 × 844 sowie 320 × 568 geprüft: native Geräte-, Muskel- und Messartauswahl, Scrollbereich nach unten und oben, keine zusätzlichen Auswahl-Portale und kein horizontaler Überlauf. Eigene eGym-Übung speichern, neu laden und per JSON unverändert exportieren. Suchbegriffe für Überkopf-Trizeps und Reverse Preacher Curls sowie Gerätefilter erfolgreich.
- Den vollständigen Chromium-Test für Workout, einzelne Satzwerte, RIR, Timer, JSON-Import/-Export/-Rücknahme, Browserneustart, Offlinebetrieb und Desktop erneut erfolgreich ausgeführt.
- Echter Service-Worker-Versionswechsel im Browser: alten Produktionsbuild 1.3.1 geöffnet, Testplan mit individuellen Satzvorgaben und Gewichtseintrag gespeichert, Serverdateien auf 1.3.2 gewechselt und „Jetzt aktualisieren“ verwendet. Plan, Vorgaben, Gewichtseintrag und Notizen blieben erhalten. Anschließend Backup aus 1.3.1 importiert und neue Version offline geöffnet. Ausschließlich künstliche Testdaten; keine persönlichen Daten verwendet.
- Der öffentliche Trackby-Workflow wurde gelesen: Er entpackt bei jedem Push `Forma-GitHub-Pages.zip` und veröffentlicht den Inhalt. Das neue Paket muss vom Nutzer dort hochgeladen werden; keine Veröffentlichung durch diesen lokalen Test.

Reproduzieren (nach Installation der Testbrowser und ihrer Systembibliotheken):

```sh
npm run verify
npm run test:browser
node scripts/test-exercise-update.mjs
FORMA_PREVIOUS_BUILD=/pfad/zum/entpackten/alten/build node scripts/test-exercise-update.mjs
```

**Grenzen:** Linux-WebKit ist kein physisches iPhone. Der native iOS-Auswahldialog, reale Touch-Bildrate, Tastatur, Home-Bildschirm-Installation und iOS-Speicherbereinigung wurden nicht auf Hardware gemessen. Die geänderte Auswahl vermeidet das verschachtelte Scrollmenü; das Scrollgefühl muss auf dem Gerät bestätigt werden. Frühere Protokolle unten beschreiben ihren damaligen Stand.

## Standalone-Export 1.3.1 (01.10.2026)

- Saubere Installation aus dem enthaltenen npm-Lockfile erfolgreich. Kein Sites-/Next-/Vinext-Server oder privater Paketserver erforderlich.
- TypeScript-Prüfung und **76 automatische Tests erfolgreich**. Zehn zusätzliche Tests verwenden fake-indexeddb für echte IndexedDB-Transaktionsabläufe: neu öffnen, parallele Eingaben, abgewiesene Änderungen, Backup/Import/Rücknahme, getrennte Demo-Daten, Projektpfade und beschädigte gespeicherte Daten. Das Testdouble ersetzt keine Prüfung der Speicherung auf Datenträger.
- Produktionsbuild und Service-Worker-Prüfung erfolgreich: Root-Pfad, `/forma/`, verschachtelter Projektpfad, Cache-Bereinigung nur für das eigene Projekt, keine Navigation außerhalb des Scopes umgeleitet.
- **Zusätzlicher echter Chromium-Browsertest mit persistentem Profil**, mobilem Viewport 390 × 844 und Desktop 1440 × 1000: Erststart; Körpergewicht speichern; Workout starten; Übung suchen; zwei verschiedene Satzgewichte und Wiederholungen, RIR, Abschluss, Timer; aktives Workout nach Reload; Workout abschließen; JSON-Datei herunterladen und Inhalte prüfen; vollständiger Import einschließlich eigener Übungen, Satzvorgaben, Plänen, Gewicht, Einstellungen und Video-Metadaten; fehlerhafte Datei abweisen; Import zurücknehmen; Browserprozess schließen; denselben Profilordner offline wieder öffnen; alle Daten erneut als JSON vergleichen.
- Fortschrittsseite, Übungsbibliothek und Video-Oberfläche offline geöffnet. Getrennte Daten unter `/zweite-app/`; identische Daten unter `/forma/` und `/forma/index.html`. Kein horizontaler Überlauf in beiden geprüften Breiten. Keine JavaScript-Laufzeitfehler und keine externen Netzabrufe im geprüften Kernablauf.
- Testdaten waren künstliche QA-Einträge in einem temporären Profil. Die vorhandene veröffentlichte Website und ihre Nutzerdaten wurden nicht verändert.

Reproduzieren:

```sh
npm ci
npm run verify
npx playwright install chromium
npm run test:browser
```

Der Browsertest startet seinen lokalen statischen Server selbst, verwendet ausschließlich `dist/`, räumt sein Profil auf und schreibt Bericht/Screenshots nach `test-results/`. Diese temporären Dateien gehören nicht zum Export. Unter Linux können Browser-Systembibliotheken erforderlich sein (`npx playwright install-deps chromium`).

**Offen:** echter iPhone-/Safari-Test, Installation auf dem Home-Bildschirm, iOS-Speicherdruck und Hintergrundtimer, VoiceOver, Posequalität auf echten Trainingsaufnahmen. Ein WebKit-Start war hier wegen fehlender Systembibliotheken nicht verfügbar; es wird kein Safari-Test behauptet. Der automatische Modelldownload ist nicht Teil des Offline-Kerns. Die folgenden Abschnitte sind die historischen Testprotokolle der übernommenen App-Versionen.


## Ergänzung: Bibliothek und Leistungsvergleich 1.3 (30.09.2026)

66 automatische Tests erfolgreich, Typprüfung erfolgreich. Neue Prüfungen: 275 eindeutige Übungen und gültige Muskel-/Geräte-/Bewegungsdaten, Körpergewichts-/Zeit-/Unterstützungsmodi, deutsche/englische Varianten- und Kürzelsuche, unvermischt erhaltene Deadlift-Historien und Backups. Vergleich: Quellenanker und Tabellenzuordnung, Alters-/Gewichtsklassengrenzen, Jugendliche, nicht vorhandene oder widersprüchliche Referenzen, Trainingserfahrungsfilter, Ausschluss unpassender Übungsvarianten, Epley-/RIR-/RPE-Grenzen, keine künstlich präzisen Ränge und zeitlich passende Körpergewichtseinträge.

Die neue Vergleichskomponente wurde außerdem als SSR-Bundle gerendert: Übung, Eingaben, Quelleninformation und der Zustand einer nicht unterstützten Variante erscheinen ohne Renderfehler. Das ist kein Nachweis interaktiver Bedienung oder mobilen Layouts.

Die Referenzdaten werden reproduzierbar aus dem Original-PDF extrahiert; Gruppen- und Spaltenstruktur sowie ausgewählte Ankerwerte geprüft. Die publizierten Stichprobengrößen wurden zwischen Alters- und Gewichtstabellen abgeglichen und widersprüchliche Alterszellen ausgeschlossen. Keine eigenmächtige Zahlenkorrektur. Auswahl und Limits stehen in COMPARISON_METHOD.md.

Ein echter iPhone-/Safari-Test dieser Erweiterung ist noch offen. Die früheren Browserprüfungen unten belegen nicht die neue Vergleichsansicht. Auf dem iPhone prüfen: Suche „Sumo“, „Stiff Leg“, „Hex Bar“, „Smith RDL“; Übung zum Workout hinzufügen und getrennte Sätze speichern; „Mehr → Leistungsvergleich“ öffnen; Langhantel-Bankdrücken männlich, Alter 17 mit passendem vorhandenen Satz und Körpergewicht auswählen; grobe Jugendreferenz prüfen. Maschine, gleiche Trainingsjahre oder gemeinsamer Alter-/Gewichtsfilter müssen eine begründete Meldung ohne erfundene Perzentile liefern. Wechsel kg/lb sowie hell/dunkel prüfen. Ein tatsächlicher Maximalversuch ist für diese Abnahme nicht nötig.

## Ergänzung: Satzvorgaben 1.2 (30.09.2026)

56 automatische Tests erfolgreich, darunter fünf neue Prüfungen für individuelle Satzwerte, feldweise Übernahme aus der Historie, explizite 0 kg, unabhängige Satzdaten, Vergrößern/Verkleinern der Satzanzahl, Datenmigration 2 → 3, kg/lb, JSON-Roundtrip und Workout-Übernahme als Plan. Typprüfung erfolgreich. Der direkte Aufruf `node .test-build/core.test.js` zeigt alle 56 Fälle; der übergeordnete Node-Testlauf fasst die Datei in dieser Umgebung als einen Test zusammen.

Die neue Oberfläche wurde noch nicht auf einem echten iPhone oder im Browser geprüft. Die bisherigen Browserprüfungen weiter unten beziehen sich auf frühere Versionen. Zusätzlich auf dem iPhone prüfen: Plan bearbeiten → pro Satz unterschiedliche Werte eingeben → Plan speichern und wieder öffnen → starten → einen Satz ändern und abschließen → App neu öffnen. Leere Planfelder sollen historische Werte übernehmen; feste Vorgaben haben Vorrang.

Stand 28.09.2026. Browserprüfungen vom 24.09.2026 und für Fortschritt 1.1 vom 28.09.2026. Keine Behauptung einer vollständigen Gerätefreigabe.

## Automatisch ausgeführt

`pnpm typecheck`: erfolgreich. `pnpm test`: 51 Tests erfolgreich, darunter 20 Fortschrittstests und 6 Prüfungen der erweiterten Übungsbibliothek. Regeln prüfen insbesondere fehlende Daten, Beschwerden/Krankheit/Tagesform, Trainingserfahrung, ausbleibende Laststeigerung bei 10/10/9, RIR/RPE, zu große Lastsprünge, Warm-up-Ausschluss, Technikwechsel, aktive Wiederaufnahme, Pausen/Supersätze, Plateau versus mehr Reserve, Trainingspause, Epley-Grenzen, PRs, Importvalidierung, kg/lb und synthetische Videozyklen/Fehlerfälle.

Bibliothek 1.1.1: enge/breite Rudervarianten und Muskelzuordnung; deutsche/englische Suchbegriffe, beliebige Wortreihenfolge, Umlaute und T-Bar-Schreibweisen; eigene Übungen ohne Suchaliase; verlustfreier Backup-/Import-Roundtrip mit bisherigen und neuen Übungen, Plänen, Favoriten und Notizen. Vorherige Satzwerte, Historie, PRs und Coaching wurden auf Trennung der Griffvarianten geprüft. Diese Ergänzung wurde nicht erneut auf einem echten iPhone oder im Browser getestet.

Neue Prüfungen: Datenmigration 1 → 2, Gewicht im Backup-Roundtrip, ungültige/doppelte Einträge, Kalendertage und Sommerzeit, Monatsenden, eigene Zeiträume, einzelner Gewichtspunkt ohne Trend, Tagesmediane, getrennte Messwochen, Mindestdaten für Prozentwerte, Gewicht-/Wiederholungsvergleich, einzelne schlechte Einheit versus anhaltender Rückgang, Pausen-/Technik-/Satzkontext, Reserve, gleiche Last bei Wiederholungsvergleichen, ungeeignete Lastmodi, Planfilter und genaue Rekordsätze.

`node scripts/check-pwa.mjs` nach Build prüft Manifest, Icons, Cachedateien und Offline-Navigation/Chunks in einer simulierten Service-Worker-Umgebung. Das ist kein echter Browser-Offline- oder iOS-Installationsnachweis.

## Browserprüfung

Der Produktionsbuild vom 28.09.2026 ist erfolgreich. Die PWA-Artefaktprüfung findet 33 lokale Cachedateien einschließlich Fortschrittscode und Dokumentation; Navigation und App-Chunks sind aus dem simulierten Offline-Cache lesbar.

Durchgeführt in Chrome mit betreuter Entwicklungs-Vorschau. Nur eigens angelegte Testdaten, keine importierten Nutzerdaten. Visuell geprüft: Desktop, 390-Pixel-Mobilansicht im eingebetteten Viewport. Diese Mobilansicht emuliert weder iOS noch dessen Tastatur oder Speicherregeln.

Beobachtet: erstes Öffnen, freies Workout, Übungssuche nach englischem Begriff „Smith“, Übung hinzufügen, Gewicht/Wiederholungen/RIR ändern, Satz abschließen, Timer und Wiederaufnahme nach Neuladen, letzten Satz übernehmen, Satzstart markieren, weitere Sätze abschließen, Workout beenden, offene Sätze korrekt getrennt, Historie mit 70 kg × 9 und 1.260 kg Lastvolumen aus zwei erledigten Sätzen. Zusätzlich beobachtet: Workout als Plan speichern, Plan umbenennen, Latzug hinzufügen und umsortieren, gespeicherten Plan öffnen; JSON-Export mit anschließend validierter Datei; Demo-Modus, mobiles Push-Workout mit vorherigen Leistungen, Satzerfassung und Timer; Desktop-Statistiken mit Balken- und Liniendiagramm sowie Bestwerten. Der Dateiauswahl-Dialog für den Import wurde geöffnet; der vollständige Importablauf wurde im Browser noch nicht bestätigt. Backup-Parsing und Validierung sind durch automatisierte Tests abgedeckt.

Behobene Befunde: UUID-Erzeugung brauchte eine getRandomValues-Alternative für die HTTP-Vorschau; 1,25-Schritte wurden anfangs auf 1,3 gerundet; ungültige Modellversion 0.10.22 auf tatsächlich erreichbare 0.10.21 geändert; manuell eingetragene Satzpause wird beim Abschluss erhalten; neue Vergleichskontexte unterbrechen die Progressionshistorie; Speicherfehler zeigen keinen Erfolgstatus; Service Worker unterscheidet App-Navigation von Dokument- und ZIP-Downloads.

Fortschritt 1.1 im Browser am 28.09.2026: Gewicht mit Dezimalkomma gespeichert, Seite neu geladen und denselben Eintrag wieder geöffnet; Diagrammpunkt ausgewählt, Gewicht bearbeitet und gespeichert; einzelner Wert ohne Trend, Tagesfilter mit Datumseingabe per Tastatur und leerem Vortag; Beispielverläufe, Sortierung, englische Suche „Smith“, Übungsdetails, genauer Datenpunkt mit RIR/Pause, Wechsel zu Trainingsvolumen, Wochenansicht mit einem Workout, mobile Favoritenänderung. Bei 390 Pixel breitem Iframe (375 Pixel Nutzbreite wegen Scrollbar) weder auf Startseite noch Übungsdetails horizontales Überlaufen. Screenshots zeigen Beispieldaten. Native Datumseingabe reagierte auf Tastatur; programmatisches Befüllen allein löste in der Browser-Testumgebung keine Änderung aus. Der erneute Downloadversuch im Iframe wurde ausgelöst, die Testverbindung lief beim Warten auf das Downloadereignis in ein Timeout; daher kein zusätzlicher Browsernachweis für Backup-Restore. Die neuen Formate sind automatisch geprüft.

## Noch nicht auf realer Hardware bestätigt

- Safari/iPhone/iPad, tatsächliche Home-Bildschirm-Installation und Splashscreen.
- Echter Offline-Kaltstart unter HTTPS, Update bei mehreren offenen PWA-Instanzen und iOS-Speicherdruck.
- iOS-Tastatur, VoiceOver, Vibration/Ton nach Sperren des Bildschirms.
- Belastbarer Pose-/Wiederholungsbenchmark auf echten Trainingsvideos, unterschiedliche Kleidung, Licht, Verdeckungen und Kamerawinkel.
- Mehrjährige Datenbestände und Browserquoten; Absturz genau während eines Schreibvorgangs.
- Vollständiger Accessibility-Audit, unabhängige anatomische und trainingswissenschaftliche Fachprüfung.

## Reproduzierbare iPhone-Abnahme

1. Auf finalem HTTPS-Link installieren; Home-Bildschirm-App mit Internet starten. Unter Mehr Offlinebereitschaft abwarten.
2. Freies Testworkout → Übung hinzufügen → zwei Sätze erfassen; zwischen den Sätzen App schließen/öffnen. Werte und Timerdeadline müssen erhalten bleiben.
3. Flugmodus aktivieren, App vollständig schließen, neu öffnen, Satz ergänzen und beenden. Historie und Charts prüfen. Flugmodus wieder ausschalten.
4. Neues Template erstellen, zwei Übungen hinzufügen, mit Pfeilen sortieren, eine entfernen; speichern und starten. Früheren Workout als Template sichern und erneut starten.
5. JSON exportieren, Datei prüfen, testweise importieren; Vorschau und Bestätigung beachten. Rücknahme prüfen. Nicht mit ungesicherten echten Daten experimentieren.
6. Helles/dunkles Theme, kg/lb, optional RPE, Satztypen, Timer +30 s und „Reduce Motion“ prüfen.
7. Kurzes seitliches MP4 auswählen, Modell bewusst laden, Ausgabe mit manuell gezählten Wiederholungen vergleichen. Ungeeignete Aufnahme muss Unsicherheit/Fehler zeigen. Abbruch und manuelle Markierung prüfen.
8. Erst nach erfolgreichen Checks die persönliche Alltagsnutzung mit regelmäßigen Backups beginnen.

Offene Punkte sind explizite Grenzen der Abnahme und werden nicht als bestandene Tests ausgegeben.
