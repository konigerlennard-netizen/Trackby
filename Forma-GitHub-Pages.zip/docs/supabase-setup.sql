-- Forma 1.5.0. Run once in your own Supabase SQL Editor.
-- No public workout reads. Every operation is scoped by the authenticated user.
create table if not exists public.forma_heads (
 user_id uuid primary key references auth.users(id) on delete cascade,
 version uuid not null default gen_random_uuid(),
 payload jsonb not null check (payload->>'schema' = '3' and octet_length(payload::text) <= 23068672),
 updated_at timestamptz not null default now()
);
create table if not exists public.forma_snapshots (
 user_id uuid not null references auth.users(id) on delete cascade,
 version uuid not null,
 payload jsonb not null,
 updated_at timestamptz not null,
 primary key (user_id,version)
);
alter table public.forma_heads enable row level security;
alter table public.forma_snapshots enable row level security;
revoke all on public.forma_heads, public.forma_snapshots from anon;
grant select, insert, update, delete on public.forma_heads, public.forma_snapshots to authenticated;
drop policy if exists forma_own_head on public.forma_heads;
create policy forma_own_head on public.forma_heads for all to authenticated
 using ((select auth.uid()) = user_id) with check ((select auth.uid()) = user_id);
drop policy if exists forma_own_snapshots on public.forma_snapshots;
create policy forma_own_snapshots on public.forma_snapshots for all to authenticated
 using ((select auth.uid()) = user_id) with check ((select auth.uid()) = user_id);

create or replace function public.forma_save(expected_version uuid,new_payload jsonb)
returns jsonb language plpgsql security invoker set search_path = '' as $$
declare current_row public.forma_heads; next_row public.forma_heads; account uuid := auth.uid();
begin
 if account is null then raise exception 'Authentication required' using errcode='28000'; end if;
 if new_payload is null or jsonb_typeof(new_payload) <> 'object'
    or (new_payload->>'schema') is distinct from '3' or octet_length(new_payload::text) > 23068672 then
   raise exception 'Invalid payload' using errcode='22023';
 end if;
 select * into current_row from public.forma_heads where user_id=account for update;
 if found then
  if expected_version is distinct from current_row.version then
   raise exception 'Cloud version changed' using errcode='40001';
  end if;
  insert into public.forma_snapshots values (account,current_row.version,current_row.payload,current_row.updated_at)
   on conflict do nothing;
  update public.forma_heads set payload=new_payload,version=gen_random_uuid(),updated_at=clock_timestamp()
   where user_id=account returning * into next_row;
 else
  if expected_version is not null then raise exception 'Cloud version changed' using errcode='40001'; end if;
  begin
   insert into public.forma_heads (user_id,payload) values (account,new_payload) returning * into next_row;
  exception when unique_violation then raise exception 'Cloud version changed' using errcode='40001'; end;
 end if;
 -- Keep the ten most recent pre-update states for this account.
 delete from public.forma_snapshots where user_id=account and version not in
  (select version from public.forma_snapshots where user_id=account order by updated_at desc limit 10);
 return jsonb_build_object('version',next_row.version,'payload',next_row.payload,'updated_at',next_row.updated_at);
end;
$$;
revoke all on function public.forma_save(uuid,jsonb) from public,anon;
grant execute on function public.forma_save(uuid,jsonb) to authenticated;
