# Externe Prüfung der Video-Zählung · 20.10.2026

**Einordnung für 1.15.0:** Die folgenden historischen Ergebnisse gelten nur für den beschriebenen Zählversuch. Der neue grobe Kameracheck und die kameraseitige Auswahlpräferenz wurden damit nicht validiert. Für diese Änderungen existieren lediglich synthetische Regressionstests, keine neu gemessene reale Erkennungsquote. Zählalgorithmus und Modell wurden nicht verändert.

Diese kleine Prüfung testet **nur den vorhandenen Zählalgorithmus** mit bereits berechneten 2D-Gelenkpunkten aus realen Trainingsaufnahmen. Sie testet weder MediaPipe noch Video-Decodierung, Kamera, Touch-Bedienung, Technikhinweise oder die gesamte App auf einem Handy. Es wurden keine Nutzeraufnahmen verwendet und keine Trainingsdaten hochgeladen.

## Quelle und Auswahl

MM-Fit, Strömbäck, Huang & Radu (2020), DOI [10.1145/3432701](https://doi.org/10.1145/3432701). [Projekt und Datendownload](https://mmfit.github.io/), [offizielles Format-/Annotationsnotebook](https://github.com/KDMStromback/mm-fit/blob/master/EDA.ipynb), [separates Videoarchiv](https://doi.org/10.5281/zenodo.7672767). Die Pose-Dateien enthalten Frame-Nummern und 18 Gelenke; CSV-Dateien enthalten Satzgrenzen, Wiederholungszahl und Übung. Quellen geprüft: 20.10.2026.

Vor der Auswertung festgelegte Auswahl: die ersten zwei Sessions w00/w01, die sechs beidseitigen Klassen Kniebeugen, Liegestütze, Schulterdrücken, Rudern, Trizepsstrecken und Seitheben. Alternierende Curls/Ausfallschritte sowie Sit-ups und Jumping Jacks sind ausgeschlossen, weil Seitenzählung bzw. Profil nicht gleich definiert ist. Das ergibt 38 berücksichtigte Sätze und 24 durch die Profilauswahl ausgeschlossene Sätze. Keine Zufallsstichprobe; nur zwei Personen laut Session-Zuordnung des Notebooks. Nicht repräsentativ für Gym-Geräte, Kamerawinkel, Altersgruppen oder Trainingserfahrung.

## Vorgehen

Original-Pixelkoordinaten, 30 fps anhand der Dokumentation, nahe liegende Frames für 8 Abtastungen/s. Fehlende/nichtpositive Gelenkkoordinaten werden ausgelassen. Ellenbogen: Schulter–Ellenbogen–Handgelenk; Knie: Hüfte–Knie–Knöchel; Seitheben: Hüfte–Schulter–Ellenbogen. Die Körperseite wird ausschließlich nach Zahl auswertbarer Samples gewählt; bei Gleichstand links. Keine Auswahl anhand der richtigen Wiederholungszahl. Aus den Winkeln zählt der unveränderte `analyzeCycles`-Code. Die Annotierungen sind Satzgrenzen/-zahlen, keine Ground-Truth-Messungen einzelner Winkel oder Wiederholungsgrenzen.

## Ergebnis

- 38 ausgewählte Sätze; 37 mit einer Zählung, einer durch die bestehende Qualitätsprüfung abgewiesen.
- 16 von 38 exakt (42,1 %).
- 25 von 38 innerhalb ±1 Wiederholung (65,8 %, einschließlich der 16 exakten).
- Mittlerer absoluter Fehler der 37 gezählten Sätze: 1,43 Wiederholungen. Die Abweisung ist separat berichtet und nicht als exakte Zählung oder als Fehler 0 behandelt.

| Übung | Sätze | Gezählt | Exakt | Innerhalb ±1 |
| --- | ---: | ---: | ---: | ---: |
| Kniebeugen | 6 | 6 | 5 | 6 |
| Liegestütze | 6 | 5 | 0 | 0 |
| Schulterdrücken | 6 | 6 | 1 | 6 |
| Rudern | 7 | 7 | 2 | 2 |
| Trizepsstrecken | 7 | 7 | 3 | 5 |
| Seitheben | 6 | 6 | 5 | 6 |

Die Zahlen belegen keine ausreichende Genauigkeit für ungeprüftes automatisches Logging. Schon der Zähler allein kann trotz externer Gelenkpunkte Fehler machen. Die App benötigt deshalb eine sichtbare Nachprüfung/Korrektur; hohe Bildabdeckung darf nicht als Genauigkeitsquote erscheinen. Es wurde bewusst keine Schwelle anhand dieser Testlabels nachjustiert. Eine vollständige Validierung braucht eigene manuell annotierte Videos, das tatsächliche MediaPipe-Modell sowie reale iPhone-/Android-Geräte.

## Reproduzieren

Nach eigenständigem Download der angegebenen Pose-/CSV-Dateien (flat oder in Session-Ordnern), mit Python/numpy und den Projektabhängigkeiten:

```sh
python3 scripts/prepare-mmfit.py /pfad/mm-fit /tmp/mmfit-input.json
node scripts/evaluate-mmfit.mjs /tmp/mmfit-input.json /tmp/mmfit-results.json
```

Alle 38 Einzelergebnisse, Ausschlussliste und SHA-256-Werte der Eingabedateien stehen in `benchmarks/mmfit-counter-1.9.3.json`. Paketiert werden nur eigener Prüfcode und Ergebniskennzahlen. Keine Videobilder, Pose-Dateien oder sonstigen Datenbestände Dritter werden mit der App weitergegeben; die Code-Lizenz des Beispiel-Repositories wird nicht auf den Datensatz übertragen.
