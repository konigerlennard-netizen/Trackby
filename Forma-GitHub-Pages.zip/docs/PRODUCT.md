# Produkt, Konkurrenz und UX

## Ziel

Schnelles deutschsprachiges Trainingstagebuch für iPhone und Desktop. Datenhoheit und transparente Entscheidungshilfen. Kein Social-Ranking, Körpervergleich, Kalorienziel oder Steigerungsdruck.

## Konkurrenzanalyse · geprüft 22.09.2026

Grundlage sind öffentliche Herstellerbeschreibungen, keine vollständigen Praxistests bezahlter Apps und keine Nutzungsstatistik. Häufigkeit tatsächlicher Nutzung lässt sich daraus nicht seriös behaupten.

| Produkt / Primärquelle | Nützliches Bedienkonzept | Entscheidung für Forma |
|---|---|---|
| [Hevy – Tracking](https://www.hevyapp.com/features/track-exercises/) | Vorherige Leistung direkt beim Satz, kurze Wiederverwendung | Vorige Werte sichtbar und antippbar, nächster Satz vorbereitet |
| [Strong](https://www.strong.app/) / [Widgets](https://help.strongapp.io/article/239-profile-widgets) | Fokus auf schnelle Eingabe, Historie/Statistik getrennt | Aktives Workout enthält nur wesentliche Felder; Analyse in eigenen Ansichten |
| [FitNotes – Routinen](https://www.fitnotesapp.com/routines/) / [Einstellungen](https://www.fitnotesapp.com/settings/) | Wiederverwendbare Einheiten, Datenexport | Lokale Templates, Historie als Vorlage, JSON mit Prüfung und Import-Rücknahme |
| [Alpha Progression – Empfehlungen](https://alphaprogression.com/en/glossary/progression-recommendations) | Vorleistungen und Anstrengung für nächste Ziele | Eigenständige dokumentierte Regeln; Vorschlag, Begründung und Unsicherheit sichtbar |

Mögliche Reibungspunkte im eigenen Produkt: zu viele Statistiken zwischen Sätzen, verpflichtende Check-ins, undurchsichtige Empfehlungen und zu kleine Eingabefelder. Deshalb optionale Details in Sheets, große Zahlen, reduzierte Primäraktionen. Keine fremden Designs oder Assets kopiert.

## Umfang

**Must-have, umgesetzt:** freies Workout und Planstart, schnelle Satzfelder und letzte Leistung, IndexedDB mit Transaktionen, Wiederaufnahme, Templates, Suche, Historie, Regeln mit Quellen, Backup/Restore, dunkles/helles Theme, installierbare statische PWA mit Service Worker.

**Should-have, umgesetzt:** Favoriten/eigene Übungen, sortierbare Übungen mit Pfeilalternative, Wochenplan, Supersatz-Gruppen, separate Satztypen, optional RIR/RPE und Tagesform, Timer, PRs, Diagramme, Anatomie, Demo in separater Datenbank, Historie wiederholen/als Template speichern.

**Experimentell:** lokale Video-Pose-Schätzung, grobe Zyklenerkennung, ROM-/Dauervergleich und manueller Zähler. Kein validierter Technikcoach.

**Nicht Bestandteil von v1:** Accounts, Cloud-Sync, verschlüsselte automatische Sicherung, Apple/Google-Login, verlässlicher Hintergrundalarm, automatische Trainingsvolumenoptimierung, vollständige 3D-/Symmetrieanalyse, automatische Aktualisierung wissenschaftlicher Regeln. Schnittstellen und Ausbauweg: ARCHITECTURE.md.

## Benutzerflüsse

1. Heute → vorgeschlagener Plan / freies Workout → optionaler Check-in → Training.
2. Training → Übung suchen → vorherige Last/Wiederholungen übernehmen → Zahlen ändern → Haken → gespeichert + Timer. Details sind optional.
3. Training schließen / Navigation wechseln → aktive Einheit bleibt erhalten → Workout fortsetzen.
4. Beenden → Anzahl erledigter Sätze prüfen → speichern → Historie. Nicht erledigte Sätze werden nicht als Leistung gewertet.
5. Pläne → neuer Plan → Übungen und Vorgaben → sortieren → speichern → starten oder Wochentag zuordnen.
6. Übungsdetail → Verlauf / Coach → „Warum diese Empfehlung?“ → Grundlagen. Keine Erklärungspflicht während des Satzes.
7. Mehr → JSON exportieren. Import → Inhalt prüfen → Ersetzen bestätigen; vorheriger Stand bleibt für Rücknahme.
8. Video → eigene Aufnahme auswählen → Gelenk/Seite → Modell bewusst laden → Ergebnis überprüfen → Messwerte speichern.

## Designsystem

- Systemschrift, große Satzwerte; kein externer Fontdownload.
- Dunkles Anthrazit, abgestufte warme Grautöne, zurückhaltendes helles Grün; helle Variante mit denselben Komponenten.
- Mobile Bottom Navigation: Heute, Workout, Verlauf, Übungen, Mehr. Desktop Sidebar.
- Hauptaktionen mindestens 44 px; Swipe/Drag nicht erforderlich. Sichtbarer Fokus, Labels, Dialogsemantik, Tabellenalternative für Diagramme.
- Kleine CSS-Übergänge statt großer Animationsbibliothek; `prefers-reduced-motion` wird respektiert.
- Keine Leistungs-Rangliste, Streak-Pflicht, Körperideale oder aggressive Erfolgseffekte.

## Produktentscheidungen

Gewichte sind intern kg. Bei Kurzhanteln konsistent dieselbe Eingabekonvention (pro Hantel) nutzen; Gerätegewicht ist nicht geräteübergreifend vergleichbar. Unterstützte Übungen kennzeichnen Hilfe; Zeitübungen verwenden Sekunden. Timer ist eine Uhrzeit, keine zuverlässige Hintergrundbenachrichtigung. Gemessene Pause braucht einen Satzstart oder manuelle Angabe, damit Satzdauer nicht als Pause gezählt wird. Beispielpläne sind editierbare Ausgangspunkte, keine individuelle Belastungsverordnung.
