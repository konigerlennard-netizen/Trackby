# 1.8.1 · 14.10.2026 · Satzanzahl und sichtbare Hinweise

- „Übung anpassen“ zeigt die tatsächliche Zahl der Arbeitssätze und einen eigenen Übernehmen-Button. Zielvorgabe, Satzzeilen und Workout-Zähler werden zusammen in einer Speichertransaktion aktualisiert.
- Reduzieren entfernt nur nach dem Übernehmen offene, unbegonnene Arbeitssätze vom Ende; die Vorschau nennt die betroffenen Zeilen einschließlich ihrer Werte. Begonnene/abgeschlossene Sätze und andere Satztypen bleiben erhalten. Ein zu kleiner Wert wird abgewiesen. Erhöhen ergänzt eigenständige offene Zeilen.
- Trainingspläne und alte Einheiten werden durch eine Anpassung im aktiven Workout nicht geändert. Keine Migration, keine neue Datenbank, keine Änderung der Berechnungen.
- Hinweise einschließlich „Nach App-Update suchen“ stehen in beiden Ausgaben unten. Abstände berücksichtigen Navigation, Home-Indikator, Timer, Workout-Zugang und sichtbare Tastatur.
- Beide Ausgaben sind inhaltlich gleich umfangreich. Android-Unterschiede betreffen die Bedienelemente, nicht die verfügbaren Trainingsfunktionen.

# 1.8.0 · 14.10.2026 · iPhone und Android

- Zwei eigenständig deploybare Ausgaben aus demselben Quellcode. Android: Material-orientierte Auswahlfenster, Suchoption bei langen Listen, Buttons und Bottom Navigation. iPhone: bestehende Glasnavigation und native Formularauswahl erhalten.
- Zeitraumwahl in beiden Ausgaben begrenzt; Datumsfelder und lange Labels können umbrechen. Leistungszeilen trennen Gerät, letzten Satz und Veränderung in kg/Wdh. sowie Prozent. Zunächst fünf Übungen wie bisher.
- Statischer Startschutz und unabhängige `repair.html` ohne App-Abhängigkeiten. Reparatur nur für Cache und Service Worker des eigenen Pfads, keine Datenbankzugriffe. Updateaktivierung mit Sperre gegen Mehrfachklicks und begrenzter Wartezeit; vorheriger Build bleibt für noch offene Tabs verfügbar.
- Keine Änderung von Datenbanknamen, Datenformat, Übungen, Coach- oder Fortschrittsregeln. Kein automatischer Datenübertrag auf andere Geräte/URLs.
- Keine neue Literaturbewertung: diese Version verändert Darstellung und Laden, nicht wissenschaftliche Empfehlungen. Reale iPhone-/Android-Bedienung und Ursache des konkret gemeldeten weißen Bildschirms hier nicht verifiziert.

# 1.7.2 · 13.10.2026 · Eine Fotoauswahl

- „Eigenes Bild“ öffnet die lokale Fotoauswahl direkt, auch wenn schon ein Bild gespeichert ist.
- Redundanten Button „Bild aus Galerie auswählen“ / „Bild ersetzen“ entfernt; Statusmeldung bleibt während der Verarbeitung sichtbar.
- Abbruch ändert keine Einstellungen. Ein gewähltes Bild wird wie bisher erst nach erfolgreichem Speichern aktiviert.
- Keine Änderungen an Speichern, Trainingsdaten, Coach, Icons oder übrigen Funktionen.

# 1.7.1 · 13.10.2026 · Zusammenhängender Schriftzug und Home-Bildschirm-Icon

- Logo oben links und in der Seitenleiste als ein Textlauf „4REPS“ ohne getrenntes 4-Symbol und ohne zusätzlichen Flex-Abstand.
- Eigenes App-Icon zeigt den vollständigen Namen nebeneinander. Neu gerenderte Apple-Touch-, PWA- und Favicon-Dateien mit neuen Pfaden; bestehende Icon-Pfade bleiben ebenfalls gültig.
- Keine Änderung an Datenbanken, Trainings-/Coachinglogik, gespeicherten Einstellungen, App-Adresse oder Manifest-ID.
- Typprüfung, bestehende 123 Tests und Produktions-/PWA-Prüfung; keine neue echte iPhone-Abnahme. Neue PNGs visuell kontrolliert.

# 1.7.0 · 13.10.2026 · 4REPS

- App-Name, Logo, Browser-Titel, PWA-Name und eigene App-Icons auf 4REPS umgestellt. Manifest-ID, Startadresse, Speicherpfad und Backupkennung bleiben gleich. ZIP-Dateiname für den vorhandenen Trackby-Workflow unverändert.
- Heute: eine kompakte Fortschrittsübersicht ganz oben, danach der kleinere Kalender und Trainingspläne. Auf großen Bildschirmen stehen Fortschritt und Kalender nebeneinander. Doppelter Fortschrittsbutton entfernt; Körpergewicht öffnet weiterhin die große Detailansicht.
- Kraftübersicht: zunächst fünf Einträge, weitere in Fünferschritten und wieder einklappbar. Suche und Filter durchsuchen weiterhin die gesamte Bibliothek. Eigene schematische Gerätesymbole ergänzen die Liste.
- Dein Look: Ohne, YOU VS YOU oder eigenes Galeriebild. Foto wird auf dem Gerät verkleinert, neu als JPEG kodiert und getrennt in IndexedDB abgelegt. Kein Foto-Upload, keine Fotoübernahme in Cloud- oder JSON-Backups. Austausch, Entfernen mit Bestätigung und lesbare Abdunklung enthalten.
- Trainingsdatenbank und Format 3 bleiben erhalten; nur die optionale kosmetische Hintergrundwahl wird ergänzt. Ausgeschaltete alte Hintergründe bleiben aus. Kein erneuter Import erforderlich.
- 123 automatisierte Prüfungen sowie Typprüfung bestanden; Prüfgrenzen und manuelle Geräteabnahme siehe TESTING.md.

# 1.6.3 · 13.10.2026

- Körpergewichts- und Übungsänderung: absoluter Wert größer, Prozentzahl kleiner darunter; beide verwenden dieselbe ungerundete Vergleichsbasis. Plus/Minus nutzen die gewählten Änderungsfarben.
- Die Übungen zeigen je nach bestehender Auswertung kg des geschätzten 1RM oder Wiederholungen bei gleicher Last. Kein Vermischen der reinen Laststeigerung mit einer e1RM-Prozentzahl. Vergleichswerte sind in der Erklärung nachlesbar.
- Große Gewichtsdetailansicht, Zeitraumwahl und gespeicherte Farbauswahl bleiben erhalten. Die Farb-Vorschau verwendet dieselbe Darstellung wie der Fortschritt.
- Keine Änderung an IndexedDB, Schema, Import/Export, Plänen, Satzdaten, Coach, Leistungsalgorithmus, Navigation oder Cloud. Keine neue Bibliothek.
- 113 Typ-/Logik-/Speicher-/React-Strukturprüfungen erfolgreich; Grenzen der Browser-/iPhone-Prüfung in TESTING.md.

# 1.6.2 · 12.10.2026

- Körpergewichtskarte auf Heute und Mein Fortschritt öffnet eine große Gewichtsübersicht. Zeitraum bleibt erhalten; Zurück führt zur Fortschrittsliste. Hinzufügen, einzelne Punkte, Notizen, Bearbeiten und bestätigtes Löschen bleiben möglich.
- Große Grafik und direkt sichtbare Messwertliste mit 20 Einträgen je Nachladeschritt. Erster/letzter Wert, Differenz, Messtage und optional geglättete Linie ohne Körperbewertung.
- Vorhandene Änderungswerte erhalten Grün/Rot für Plus/Minus. Eigene Farben unter Dein Look; unabhängig von Haupt-/Diagrammfarbe. Auch in der Übungsdetailansicht sichtbare Prozentänderung mit Berechnungsbasis. Fehlende oder auf null gerundete Werte bleiben neutral.
- Mehr aufgeräumt: kein Demo-Einstieg oder Installationsblock, Datenschutz/Coach unter Über Forma. JSON-Export/-Import und App-Updateprüfung bleiben direkt erreichbar. Rücknahme und Speicheroptionen sind unter Weitere Datenoptionen.
- Optionale `appearance.increase`/`appearance.decrease`; keine neue Schema-/Backupversion oder neue Datenbank. Bestehende Werte werden beim Lesen nicht umgeschrieben. Coach- und Fortschrittsberechnung unverändert.
- TESTING.md unterscheidet Kern-/Struktur-/Build-Prüfungen von noch ausstehender Browser-/iPhone-Abnahme.

# 1.6.1 · 12.10.2026

- Schalter repariert: nur eine berechnete Bewegung des Kreises, feste Abstände in beiden Zuständen und mindestens 44 px hohe Touchfläche. Die sich addierenden CSS-Eigenschaften `translate` und `transform` entfallen.
- Mehr → Dein Look → Farben & Hintergrund: Hauptfarbe für Aktionen/aktive Elemente; zweite Akzentfarbe für Fortschritt, PRs und Diagramme. Sechs Farbvorschläge und freie Farbauswahl, kleine Live-Vorschau, Reset.
- YOU VS YOU als abschaltbarer, statischer Hintergrund hinter leicht durchscheinenden Karten. Trainingskarten bleiben fast deckend; keine neue Hintergrundanimation oder großflächige Unschärfe.
- Helligkeit der gewählten Akzente wird für dunkle/helle Ebenen angepasst. Warn-/Fehlerfarben bleiben eigenständig. Reduzierte Bewegung und reduzierte Transparenz werden berücksichtigt.
- Einstellungen bleiben lokal und werden mit JSON-Backups sowie optionalen Cloud-Snapshots gesichert. Optionales `settings.appearance`; kein Wechsel von Datenbank, Schema-/Backupversion oder Übungs-IDs. Vorhandene Trainingsdaten bleiben erhalten.
- Testumfang und die in diesem Durchlauf fehlende Browser-/iPhone-Prüfung: TESTING.md.

# 1.6.0 · 09.10.2026

- Startseite: interaktiver Kalender mit Wochen-/Monatsansicht, aktuelle Pläne und ein klarer Trainingsstart. Direkter Fortschrittszugang bleibt.
- Entfernt: Leistungsvergleich, automatische Rückblicke auf zuletzt trainierte Einheiten/Übungen, Studienlisten im täglichen Trainingsablauf. Frühere #comparison-Links führen zum persönlichen Fortschritt.
- Bibliothek und Picker: fünf Treffer zum Einstieg, alle aufklappbar; Suche/Filter arbeiten immer über die gesamte Bibliothek.
- Quellen bleiben dokumentiert und optional unter „Über Forma & den Coach“ erreichbar. Keine versteckte Änderung wissenschaftlicher Regeln; kein ständig laufender Internetabruf.
- Datenbank, Schema, Datenpfad, IDs und Backupformat bleiben unverändert. Kalender rechnet mit lokalen Tagen einschließlich Zeitumstellung.

# 1.5.1 · 08.10.2026

- Verschwindende untere Navigation beim Tabwechsel behoben: nur der Seiteninhalt wird animiert, keine dokumentweite Momentaufnahme mehr über der Navigation.
- Glass Pill, Wischbedienung, sanftes Einblenden, Bottom Sheets und reduzierte Bewegung bleiben erhalten. Laufende Seitenanimationen werden beim nächsten Wechsel sauber abgebrochen.
- Neuer Regressionstest prüft tatsächlich gerenderte Pixel während des Übergangs, statt nur die DOM-Sichtbarkeit; zusätzlich schnelle Wechsel, Scrollen, Tastatur-Simulation und 320/390/430-Pixel-Ansichten.
- Einheitliche Versionsanzeige auf Mobilgeräten und Desktop. Keine Änderung an Datenbank, Backupformat, Plänen, Satzdaten, Coaching oder Cloud-Speicherung.

# 1.5.0 · 07.10.2026

- Pläne: einzelne Satzzeilen mit Gewicht/Wiederholungen, direktes Hinzufügen/Entfernen; keine zusätzliche Anzahl-/Von-/Bis-Eingabe in der Hauptansicht. Coach-Ziele eingeklappt, bestehende Werte erhalten.
- Workout: Übungsvariante statt Wiederholungsrange im Kopf. Alle Einzelwerte, RIR/RPE und schnelle Aktionen bleiben erhalten.
- Freiwillige Supabase-Cloud-Sicherung: E-Mail-Code, automatischer Online-Abgleich, Konto-Trennung, Konfliktvorschau, zehn Cloud-Rückfallsicherungen. Projekt muss einmalig eingerichtet werden; Standard bleibt lokal.
- Lokale Datenbank, Schema 3, Übungs-IDs und JSON-Backups unverändert. Cloud-Tokens liegen separat und fehlen in Exporten.
- WebKit: Race zwischen Sheet-Zurück und Workout-Navigation behoben; Abschlussansicht bleibt geöffnet.
- Kein Live-Backend vorkonfiguriert. Einrichtung und Grenzen in CLOUD-SYNC.md.

# Änderungen

## 1.4.1 · 07.10.2026 · Ruhigere Übergänge und klare Fortschrittsnavigation

- „Mein Fortschritt“ ist ein Bereich von „Heute“: kompakte Übersicht, ein gemeinsamer Button zur vollständigen Ansicht, passender Zurück-Button und aktiver Heute-Tab. Der doppelte Link unter „Mehr“ entfällt. Trainingspläne gehören zum Workout-Tab.
- Auf der Startseite zeigen kompakte Übungszeilen die letzte Leistung statt wiederholter Erklärungstexte. Die ausführliche Berechnungsbasis bleibt in der Detailansicht erhalten. „Mehr“ beginnt mit seiner Überschrift und bündelt drei zusätzliche Analysewerkzeuge.
- Ruhige Seitenüberblendung, kurze Bewegungswege und abgestimmtes Abbremsen. Nachgeladene Seiten werden vor dem Übergang vorbereitet. Schnelle Tabwechsel berücksichtigen die letzte Eingabe. Ältere Browser und reduzierte Bewegung haben einen direkten Ersatzpfad.
- Die Glass Pill springt bei einem Fingertipp nicht mehr sofort unter den Finger; kleine Fingerbewegungen lösen noch kein Ziehen aus. Ein abgebrochener Sheet-Drag startet nicht erneut die Öffnungsanimation.
- Schließende Fenster behalten Inhalt und Höhe bis zum Ende des Übergangs. Nach einem Schließ-Swipe bleibt die gezogene Position erhalten. Weniger übereinanderliegende Hintergrundunschärfen senken den Darstellungsaufwand.
- Schmale Startseite und lange Bibliotheksüberschrift verursachen keinen seitlichen Überlauf mehr; eigene Übungen bleiben nach dem Scrollen bedienbar.
- Versionsnummer direkt oben unter „Mehr“. Kein Eingriff in Datenbank, Backupformat, Übungs-IDs oder Coachingregeln.
- Testumfang und verbleibende Hardwaregrenzen sind in TESTING.md dokumentiert. Die Literaturbasis ist unverändert.

## 1.4.0 · 07.10.2026 · Stabilität und einheitliche Oberfläche

- Ausgangsprüfung vor dem Redesign dokumentiert in AUDIT.md; kritische Eingabe- und Navigationsfehler zuerst behoben.
- Schnelle +/- Schritte rechnen innerhalb der vorhandenen Schreibtransaktion mit dem neuesten Satzwert. Numerische Entwürfe werden beim Verlassen des Felds übernommen; Fehler bleiben sichtbar.
- Dialoge haben einen gemeinsamen Zurück-Mechanismus. Ungespeicherte Plan-, Gewichts- und Übungsentwürfe werden beim Schließen geschützt. Übungsersatz benötigt eine ausdrückliche Bestätigung.
- Sofortige Sperren verhindern doppelte Speicherung beim Workout-Abschluss, bei Plan-/Übungsentwürfen, Historienkopien und manueller Videozählung. RIR/RPE im Verlauf verwendet dieselbe Priorität wie aktuelle Satzeingaben.
- Einheitliche neutrale Farbpalette, Radien, Touchflächen und Eingaben; gezieltes Glasmaterial für schwebende Steuerelemente. Eine gemeinsame Glass Pill folgt dem Finger in der Bottom Navigation. Sheets können am Griff heruntergezogen werden. Animationen respektieren reduzierte Bewegung.
- Verbesserte 320-Pixel-Satzanordnung, ein Scrollbereich in der Übungsauswahl, Visual-Viewport-Anpassung für die Bildschirmtastatur und Safe-Area-Abstände. Countdown und Trainingsdauer sind von großen Ansichten getrennt.
- Manuelle Update-Prüfung sowie Prüfung beim Zurückkehren/Onlinegehen. Aktualisierung wird erst außerhalb eines aktiven Workouts angeboten.
- Videoanalyse lässt sich während einer ausstehenden Worker-Antwort sofort abbrechen; ungeeignete Dateien und Modellfehler bleiben verständlich. Analyse weiterhin experimentell, keine neue Genauigkeitsbehauptung.
- Suche findet „breiter Griff“ auch bei als „weiter Griff“ benannten Übungen. Rudern und Latzug bleiben getrennte Übungen.
- Keine Schemaänderung, keine Umbenennung bestehender Übungs-IDs, keine neue wissenschaftliche Coachingregel. Datenbankversion 1, Daten-/Backupformat 3 und Coach 1.0.1 bleiben erhalten. Literatur wurde für dieses UI-Update nicht neu bewertet.
- Verpflichtende zweite Prüfung: 79 Logik-/Speichertests, Chromium- und WebKit-Bedienabläufe sowie echter Service-Worker-Wechsel 1.3.2 → 1.4.0 mit Datenvergleich. Grenzen siehe TESTING.md.

## 1.3.2 · 05.10.2026 · Geräteauswahl und eGym

- Native HTML-Auswahl für Gerät, Muskel und andere einfache Optionen statt verschachtelter Scroll-Portale. Formular-Scrollbereich mit stabiler Höhe und festem Kopfbereich.
- 25 zusätzliche Übungen, insgesamt 300: 18 eGym-Gerätetypen und eine separate Reverse-Grip-Variante, vier weitere Reverse-Preacher-Varianten sowie zwei Überkopf-Trizepsvarianten.
- Vorhandene Überkopf-Trizepsübungen besser benannt und über „Trizepsdrücken über den Kopf“ suchbar; IDs unverändert.
- eGym getrennt von anderen Geräten und Griffen protokollieren; keine 1RM-Schätzung, kein externer Maschinenvergleich und keine automatische Laststeigerung bei unvollständig erfasstem Widerstandsmodus. Coachingregel `smart-machine`, Regelversion 1.0.1. Andere Regeln unverändert; die wissenschaftliche Literatur wurde nicht pauschal neu geprüft.
- Gerätequellen, Unsicherheiten und Grenzen in EXERCISE_CATALOG.md. Kein automatischer EGYM-Datenabruf.
- Datenbankname, Schema und JSON-Format bleiben unverändert. Bestehende Pläne und eigene Übungen werden nicht automatisch ersetzt. Ziel-App vor Import neuer Basisübungen aktualisieren.
- UPDATE-IPHONE.md erklärt den Austausch nur einer ZIP in Trackby, ohne erneute Pages-Einrichtung.

## 1.3.1 · 01.10.2026 · eigenständiger Export

- Reines React-/TypeScript-/Vite-Projekt ohne Sites-, Next-, Vinext-, Login- oder Server-Abhängigkeiten. Reproduzierbarer npm-Lockfile und GitHub-Pages-Workflow.
- Fertige statische Website mit relativen Pfaden, vollständigen Assets, Manifest und Service Worker.
- IndexedDB, Demo-Sitzung und Offline-Caches pro App-Pfad getrennt, damit mehrere GitHub-Projekte sich nicht vermischen.
- Sicherungen lesen den aktuellen Datenbankstand; Import und Rücknahme sind atomar. JSON-Formate 1–3 bleiben lesbar, Exportformat bleibt 3.
- Blockierter Sitzungs-Speicher führt nicht mehr zu einem Fehler beim persönlichen App-Start.
- Zusätzliche Prüfungen für Speicherung, Datenintegrität und Projektpfade. Umzugs- und Installationsanleitung in START-HIER.md.
- Übungsdatenbank, Coachingregeln und wissenschaftliche Aussagen aus 1.3.0 unverändert. Videoanalyse weiterhin lokal; optionale Modell-/Laufzeitdateien werden online geladen.


## 1.3.0 · 30.09.2026

140 zusätzliche Übungen, insgesamt 275. Ausgebaut sind insbesondere Kreuzheben und Hinge-Varianten, weitere Geräte-/Griffvarianten, einseitige Übungen, Arme, Beine, Core und Trageübungen. Suche berücksichtigt jetzt auch das Bewegungsmuster sowie zusätzliche Kürzel und Namen wie RDL, SLDL und Hex Bar. Eigene IDs trennen die Verläufe; alle bisherigen IDs bleiben erhalten. Trap Bar ist als Equipmentfilter verfügbar. Halteübungen verwenden Sekunden, Ringübungen Körpergewicht, unterstützte Übungen keine 1RM-Metadatenfreigabe.

Neuer optionaler Leistungsvergleich über „Mehr“ und Übungsdetails. Geprüfte aggregierte Wettkampf-Referenzzellen, Median/P10/P90, Alters- oder Gewichtsklassenauswahl, bestehende Sätze und manuelle Leistungseingabe, relative Kraft und nur grobe Perzentilbereiche. Sichtbare Ausschlüsse bei fehlenden Daten, unpassenden Varianten, nicht abbildbaren Filtern und widersprüchlichen Quellenangaben. Jugendliche erhalten keine altersgemischte Gewichtsklasseneinordnung. Quelldaten und transparente Regeln sind offline verfügbar.

Vergleichsregeln 1.0.0, gezielte Recherche 30.09.2026. Datenformat/Backup bleiben 3, Trainings-Coachingregeln bleiben 1.0.0. Vergleichseingaben werden nur in dieser Ansicht gehalten und nicht als Profil gespeichert. Keine Übertragung persönlicher Daten.

## 1.2.0 · 29.09.2026

Gewicht und Wiederholungen pro Satz auch in Trainingsplänen. Jede Übung zeigt eigene Satzzeilen; leere Felder übernehmen die vorherige Leistung, feste Werte bleiben individuell. Zusätzliche große Gewicht-/Wiederholungsfelder in den Satzdetails des aktiven Workouts. Beim Speichern eines Workouts als Plan bleiben die erledigten Arbeitssätze mit ihren Werten erhalten.

Datenformat und Backupversion 3; bestehende Daten und Backups der Versionen 1 und 2 werden ohne Verlust übernommen. Ältere App-Tabs vor weiterer Nutzung schließen und aktualisieren, damit sie neue Satzvorgaben nicht verwerfen.

## 1.1.1 · 28.09.2026

Neun zusätzliche Rudervarianten: eng und breit an Multipresse, Langhantel, brustgestützter Maschine und T-Bar sowie enges Kabelrudern. Der vorhandene breite Kabelzug-Eintrag bleibt unter derselben ID erhalten. Damit umfasst die Basisbibliothek 135 Übungen. Die Varianten enthalten eigene Ausführungshinweise, Muskelfokus und Suchbegriffe; Historie, PRs und Coaching werden pro Variante getrennt geführt. Bisherige allgemeine Rudereinträge, eigene Übungen, Pläne und Favoriten bleiben erhalten.

Einheitliche Suche in Bibliothek, Workout-/Planauswahl und Fortschritt: mehrere Suchwörter in beliebiger Reihenfolge, deutsche/englische Namen, Griffbezeichnungen und Umlaute. Anatomische Einordnung und Grenzen anhand zweier akuter EMG-Studien in EVIDENCE.md ergänzt. Datenformat 2 und Coachingregeln 1.0.0 bleiben unverändert.

## 1.1.0 · 28.09.2026

„Mein Fortschritt“ auf der Startseite und als eigene Ansicht: freiwillige Körpergewichtseinträge mit interaktivem Diagramm, Bearbeitung, Tagesmedianen und geglättetem Verlauf. Zeitraum von einem ausgewählten Tag bis zur gesamten Aufzeichnung, einschließlich eigener Datumsgrenzen.

Übungsübersicht mit Suche, Favoriten, sechs Sortierungen und Muskel-/Geräte-/Planfiltern. Detailseiten mit sechs geeigneten Leistungskennzahlen, antippbaren Satzdetails, Historie und automatisch abgeleiteten Bestwerten. Prozententwicklung nur mit ausreichenden vergleichbaren Arbeitssätzen; ein einzelner schlechter Tag wird nicht als anhaltender Rückgang bewertet. Vergleichsregeln und Unsicherheiten stehen in PROGRESS_METHOD.md. Trainings-Coachingregeln bleiben auf 1.0.0.

Datenformat 2 ergänzt Gewichtseinträge. Bestehende Version-1-Daten und Backups werden beim Lesen validiert und verlustfrei um das leere Feld ergänzt. Export enthält Gewichtseinträge; alte App-Versionen können neue Backups nicht importieren. Nach Aktualisierung alte App-Tabs schließen.

## 1.0.0 · 23.09.2026

Erste implementierte Version mit local-first Training, Vorlagen, Historie, 126 Basisübungen, Diagrammen, PRs, eigener Muskelgrafik, Backup/Import-Rücknahme und PWA-Build. Transparente Coachingregeln 1.0.0; Literaturprüfung 22.–23.09.2026. Optionale Videoauswertung experimentell. Automatische Datensynchronisation und Hintergrund-Push gehören nicht zu dieser Version.

Regeländerungen werden künftig hier mit ihren Auswirkungen beschrieben. Daten werden bei einer neuen wissenschaftlichen Einordnung nicht still verändert.
