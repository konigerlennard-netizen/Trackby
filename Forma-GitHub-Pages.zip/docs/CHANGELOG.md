# Änderungen

## 1.4.0 · 07.10.2026 · Stabilität und einheitliche Oberfläche

- Ausgangsprüfung vor dem Redesign dokumentiert in AUDIT.md; kritische Eingabe- und Navigationsfehler zuerst behoben.
- Schnelle +/- Schritte rechnen innerhalb der vorhandenen Schreibtransaktion mit dem neuesten Satzwert. Numerische Entwürfe werden beim Verlassen des Felds übernommen; Fehler bleiben sichtbar.
- Dialoge haben einen gemeinsamen Zurück-Mechanismus. Ungespeicherte Plan-, Gewichts- und Übungsentwürfe werden beim Schließen geschützt. Übungsersatz benötigt eine ausdrückliche Bestätigung.
- Sofortige Sperren verhindern doppelte Speicherung beim Workout-Abschluss, bei Plan-/Übungsentwürfen, Historienkopien und manueller Videozählung. RIR/RPE im Verlauf verwendet dieselbe Priorität wie aktuelle Satzeingaben.
- Einheitliche neutrale Farbpalette, Radien, Touchflächen und Eingaben; gezieltes Glasmaterial für schwebende Steuerelemente. Eine gemeinsame Glass Pill folgt dem Finger in der Bottom Navigation. Sheets können am Griff heruntergezogen werden. Animationen respektieren reduzierte Bewegung.
- Verbesserte 320-Pixel-Satzanordnung, ein Scrollbereich in der Übungsauswahl, Visual-Viewport-Anpassung für die Bildschirmtastatur und Safe-Area-Abstände. Countdown und Trainingsdauer sind von großen Ansichten getrennt.
- Manuelle Update-Prüfung sowie Prüfung beim Zurückkehren/Onlinegehen. Aktualisierung wird erst außerhalb eines aktiven Workouts angeboten.
- Videoanalyse lässt sich während einer ausstehenden Worker-Antwort sofort abbrechen; ungeeignete Dateien und Modellfehler bleiben verständlich. Analyse weiterhin experimentell, keine neue Genauigkeitsbehauptung.
- Suche findet „breiter Griff“ auch bei als „weiter Griff“ benannten Übungen. Rudern und Latzug bleiben getrennte Übungen.
- Keine Schemaänderung, keine Umbenennung bestehender Übungs-IDs, keine neue wissenschaftliche Coachingregel. Datenbankversion 1, Daten-/Backupformat 3 und Coach 1.0.1 bleiben erhalten. Literatur wurde für dieses UI-Update nicht neu bewertet.
- Verpflichtende zweite Prüfung: 79 Logik-/Speichertests, Chromium- und WebKit-Bedienabläufe sowie echter Service-Worker-Wechsel 1.3.2 → 1.4.0 mit Datenvergleich. Grenzen siehe TESTING.md.

## 1.3.2 · 05.10.2026 · Geräteauswahl und eGym

- Native HTML-Auswahl für Gerät, Muskel und andere einfache Optionen statt verschachtelter Scroll-Portale. Formular-Scrollbereich mit stabiler Höhe und festem Kopfbereich.
- 25 zusätzliche Übungen, insgesamt 300: 18 eGym-Gerätetypen und eine separate Reverse-Grip-Variante, vier weitere Reverse-Preacher-Varianten sowie zwei Überkopf-Trizepsvarianten.
- Vorhandene Überkopf-Trizepsübungen besser benannt und über „Trizepsdrücken über den Kopf“ suchbar; IDs unverändert.
- eGym getrennt von anderen Geräten und Griffen protokollieren; keine 1RM-Schätzung, kein externer Maschinenvergleich und keine automatische Laststeigerung bei unvollständig erfasstem Widerstandsmodus. Coachingregel `smart-machine`, Regelversion 1.0.1. Andere Regeln unverändert; die wissenschaftliche Literatur wurde nicht pauschal neu geprüft.
- Gerätequellen, Unsicherheiten und Grenzen in EXERCISE_CATALOG.md. Kein automatischer EGYM-Datenabruf.
- Datenbankname, Schema und JSON-Format bleiben unverändert. Bestehende Pläne und eigene Übungen werden nicht automatisch ersetzt. Ziel-App vor Import neuer Basisübungen aktualisieren.
- UPDATE-IPHONE.md erklärt den Austausch nur einer ZIP in Trackby, ohne erneute Pages-Einrichtung.

## 1.3.1 · 01.10.2026 · eigenständiger Export

- Reines React-/TypeScript-/Vite-Projekt ohne Sites-, Next-, Vinext-, Login- oder Server-Abhängigkeiten. Reproduzierbarer npm-Lockfile und GitHub-Pages-Workflow.
- Fertige statische Website mit relativen Pfaden, vollständigen Assets, Manifest und Service Worker.
- IndexedDB, Demo-Sitzung und Offline-Caches pro App-Pfad getrennt, damit mehrere GitHub-Projekte sich nicht vermischen.
- Sicherungen lesen den aktuellen Datenbankstand; Import und Rücknahme sind atomar. JSON-Formate 1–3 bleiben lesbar, Exportformat bleibt 3.
- Blockierter Sitzungs-Speicher führt nicht mehr zu einem Fehler beim persönlichen App-Start.
- Zusätzliche Prüfungen für Speicherung, Datenintegrität und Projektpfade. Umzugs- und Installationsanleitung in START-HIER.md.
- Übungsdatenbank, Coachingregeln und wissenschaftliche Aussagen aus 1.3.0 unverändert. Videoanalyse weiterhin lokal; optionale Modell-/Laufzeitdateien werden online geladen.


## 1.3.0 · 30.09.2026

140 zusätzliche Übungen, insgesamt 275. Ausgebaut sind insbesondere Kreuzheben und Hinge-Varianten, weitere Geräte-/Griffvarianten, einseitige Übungen, Arme, Beine, Core und Trageübungen. Suche berücksichtigt jetzt auch das Bewegungsmuster sowie zusätzliche Kürzel und Namen wie RDL, SLDL und Hex Bar. Eigene IDs trennen die Verläufe; alle bisherigen IDs bleiben erhalten. Trap Bar ist als Equipmentfilter verfügbar. Halteübungen verwenden Sekunden, Ringübungen Körpergewicht, unterstützte Übungen keine 1RM-Metadatenfreigabe.

Neuer optionaler Leistungsvergleich über „Mehr“ und Übungsdetails. Geprüfte aggregierte Wettkampf-Referenzzellen, Median/P10/P90, Alters- oder Gewichtsklassenauswahl, bestehende Sätze und manuelle Leistungseingabe, relative Kraft und nur grobe Perzentilbereiche. Sichtbare Ausschlüsse bei fehlenden Daten, unpassenden Varianten, nicht abbildbaren Filtern und widersprüchlichen Quellenangaben. Jugendliche erhalten keine altersgemischte Gewichtsklasseneinordnung. Quelldaten und transparente Regeln sind offline verfügbar.

Vergleichsregeln 1.0.0, gezielte Recherche 30.09.2026. Datenformat/Backup bleiben 3, Trainings-Coachingregeln bleiben 1.0.0. Vergleichseingaben werden nur in dieser Ansicht gehalten und nicht als Profil gespeichert. Keine Übertragung persönlicher Daten.

## 1.2.0 · 29.09.2026

Gewicht und Wiederholungen pro Satz auch in Trainingsplänen. Jede Übung zeigt eigene Satzzeilen; leere Felder übernehmen die vorherige Leistung, feste Werte bleiben individuell. Zusätzliche große Gewicht-/Wiederholungsfelder in den Satzdetails des aktiven Workouts. Beim Speichern eines Workouts als Plan bleiben die erledigten Arbeitssätze mit ihren Werten erhalten.

Datenformat und Backupversion 3; bestehende Daten und Backups der Versionen 1 und 2 werden ohne Verlust übernommen. Ältere App-Tabs vor weiterer Nutzung schließen und aktualisieren, damit sie neue Satzvorgaben nicht verwerfen.

## 1.1.1 · 28.09.2026

Neun zusätzliche Rudervarianten: eng und breit an Multipresse, Langhantel, brustgestützter Maschine und T-Bar sowie enges Kabelrudern. Der vorhandene breite Kabelzug-Eintrag bleibt unter derselben ID erhalten. Damit umfasst die Basisbibliothek 135 Übungen. Die Varianten enthalten eigene Ausführungshinweise, Muskelfokus und Suchbegriffe; Historie, PRs und Coaching werden pro Variante getrennt geführt. Bisherige allgemeine Rudereinträge, eigene Übungen, Pläne und Favoriten bleiben erhalten.

Einheitliche Suche in Bibliothek, Workout-/Planauswahl und Fortschritt: mehrere Suchwörter in beliebiger Reihenfolge, deutsche/englische Namen, Griffbezeichnungen und Umlaute. Anatomische Einordnung und Grenzen anhand zweier akuter EMG-Studien in EVIDENCE.md ergänzt. Datenformat 2 und Coachingregeln 1.0.0 bleiben unverändert.

## 1.1.0 · 28.09.2026

„Mein Fortschritt“ auf der Startseite und als eigene Ansicht: freiwillige Körpergewichtseinträge mit interaktivem Diagramm, Bearbeitung, Tagesmedianen und geglättetem Verlauf. Zeitraum von einem ausgewählten Tag bis zur gesamten Aufzeichnung, einschließlich eigener Datumsgrenzen.

Übungsübersicht mit Suche, Favoriten, sechs Sortierungen und Muskel-/Geräte-/Planfiltern. Detailseiten mit sechs geeigneten Leistungskennzahlen, antippbaren Satzdetails, Historie und automatisch abgeleiteten Bestwerten. Prozententwicklung nur mit ausreichenden vergleichbaren Arbeitssätzen; ein einzelner schlechter Tag wird nicht als anhaltender Rückgang bewertet. Vergleichsregeln und Unsicherheiten stehen in PROGRESS_METHOD.md. Trainings-Coachingregeln bleiben auf 1.0.0.

Datenformat 2 ergänzt Gewichtseinträge. Bestehende Version-1-Daten und Backups werden beim Lesen validiert und verlustfrei um das leere Feld ergänzt. Export enthält Gewichtseinträge; alte App-Versionen können neue Backups nicht importieren. Nach Aktualisierung alte App-Tabs schließen.

## 1.0.0 · 23.09.2026

Erste implementierte Version mit local-first Training, Vorlagen, Historie, 126 Basisübungen, Diagrammen, PRs, eigener Muskelgrafik, Backup/Import-Rücknahme und PWA-Build. Transparente Coachingregeln 1.0.0; Literaturprüfung 22.–23.09.2026. Optionale Videoauswertung experimentell. Automatische Datensynchronisation und Hintergrund-Push gehören nicht zu dieser Version.

Regeländerungen werden künftig hier mit ihren Auswirkungen beschrieben. Daten werden bei einer neuen wissenschaftlichen Einordnung nicht still verändert.
