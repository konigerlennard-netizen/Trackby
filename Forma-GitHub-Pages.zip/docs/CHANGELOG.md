# 1.20.0 · 27.10.2026 · Vorlagen einzeln ergänzen

- Elemente hinzufügen direkt unter Einfach, Standard und Detailliert. Alle optionalen Karten, Satzangaben und Übungsbereiche sind ohne Vorlagenwechsel erreichbar.
- Kleine Beispiele, eindeutige Auswahlhaken und direktes Entfernen; Änderungen betreffen nur das gewünschte Element und bleiben bis zum Speichern ein Entwurf.
- Halbe Zeile/Ganze Zeile mit Bildwahl und Vorschau der eigenen Kartenanordnung; Hinweis auf die unveränderte einspaltige Handyansicht.
- Im Anpassungsbereich nur gewählte Satzangaben; weitere Ergänzungen nutzen dieselbe Auswahl. Ansichtwechsel führen zum Anfang und setzen den Tastaturfokus auf die Zurück-Taste.
- Fünf neue Regressionen für gezielte Ergänzungen, Pflichtfelder, Daten, Planbezug, Neustart, Backup, zugängliche Auswahl und Breitenabbildung. Keine neuen Abhängigkeiten oder Datenformate.

# 1.19.0 · 26.10.2026 · Weniger Schritte im Training

- Direkte Übernahme abweichender Satzwerte, automatischer Wechsel nach erfolgreichem Abschluss, abschaltbar.
- Coach-Erklärungen auf Wunsch; Warnhinweise sichtbar und Lastvorschlag in kg/lb.
- Angehefteter Startplan, Wochenplan-Priorität und nächste Position der Planliste.
- Kurze Statistiktexte mit vorhandenen Vergleichsregeln; Wochenvergleich aufklappbar.
- Verlauf direkt wiederholen, einzelne Sätze gezielt korrigieren, vorherige Einheit vergleichen.
- Plan aus letzter Einheit oder Grundvorlage; unabhängige Vorgaben, eindeutige Namen und globale Pause.
- Fehlende Wiederholungen blockieren den Abschluss; auffällige externe Lasten und markierte Schmerzen verlangen Bestätigung. Änderungen werden erneut geprüft.
- Backup-Erinnerung mit Mindestabstand, neuen Einträgen und Sieben-Tage-Ausblendung.
- Optionale workflow-Einstellungen und workflow-v1 zum Schutz vor älteren Tabs. 19 neue Regressionen, keine neue Abhängigkeit oder Schema-Version.

# 1.18.0 · 23.10.2026 · Einfacherer Editor und lesbarer Fortschrittsgraph

- Drei Layout-Karten als Einstieg, getrennte große Vorschau und Anpassung; ein Speicherknopf. Eigene Vorlagen und Zusatzoptionen sind aufklappbar.
- Kartenauswahl mit Pfeilen und Ausblenden; Namen/Farben separat. Workout-Ansicht mit zwei Bildern für untereinander/einzeln und einem Beispiel der Pflichtfelder.
- Gewichtsgraph mit fester Höhe, unverkleinerten Achsen und Punkten, proportionalem Zeitabstand und gepolsterter Skala. Auch kleine Unterschiede, gleiche Werte und einzelne Einträge werden dargestellt.
- Große Gewichtsgrafik verwendet ebenfalls die angepasste Skala. Vorschau zeigt den aktuellen Gewichtsgraphen und die einmalige Pausenangabe.
- Wiederholte Pausenangaben je Übung, doppelte Timer-Einstellungen und Übungsdetail-Knöpfe entfernt. Wochenplan aufklappbar; kürzere Überschriften und Hilfstexte in weiteren Ansichten.
- Fünf zusätzliche Regressionen; vorhandene Speicher-, Konflikt-, Wiederherstellungs- und Timerprüfungen bleiben bestehen. Keine neuen Abhängigkeiten oder Datenformate, keine Änderungen an Animationen.

# 1.17.0 · 23.10.2026 · Bildliche Layout-Vorschauen

- Lesbare Handy-Beispiele statt beschrifteter Platzhalter im Layout-Editor; Reihenfolge, ausgeblendete Karten, Namen, Akzente, Abstände, Fokus und gewählte Satzfelder folgen dem Entwurf.
- Standard, Schnell, Detailliert und eigene Vorlagen mit visuellen Beispielen, Umschaltung zwischen Startseite und Workout sowie vollständiger großer Vorschau.
- Zusätzliche Satzangaben und Schnelleingabe lassen sich in der großen Vorschau öffnen. Beispielwerte sind klar markiert; Einheit und Pausenvorgabe stammen aus den Einstellungen.
- Ungenaue Bewegungszeichnungen in Training, Planbearbeitung, Bibliothek und Übungsauswahl entfernt. Keine neuen Übungsbilder.
- Vorhandener Entwurfs-/Speicherablauf und Planbezug erhalten; kein Datenformatwechsel, keine neuen Abhängigkeiten.

# 1.16.0 · 23.10.2026 · Sicheres Abhaken und nächster Satz

- Fehler behoben: Wiederöffnen eines älteren Satzes entfernte bisher auch den neueren Pausentimer. Eine Pause wird jetzt nur bei eindeutig zugeordnetem, unverändertem Countdown zurückgenommen. Verlängerte oder unklare Timer bleiben erhalten.
- Rückgängig direkt nach dem Abhaken: schützt später bearbeitete Gewichte, Notizen und Pausenangaben sowie zwischenzeitlich neu abgeschlossene Sätze. Alte Aktionen nach erneutem Abschluss, Löschen oder Workout-Ende bleiben wirkungslos.
- Expliziter Vergleich mit dem angezeigten Abschlusszustand; ein verspäteter Tipp kehrt keinen neueren Zustand um. Laufende Abschlussvorgänge werden serialisiert; derselbe Haken ignoriert den zweiten schnellen Tipp für 400 ms nach erfolgreichem Speichern. Fehler sperren keinen erneuten Versuch.
- Sprung zum nächsten offenen Satz mit Übungsname und Satznummer, Tastaturfokus auf der Satzgruppe und Rücksicht auf reduzierte Bewegung. Fokusansicht startet mit der ersten offenen Übung.
- 14 Regressionen einschließlich Speicherung nach Neustart und JSON-Roundtrip. Keine neuen Datenfelder, Abhängigkeiten oder Schemaänderungen.

# 1.15.0 · 22.10.2026 · Startpfad, Display und Kamera

- Optionale Bildschirm-Wachhaltung während sichtbarer laufender Pause, gemeinsam mit Dauer und Automatik gespeichert. Freigabe bei Ende, Hintergrundwechsel, Abschalten oder Entfernen der Ansicht; verspätete Anfragen werden aufgeräumt. Geräteablehnung bleibt sichtbar.
- `rest-display-v1` schützt die neue optionale Einstellung vor älteren Tabs. Atomare Speicherung, Backup, bewusster Import/Reset und Rücknahme; unveränderte DB- und Backup-Versionen.
- Klarer Hinweis: kein garantierter Sperrbildschirm-Alarm. Die Option entsperrt kein Gerät und hält keine Hintergrundausführung am Leben.
- Schlankere Desktop-Navigation und getrennte Übungssuche. Leichtes SVG-Gewichtsdiagramm auf Heute; große Diagramme erst in den Detailansichten. Bestehende Werte, Datumsabstände und Detailbedienung bleiben erhalten.
- Automatische Körperseitenwahl berücksichtigt die manuell gewählte Kameraseite bei ausreichender Abdeckung. Grober Geometriecheck kennzeichnet mögliche Perspektivwidersprüche, ohne die manuelle Angabe zu überschreiben oder neue Technikurteile bei Widerspruch auszugeben.
- 13 neue automatisierte Regressionen. Reproduzierbare Startpfad-Prüfung in `scripts/audit-startup.mjs`; keine echte Kamera-, Handy- oder Browserinteraktionsprüfung und keine Veröffentlichung.

# 1.14.0 · 21.10.2026 · Pausentimer dauerhaft speichern

- Globale Timerdauer mit Minuten/Sekunden, Schnellauswahl und gemeinsamer Bestätigung für Dauer und automatischen Start. Drei Minuten voreingestellt; gültige eigene Dauer: 5 Sekunden bis 60 Minuten.
- Zugriff im Workout, am laufenden Timer und unter Mehr. Gespeicherte Dauer gilt für alle Übungen und nächste Trainings, unabhängig von alten Planvorgaben.
- Einstellung in IndexedDB und Backups; eigener Zusatzwert schützt sie vor älteren offenen Tabs. Bewusster Import/Reset und Rücknahme bleiben möglich.
- Laufender Countdown und gemessene historische Pausen bleiben beim Speichern erhalten. Satzdetails nennen ausdrücklich die optionale gemessene Pause.
- +30s verlängert nur den aktuellen Timer; veraltete Schließen-/Verlängern-Aktionen greifen nicht auf einen neu gestarteten Timer zu.
- Ablaufhinweis wird bei Rückkehr aus dem Hintergrund einmal angezeigt, sofern die Pause inzwischen abgelaufen ist.

# 1.13.0 · 21.10.2026 · Drei-Minuten-Pause und einfache Ansicht

- Einheitliche 180 Sekunden für jeden neu gestarteten Pausentimer, unabhängig von älteren Planvorgaben; neue Trainings übernehmen die feste Pause. Angefangene Timer laufen bis zum nächsten Satz weiter.
- Bereits aufgezeichnete Trainings und tatsächlich gemessene Pausen bleiben erhalten. Abschalten der Automatik sowie das manuelle Schließen oder Verlängern eines Timers bleiben möglich.
- Einheitliche breite Satztabelle auch ohne gespeichertes Layout; optionale Angaben und die Schnelleingabe zunächst geschlossen. Zeitübungen benötigen keine Gewichtsspalte.
- Zahl und Einheit ohne Umbruch; Gewichts- und Wiederholungsregler am Handy untereinander mit genügend Platz zwischen den Tasten.
- Offline-Bewegungssymbole in Trainingskarten, Planauswahl beim Bearbeiten, Übungsbibliothek und Übungsauswahl. Eigene oder nicht zugeordnete Übungen verwenden ein Gerätesymbol.
- Kein neues Datenbankschema, keine neuen externen Bildquellen und keine zusätzlichen Abhängigkeiten.

# 1.12.0 · 21.10.2026 · Schnellere Satzeingabe

- Große Plus/Minus-Tasten für den nächsten offenen Satz; verwendeter Gewichtsschritt direkt pro Übung einstellbar, mit korrekter kg/lb-Umrechnung.
- Zeitübungen mit Fünf-Sekunden-Schritten; klare Bezeichnungen für Zusatzgewicht und Unterstützung.
- Werte aus früheren abgeschlossenen Sätzen desselben Typs oder aus der letzten Einheit übernehmen, mit geschützter Rückgängig-Aktion.
- Schnelle Mehrfachtipps ändern atomar den jeweils aktuellen Wert; abgeschlossene, entfernte und inzwischen weiterbearbeitete Sätze bleiben geschützt.
- Optionale Ersteinrichtung für Grundeinstellungen und die bestehende Wochenplanung; gemeinsames Speichern, Konfliktprüfung und Schutz des Einrichtungsstatus vor älteren Tabs.
- Aktuelle Woche und Vorwoche im gleichen lokalen Wochenabschnitt vergleichen: Workouts, Arbeitssätze, Trainingszeit und externes Lastvolumen.

# 1.11.0 · 21.10.2026 · Namen, Farben und Planansichten

- Eigene Kartennamen mit bis zu 40 Zeichen und fünf dezente Farbakzente plus Standard; Vorschau und Startseite zeigen dieselben Einstellungen.
- Eigene Workout-Ansicht pro Trainingsplan: Satzfelder, Übungsbereiche, Fokus, Trainingsnotiz und Abstände. Neue Pläne übernehmen zunächst das allgemeine Layout; Rückkehr zur allgemeinen Ansicht möglich.
- Vorlagen lassen sich auf die Workout-Ansicht eines Plans anwenden. Kopieren eines Plans übernimmt dessen Ansicht unabhängig. Erneutes Starten eines Workouts behält die ursprüngliche Planzuordnung.
- Neuer atomarer Zusatzschlüssel schützt Kartenstile und Planansichten auch vor noch offenen 1.10-Tabs; JSON, Neustart, bewusster Reset und Import-Rücknahme geprüft.
- Ausgangscode mit ursprünglicher Pages-ZIP abgeglichen: alle 114 App-Dateien bytegleich reproduziert.

# 1.10.0 · 21.10.2026 · Persönliches Layout

- Layout-Editor mit Vorschau, Touch-Griff, Pfeiltasten und Schaltflächen zum Verschieben.
- Startseite: Fortschritt, Kalender, Pläne, Schnellaktionen, Körpergewicht, letztes Training und Coach; Sichtbarkeit und breite Karten am Desktop wählbar.
- Schnellaktionen frei zusammenstellen und sortieren; letzte Einheit über die bestehende Plan-Kopierlogik starten.
- Workout: optionale Felder für vorherige Werte, RIR, RPE, Pause, Notiz, Tempo und Bewegungsumfang; Bereiche umsortieren, Fokus und Trainingsnotiz wählen.
- Drei Vorlagen und bis zu acht eigene Layouts. Änderungen bleiben bis „Layout speichern“ im Entwurf; Standard stellt nur die Ansicht zurück.
- Layout-Metadaten atomar mit Trainingsdaten gespeichert und zusätzlich gegen das Entfernen durch alte Tabs geschützt; Backup und Import-Rücknahme behalten die Einstellungen.

# 1.9.3 · 20.10.2026

- Korrektur automatisch erkannter Wiederholungen: Start/Ende, aktuelle Videoposition, fehlende Wiederholungen, Löschen und Rückkehr zur ursprünglichen Zählung.
- Geprüfte Zeiten, klare Fehler bei Überlappung/ungültigen Eingaben, atomare Speicherung, Doppeltipp-Sperre, erneuter Versuch bei Speicherfehlern und Konfliktprüfung bei parallelen Änderungen.
- Rohzählung, Pose-Samples und ursprüngliche Technikhinweise bleiben erhalten. Korrigierte Anzahl und Dauer sind als manuell korrigiert bezeichnet; kein automatischer Bildmesswertvergleich mit anderen Analysen.
- Optionales Review-Metadatum plus separater atomarer Schutzschlüssel für ältere Tabs; bestehende Hauptschema-, DB- und Backup-Version bleiben unverändert.
- Workout, Pläne, Übungen und Verlauf werden gezielt nachgeladen. Check-in bleibt direkt verfügbar. Details behalten ihre Schließanimationen; fehlgeschlagenes Laden ist erneut versuchbar.
- Fehlerhafte manuelle Diagramm-Bündelung entfernt, die Diagrammcode beim App-Start mitlud. Eigene Ladegrenze für den Fortschrittsbereich auf Heute.
- Reproduzierbare externe Zählprüfung mit MM-Fit-Posen; Grenzen und auch Fehlzählungen dokumentiert. Keine Änderungen am Pose-Modell oder der Zählheuristik auf Basis dieser kleinen Stichprobe.

---

# 1.9.2 · 19.10.2026

- Vorgaben & Notizen: ein gemeinsamer Entwurf ersetzt getrennte Blur-Speicheraktionen. „Alles übernehmen“ übernimmt alle aktuellen Felder in einer Transaktion und schließt nach Erfolg.
- Sperre gegen parallele oder nachlaufende Doppeltipps; Speicherfehler behalten den Entwurf und ermöglichen einen neuen Versuch. Ungültige Eingaben werden erklärt statt still zurückgesetzt.
- Satzzahl wird im selben Commit mit den sichtbaren Zeilen abgeglichen. Begonnene/abgeschlossene Sätze sowie unveränderte Felder und neuere Satzleistungen bleiben geschützt.
- Unsaved-Entwurf beim Schließen bestätigen; erneutes Öffnen beginnt eine neue Editorsitzung. Coach-Karte mit alten gespeicherten Werten wird während Änderungen ausgeblendet.
- Kameraauswahl und Technikhinweise aus 1.9.1 vollständig enthalten. Keine Änderungen an Modell, Coach-Regeln, Datenbankschema, Icons oder Plattformauswahl.

---

# 1.9.1 · 19.10.2026

Kameraperspektive, sichtbare Technikhinweise und nachvollziehbare Grenzen ergänzt. Hinweise werden mit Regelversion 1.0 gespeichert und später nicht stillschweigend neu berechnet. Neue Metadaten bleiben in IndexedDB/JSON erhalten, auch wenn ein älterer 1.9.0-Tab Hauptdaten und Personalisierungsmetadaten schreibt. Vergleich setzt gleiche bekannte Perspektive voraus. Hinweise ohne passende Daten entfallen zugunsten konkreter Aufnahmehilfe. Manuelles Ergebnis wird nach dem Speichern geöffnet; Metadatenentwurf aktualisiert sich bereits während des Tippens. Modelle, Trainingscoach, Icon und Navigation unverändert.

---

# 1.9.0 · 18.10.2026

Persönliche Startseite, Lesbarkeit, Workout-Fokus, lokale Sicherungsverwaltung, individuelle Gewichtsschritte, vorsichtige Coachingregel-Erweiterung 1.1.0, gemeinsame Fortschrittsansicht und Video-Komfortfunktionen.

Sicherheitsverbesserungen: Import prüft die beim Vorschauöffnen gelesene Revision; aktive Workouts blockieren vollständige Wiederherstellung. Zusatz-Snapshot-Fehler rollen Hauptdaten nicht zurück. Neue optionale Metadaten haben eine atomar aktualisierte Sidecar-Kopie gegen das Entfernen unbekannter Felder durch ältere offene Tabs. Übungsauswahl wartet auf erfolgreichen Commit und blockiert Doppeltipps. „Zuletzt“ sortiert wirklich nach Zeitpunkt. Textfelder erfassen ihren Wert vor der asynchronen Speicherung.

Keine Änderung an Icon, PWA-ID, Adresse, Bibliotheks-IDs, bestehender Workout-Statistik oder Cloud-Verhalten. Kein automatisches Umbenennen oder Zusammenlegen persönlicher Übungen.

---

# 1.8.11 · 17.10.2026

- Video: vollständige Modell-/WASM-Dateien lokal im Paket; SDK 1.1.1 und Full-Modell. Telemetriesender gezielt deaktiviert und dokumentiert.
- Bessere Start-/Abbruchbehandlung, dekodierte Frames abwarten, Portrait-4K begrenzen, unterstützter Main-Kontext als Fallback, klare Fehlertexte.
- Automatische Körperseite; keine Zählung durch längere Sichtlücken; beide Ausgangspositionen; Warnung bei mehreren Personen.
- Ausschnitt wählen, Wiederholungen im Video nachprüfen, keine Vermischung alter/neuer Messmethoden, manuelles Speichern ohne Dubletten.
- Update-Prüfung unterscheidet laufenden Download von tatsächlich aktueller Version. Modelle verzögern keine normale PWA-Installation.
- iPhone und Android funktionsgleich; bestehende Plattformauswahlfenster erhalten.
- Schema 3, IndexedDB-Namen, Workout-/Coach-/Fortschrittslogik und App-Icon unverändert. Keine Migration oder erneuter Import nötig.
- Grenzen: synthetische/automatisierte Prüfungen, kein aktueller Geräte- oder Posegenauigkeitsbenchmark.

# 1.8.10 · 17.10.2026

- Im laufenden Workout heißt die Bestätigung unter „Vorgaben & Notizen“ jetzt „Alles übernehmen“. Auch bei unveränderter Satzanzahl nutzbar; ein noch fokussiertes Eingabefeld wird vor der Bestätigung gespeichert. Bestehendes automatisches Speichern der übrigen Vorgaben bleibt erhalten.
- „Workout beenden“ zusätzlich am Ende der Übungsliste nach der Trainingsnotiz. Beide Buttons öffnen dieselbe Abschlussansicht; das Workout wird erst mit „Workout speichern“ abgeschlossen.
- Beide Plattformen, unveränderte Trainingsdaten, Datenbank und App-Icons.

# 1.8.9 · 16.10.2026

- Das Originalzeichen direkt freigestellt, ohne Neugenerierung: 50 Pixel nach links; schwarzer Hintergrund mit 65 % Deckkraft.
- PNG-Alpha bleibt in Apple-Touch-Icon und regulären PWA-Icons erhalten. Maskierbare Android-Ausgabe auf Schwarz für Launcher-Beschnitt. Anzeige von Transparenz abhängig vom Betriebssystem.
- Funktionen und Datenspeicherung unverändert.

# 1.8.8 · 16.10.2026

- Nach abschließender Nutzerentscheidung genau das hochgeladene Originalbild als App-Icon übernommen: weißer Hintergrund, originale Farben und Position. Keine Neugenerierung. Nur Skalierung für die Icon-Größen und zusätzlicher weißer Rand in der maskierbaren Android-Ausgabe.
- Funktionen und Datenspeicherung unverändert.

# 1.8.7 · 16.10.2026

- 4R-App-Icon leicht nach links versetzt und helles Eisglas entsprechend der Nutzervorlage. Dunkler Hintergrund bleibt erhalten.
- Beide Plattformausgaben, Apple-Touch-Icon und Browser-Symbole aktualisiert. Funktionen und Datenspeicherung unverändert.

# 1.8.6 · 16.10.2026

- Dunkles 4R-Glasicon für iOS und Android statt weißer Hintergrundfläche. Neue versionierte Icon-Pfade und aktualisierte Kompatibilitätsdateien.
- Keine Änderung an Trainingsfunktionen oder Datenspeicherung.

# 1.8.5 · 15.10.2026 · Bereitgestelltes 4R-App-Icon

- Das vom Nutzer bereitgestellte gläserne 4R-Motiv ersetzt die bisherigen Icons. Originalbild im Quellcode unverändert behalten; technische Größenumrechnung ohne neue Gestaltung.
- iPhone-Home-Bildschirm: neue 180-px-PNG-Verknüpfung. Android/PWA: neue 192-/512-px-Icons und gepolsterte maskierbare Ausgabe. Browser-Symbole mit 32/64 px. Bestehende alternative Iconpfade enthalten ebenfalls das neue Motiv.
- Neue Icon-Dateinamen, aktualisierte Manifest-Verweise und Versionsanzeige 1.8.5. Der Service-Worker-Build nimmt die neuen Dateien offline auf.
- Keine Änderungen am Feature-Code, App-Namen, Manifest-ID, Startadresse, Speicher, Schema oder Nutzerdaten. Die Korrektur aus 1.8.4 bleibt enthalten. Keine Migration.

# 1.8.4 · 15.10.2026 · Höchster Eintrag als tatsächlicher Satz

- Die Übungsdetails kombinierten bisher das höchste Gewicht mit der höchsten Wiederholungszahl aus möglicherweise verschiedenen Sätzen. Beide Werte stammen jetzt aus genau demselben abgeschlossenen Arbeitssatz.
- Bei gleichem Höchstgewicht wird die höhere Wiederholungszahl bei diesem Gewicht verwendet. Beispiel: 65 kg × 6 und 60 kg × 8 werden als 65 kg × 6 angezeigt.
- Die Beschriftung „Wdh. im selben Satz“ macht den Zusammenhang deutlich. Bei zeitbasierten Übungen steht entsprechend „Sekunden im selben Satz“. Geschätztes 1RM bleibt eine getrennt berechnete und beschriftete Kennzahl.
- Gemeinsame Änderung für iOS und Android. Übersicht und bestehendes Layout bleiben erhalten. Keine Änderung an Datenspeicher, Schema, Satzdaten, Plänen, PR-Erkennung, Fortschrittsberechnung oder Coachingregeln. Keine Migration.

# 1.8.3 · 14.10.2026 · Navigation rechts im Handy-Querformat

- Dieselben fünf Tabs im Querformat rechts untereinander; Hochformat weiterhin unten. iOS behält Glasfläche, Rundungen, Icons und Label; Android behält seine flächige Leiste und aktive Symbolmarkierung. Keine neue Navigationsebene.
- Der iOS-Auswahlindikator wird an den tatsächlichen Tabflächen gemessen, bewegt und dehnt sich entlang der richtigen Achse. Dreh- und Größenwechsel brechen laufende Ziehgesten sauber ab. Die aktuelle Ansicht bleibt erhalten.
- Inhalt, Pausentimer, Workout-Zugang und Hinweise halten Abstand zur rechten Leiste und zu Safe Areas. Bei sehr wenig Höhe wird die Leiste scrollbar statt Tabs abzuschneiden.
- Ausschließlich Darstellung und Navigation geändert. Datenbank, Sätze, Pläne, Zeitraumwahl, Berechnungen und Updateverfahren bleiben erhalten.

# 1.8.2 · 14.10.2026 · Zeitraumwahl und Handy-Querformat

- Zeitraumwahl auf iOS wieder als native Auswahl. Nur die Android-Ausgabe nutzt weiter das eigene Auswahlfenster. Optionen, Werte und Berechnungen sind identisch.
- Konkurrierende feste Breiten entfernt; Zeitraumlabels wie „1 Monat“ bleiben auf einer Zeile. Tages- und Bereichsdatum werden in einem begrenzten Feld angezeigt, über dem das echte native Datumseingabefeld liegt. Beide Betriebssysteme behalten ihre Datumsauswahl, Grenzen und zugänglichen Beschriftungen.
- Auf Touch-Handys im Querformat mit höchstens 600 CSS-Pixeln Höhe bleibt die Navigation mit Heute, Workout, Verlauf, Übungen und Mehr unten sichtbar. Keine Desktop-Seitenleiste beim Drehen. Safe Areas und Hinweisabstände gelten auch quer; breitere Inhalte bleiben möglich.
- Die einzelne „4“ im Desktopkopf war der Einstellungsbutton. Er zeigt jetzt ein beschriftetes Zahnrad; im Handy-Layout bleibt er wie zuvor ausgeblendet.
- Keine Änderung an IndexedDB, Schema, Backups, Training, Coach, Übungen oder Fortschrittsberechnungen. Alle Änderungen aus 1.8.1 bleiben enthalten.

# 1.8.1 · 14.10.2026 · Satzanzahl und sichtbare Hinweise

- „Übung anpassen“ zeigt die tatsächliche Zahl der Arbeitssätze und einen eigenen Übernehmen-Button. Zielvorgabe, Satzzeilen und Workout-Zähler werden zusammen in einer Speichertransaktion aktualisiert.
- Reduzieren entfernt nur nach dem Übernehmen offene, unbegonnene Arbeitssätze vom Ende; die Vorschau nennt die betroffenen Zeilen einschließlich ihrer Werte. Begonnene/abgeschlossene Sätze und andere Satztypen bleiben erhalten. Ein zu kleiner Wert wird abgewiesen. Erhöhen ergänzt eigenständige offene Zeilen.
- Trainingspläne und alte Einheiten werden durch eine Anpassung im aktiven Workout nicht geändert. Keine Migration, keine neue Datenbank, keine Änderung der Berechnungen.
- Hinweise einschließlich „Nach App-Update suchen“ stehen in beiden Ausgaben unten. Abstände berücksichtigen Navigation, Home-Indikator, Timer, Workout-Zugang und sichtbare Tastatur.
- Beide Ausgaben sind inhaltlich gleich umfangreich. Android-Unterschiede betreffen die Bedienelemente, nicht die verfügbaren Trainingsfunktionen.

# 1.8.0 · 14.10.2026 · iPhone und Android

- Zwei eigenständig deploybare Ausgaben aus demselben Quellcode. Android: Material-orientierte Auswahlfenster, Suchoption bei langen Listen, Buttons und Bottom Navigation. iPhone: bestehende Glasnavigation und native Formularauswahl erhalten.
- Zeitraumwahl in beiden Ausgaben begrenzt; Datumsfelder und lange Labels können umbrechen. Leistungszeilen trennen Gerät, letzten Satz und Veränderung in kg/Wdh. sowie Prozent. Zunächst fünf Übungen wie bisher.
- Statischer Startschutz und unabhängige `repair.html` ohne App-Abhängigkeiten. Reparatur nur für Cache und Service Worker des eigenen Pfads, keine Datenbankzugriffe. Updateaktivierung mit Sperre gegen Mehrfachklicks und begrenzter Wartezeit; vorheriger Build bleibt für noch offene Tabs verfügbar.
- Keine Änderung von Datenbanknamen, Datenformat, Übungen, Coach- oder Fortschrittsregeln. Kein automatischer Datenübertrag auf andere Geräte/URLs.
- Keine neue Literaturbewertung: diese Version verändert Darstellung und Laden, nicht wissenschaftliche Empfehlungen. Reale iPhone-/Android-Bedienung und Ursache des konkret gemeldeten weißen Bildschirms hier nicht verifiziert.

# 1.7.2 · 13.10.2026 · Eine Fotoauswahl

- „Eigenes Bild“ öffnet die lokale Fotoauswahl direkt, auch wenn schon ein Bild gespeichert ist.
- Redundanten Button „Bild aus Galerie auswählen“ / „Bild ersetzen“ entfernt; Statusmeldung bleibt während der Verarbeitung sichtbar.
- Abbruch ändert keine Einstellungen. Ein gewähltes Bild wird wie bisher erst nach erfolgreichem Speichern aktiviert.
- Keine Änderungen an Speichern, Trainingsdaten, Coach, Icons oder übrigen Funktionen.

# 1.7.1 · 13.10.2026 · Zusammenhängender Schriftzug und Home-Bildschirm-Icon

- Logo oben links und in der Seitenleiste als ein Textlauf „4REPS“ ohne getrenntes 4-Symbol und ohne zusätzlichen Flex-Abstand.
- Eigenes App-Icon zeigt den vollständigen Namen nebeneinander. Neu gerenderte Apple-Touch-, PWA- und Favicon-Dateien mit neuen Pfaden; bestehende Icon-Pfade bleiben ebenfalls gültig.
- Keine Änderung an Datenbanken, Trainings-/Coachinglogik, gespeicherten Einstellungen, App-Adresse oder Manifest-ID.
- Typprüfung, bestehende 123 Tests und Produktions-/PWA-Prüfung; keine neue echte iPhone-Abnahme. Neue PNGs visuell kontrolliert.

# 1.7.0 · 13.10.2026 · 4REPS

- App-Name, Logo, Browser-Titel, PWA-Name und eigene App-Icons auf 4REPS umgestellt. Manifest-ID, Startadresse, Speicherpfad und Backupkennung bleiben gleich. ZIP-Dateiname für den vorhandenen Trackby-Workflow unverändert.
- Heute: eine kompakte Fortschrittsübersicht ganz oben, danach der kleinere Kalender und Trainingspläne. Auf großen Bildschirmen stehen Fortschritt und Kalender nebeneinander. Doppelter Fortschrittsbutton entfernt; Körpergewicht öffnet weiterhin die große Detailansicht.
- Kraftübersicht: zunächst fünf Einträge, weitere in Fünferschritten und wieder einklappbar. Suche und Filter durchsuchen weiterhin die gesamte Bibliothek. Eigene schematische Gerätesymbole ergänzen die Liste.
- Dein Look: Ohne, YOU VS YOU oder eigenes Galeriebild. Foto wird auf dem Gerät verkleinert, neu als JPEG kodiert und getrennt in IndexedDB abgelegt. Kein Foto-Upload, keine Fotoübernahme in Cloud- oder JSON-Backups. Austausch, Entfernen mit Bestätigung und lesbare Abdunklung enthalten.
- Trainingsdatenbank und Format 3 bleiben erhalten; nur die optionale kosmetische Hintergrundwahl wird ergänzt. Ausgeschaltete alte Hintergründe bleiben aus. Kein erneuter Import erforderlich.
- 123 automatisierte Prüfungen sowie Typprüfung bestanden; Prüfgrenzen und manuelle Geräteabnahme siehe TESTING.md.

# 1.6.3 · 13.10.2026

- Körpergewichts- und Übungsänderung: absoluter Wert größer, Prozentzahl kleiner darunter; beide verwenden dieselbe ungerundete Vergleichsbasis. Plus/Minus nutzen die gewählten Änderungsfarben.
- Die Übungen zeigen je nach bestehender Auswertung kg des geschätzten 1RM oder Wiederholungen bei gleicher Last. Kein Vermischen der reinen Laststeigerung mit einer e1RM-Prozentzahl. Vergleichswerte sind in der Erklärung nachlesbar.
- Große Gewichtsdetailansicht, Zeitraumwahl und gespeicherte Farbauswahl bleiben erhalten. Die Farb-Vorschau verwendet dieselbe Darstellung wie der Fortschritt.
- Keine Änderung an IndexedDB, Schema, Import/Export, Plänen, Satzdaten, Coach, Leistungsalgorithmus, Navigation oder Cloud. Keine neue Bibliothek.
- 113 Typ-/Logik-/Speicher-/React-Strukturprüfungen erfolgreich; Grenzen der Browser-/iPhone-Prüfung in TESTING.md.

# 1.6.2 · 12.10.2026

- Körpergewichtskarte auf Heute und Mein Fortschritt öffnet eine große Gewichtsübersicht. Zeitraum bleibt erhalten; Zurück führt zur Fortschrittsliste. Hinzufügen, einzelne Punkte, Notizen, Bearbeiten und bestätigtes Löschen bleiben möglich.
- Große Grafik und direkt sichtbare Messwertliste mit 20 Einträgen je Nachladeschritt. Erster/letzter Wert, Differenz, Messtage und optional geglättete Linie ohne Körperbewertung.
- Vorhandene Änderungswerte erhalten Grün/Rot für Plus/Minus. Eigene Farben unter Dein Look; unabhängig von Haupt-/Diagrammfarbe. Auch in der Übungsdetailansicht sichtbare Prozentänderung mit Berechnungsbasis. Fehlende oder auf null gerundete Werte bleiben neutral.
- Mehr aufgeräumt: kein Demo-Einstieg oder Installationsblock, Datenschutz/Coach unter Über Forma. JSON-Export/-Import und App-Updateprüfung bleiben direkt erreichbar. Rücknahme und Speicheroptionen sind unter Weitere Datenoptionen.
- Optionale `appearance.increase`/`appearance.decrease`; keine neue Schema-/Backupversion oder neue Datenbank. Bestehende Werte werden beim Lesen nicht umgeschrieben. Coach- und Fortschrittsberechnung unverändert.
- TESTING.md unterscheidet Kern-/Struktur-/Build-Prüfungen von noch ausstehender Browser-/iPhone-Abnahme.

# 1.6.1 · 12.10.2026

- Schalter repariert: nur eine berechnete Bewegung des Kreises, feste Abstände in beiden Zuständen und mindestens 44 px hohe Touchfläche. Die sich addierenden CSS-Eigenschaften `translate` und `transform` entfallen.
- Mehr → Dein Look → Farben & Hintergrund: Hauptfarbe für Aktionen/aktive Elemente; zweite Akzentfarbe für Fortschritt, PRs und Diagramme. Sechs Farbvorschläge und freie Farbauswahl, kleine Live-Vorschau, Reset.
- YOU VS YOU als abschaltbarer, statischer Hintergrund hinter leicht durchscheinenden Karten. Trainingskarten bleiben fast deckend; keine neue Hintergrundanimation oder großflächige Unschärfe.
- Helligkeit der gewählten Akzente wird für dunkle/helle Ebenen angepasst. Warn-/Fehlerfarben bleiben eigenständig. Reduzierte Bewegung und reduzierte Transparenz werden berücksichtigt.
- Einstellungen bleiben lokal und werden mit JSON-Backups sowie optionalen Cloud-Snapshots gesichert. Optionales `settings.appearance`; kein Wechsel von Datenbank, Schema-/Backupversion oder Übungs-IDs. Vorhandene Trainingsdaten bleiben erhalten.
- Testumfang und die in diesem Durchlauf fehlende Browser-/iPhone-Prüfung: TESTING.md.

# 1.6.0 · 09.10.2026

- Startseite: interaktiver Kalender mit Wochen-/Monatsansicht, aktuelle Pläne und ein klarer Trainingsstart. Direkter Fortschrittszugang bleibt.
- Entfernt: Leistungsvergleich, automatische Rückblicke auf zuletzt trainierte Einheiten/Übungen, Studienlisten im täglichen Trainingsablauf. Frühere #comparison-Links führen zum persönlichen Fortschritt.
- Bibliothek und Picker: fünf Treffer zum Einstieg, alle aufklappbar; Suche/Filter arbeiten immer über die gesamte Bibliothek.
- Quellen bleiben dokumentiert und optional unter „Über Forma & den Coach“ erreichbar. Keine versteckte Änderung wissenschaftlicher Regeln; kein ständig laufender Internetabruf.
- Datenbank, Schema, Datenpfad, IDs und Backupformat bleiben unverändert. Kalender rechnet mit lokalen Tagen einschließlich Zeitumstellung.

# 1.5.1 · 08.10.2026

- Verschwindende untere Navigation beim Tabwechsel behoben: nur der Seiteninhalt wird animiert, keine dokumentweite Momentaufnahme mehr über der Navigation.
- Glass Pill, Wischbedienung, sanftes Einblenden, Bottom Sheets und reduzierte Bewegung bleiben erhalten. Laufende Seitenanimationen werden beim nächsten Wechsel sauber abgebrochen.
- Neuer Regressionstest prüft tatsächlich gerenderte Pixel während des Übergangs, statt nur die DOM-Sichtbarkeit; zusätzlich schnelle Wechsel, Scrollen, Tastatur-Simulation und 320/390/430-Pixel-Ansichten.
- Einheitliche Versionsanzeige auf Mobilgeräten und Desktop. Keine Änderung an Datenbank, Backupformat, Plänen, Satzdaten, Coaching oder Cloud-Speicherung.

# 1.5.0 · 07.10.2026

- Pläne: einzelne Satzzeilen mit Gewicht/Wiederholungen, direktes Hinzufügen/Entfernen; keine zusätzliche Anzahl-/Von-/Bis-Eingabe in der Hauptansicht. Coach-Ziele eingeklappt, bestehende Werte erhalten.
- Workout: Übungsvariante statt Wiederholungsrange im Kopf. Alle Einzelwerte, RIR/RPE und schnelle Aktionen bleiben erhalten.
- Freiwillige Supabase-Cloud-Sicherung: E-Mail-Code, automatischer Online-Abgleich, Konto-Trennung, Konfliktvorschau, zehn Cloud-Rückfallsicherungen. Projekt muss einmalig eingerichtet werden; Standard bleibt lokal.
- Lokale Datenbank, Schema 3, Übungs-IDs und JSON-Backups unverändert. Cloud-Tokens liegen separat und fehlen in Exporten.
- WebKit: Race zwischen Sheet-Zurück und Workout-Navigation behoben; Abschlussansicht bleibt geöffnet.
- Kein Live-Backend vorkonfiguriert. Einrichtung und Grenzen in CLOUD-SYNC.md.

# Änderungen

## 1.4.1 · 07.10.2026 · Ruhigere Übergänge und klare Fortschrittsnavigation

- „Mein Fortschritt“ ist ein Bereich von „Heute“: kompakte Übersicht, ein gemeinsamer Button zur vollständigen Ansicht, passender Zurück-Button und aktiver Heute-Tab. Der doppelte Link unter „Mehr“ entfällt. Trainingspläne gehören zum Workout-Tab.
- Auf der Startseite zeigen kompakte Übungszeilen die letzte Leistung statt wiederholter Erklärungstexte. Die ausführliche Berechnungsbasis bleibt in der Detailansicht erhalten. „Mehr“ beginnt mit seiner Überschrift und bündelt drei zusätzliche Analysewerkzeuge.
- Ruhige Seitenüberblendung, kurze Bewegungswege und abgestimmtes Abbremsen. Nachgeladene Seiten werden vor dem Übergang vorbereitet. Schnelle Tabwechsel berücksichtigen die letzte Eingabe. Ältere Browser und reduzierte Bewegung haben einen direkten Ersatzpfad.
- Die Glass Pill springt bei einem Fingertipp nicht mehr sofort unter den Finger; kleine Fingerbewegungen lösen noch kein Ziehen aus. Ein abgebrochener Sheet-Drag startet nicht erneut die Öffnungsanimation.
- Schließende Fenster behalten Inhalt und Höhe bis zum Ende des Übergangs. Nach einem Schließ-Swipe bleibt die gezogene Position erhalten. Weniger übereinanderliegende Hintergrundunschärfen senken den Darstellungsaufwand.
- Schmale Startseite und lange Bibliotheksüberschrift verursachen keinen seitlichen Überlauf mehr; eigene Übungen bleiben nach dem Scrollen bedienbar.
- Versionsnummer direkt oben unter „Mehr“. Kein Eingriff in Datenbank, Backupformat, Übungs-IDs oder Coachingregeln.
- Testumfang und verbleibende Hardwaregrenzen sind in TESTING.md dokumentiert. Die Literaturbasis ist unverändert.

## 1.4.0 · 07.10.2026 · Stabilität und einheitliche Oberfläche

- Ausgangsprüfung vor dem Redesign dokumentiert in AUDIT.md; kritische Eingabe- und Navigationsfehler zuerst behoben.
- Schnelle +/- Schritte rechnen innerhalb der vorhandenen Schreibtransaktion mit dem neuesten Satzwert. Numerische Entwürfe werden beim Verlassen des Felds übernommen; Fehler bleiben sichtbar.
- Dialoge haben einen gemeinsamen Zurück-Mechanismus. Ungespeicherte Plan-, Gewichts- und Übungsentwürfe werden beim Schließen geschützt. Übungsersatz benötigt eine ausdrückliche Bestätigung.
- Sofortige Sperren verhindern doppelte Speicherung beim Workout-Abschluss, bei Plan-/Übungsentwürfen, Historienkopien und manueller Videozählung. RIR/RPE im Verlauf verwendet dieselbe Priorität wie aktuelle Satzeingaben.
- Einheitliche neutrale Farbpalette, Radien, Touchflächen und Eingaben; gezieltes Glasmaterial für schwebende Steuerelemente. Eine gemeinsame Glass Pill folgt dem Finger in der Bottom Navigation. Sheets können am Griff heruntergezogen werden. Animationen respektieren reduzierte Bewegung.
- Verbesserte 320-Pixel-Satzanordnung, ein Scrollbereich in der Übungsauswahl, Visual-Viewport-Anpassung für die Bildschirmtastatur und Safe-Area-Abstände. Countdown und Trainingsdauer sind von großen Ansichten getrennt.
- Manuelle Update-Prüfung sowie Prüfung beim Zurückkehren/Onlinegehen. Aktualisierung wird erst außerhalb eines aktiven Workouts angeboten.
- Videoanalyse lässt sich während einer ausstehenden Worker-Antwort sofort abbrechen; ungeeignete Dateien und Modellfehler bleiben verständlich. Analyse weiterhin experimentell, keine neue Genauigkeitsbehauptung.
- Suche findet „breiter Griff“ auch bei als „weiter Griff“ benannten Übungen. Rudern und Latzug bleiben getrennte Übungen.
- Keine Schemaänderung, keine Umbenennung bestehender Übungs-IDs, keine neue wissenschaftliche Coachingregel. Datenbankversion 1, Daten-/Backupformat 3 und Coach 1.0.1 bleiben erhalten. Literatur wurde für dieses UI-Update nicht neu bewertet.
- Verpflichtende zweite Prüfung: 79 Logik-/Speichertests, Chromium- und WebKit-Bedienabläufe sowie echter Service-Worker-Wechsel 1.3.2 → 1.4.0 mit Datenvergleich. Grenzen siehe TESTING.md.

## 1.3.2 · 05.10.2026 · Geräteauswahl und eGym

- Native HTML-Auswahl für Gerät, Muskel und andere einfache Optionen statt verschachtelter Scroll-Portale. Formular-Scrollbereich mit stabiler Höhe und festem Kopfbereich.
- 25 zusätzliche Übungen, insgesamt 300: 18 eGym-Gerätetypen und eine separate Reverse-Grip-Variante, vier weitere Reverse-Preacher-Varianten sowie zwei Überkopf-Trizepsvarianten.
- Vorhandene Überkopf-Trizepsübungen besser benannt und über „Trizepsdrücken über den Kopf“ suchbar; IDs unverändert.
- eGym getrennt von anderen Geräten und Griffen protokollieren; keine 1RM-Schätzung, kein externer Maschinenvergleich und keine automatische Laststeigerung bei unvollständig erfasstem Widerstandsmodus. Coachingregel `smart-machine`, Regelversion 1.0.1. Andere Regeln unverändert; die wissenschaftliche Literatur wurde nicht pauschal neu geprüft.
- Gerätequellen, Unsicherheiten und Grenzen in EXERCISE_CATALOG.md. Kein automatischer EGYM-Datenabruf.
- Datenbankname, Schema und JSON-Format bleiben unverändert. Bestehende Pläne und eigene Übungen werden nicht automatisch ersetzt. Ziel-App vor Import neuer Basisübungen aktualisieren.
- UPDATE-IPHONE.md erklärt den Austausch nur einer ZIP in Trackby, ohne erneute Pages-Einrichtung.

## 1.3.1 · 01.10.2026 · eigenständiger Export

- Reines React-/TypeScript-/Vite-Projekt ohne Sites-, Next-, Vinext-, Login- oder Server-Abhängigkeiten. Reproduzierbarer npm-Lockfile und GitHub-Pages-Workflow.
- Fertige statische Website mit relativen Pfaden, vollständigen Assets, Manifest und Service Worker.
- IndexedDB, Demo-Sitzung und Offline-Caches pro App-Pfad getrennt, damit mehrere GitHub-Projekte sich nicht vermischen.
- Sicherungen lesen den aktuellen Datenbankstand; Import und Rücknahme sind atomar. JSON-Formate 1–3 bleiben lesbar, Exportformat bleibt 3.
- Blockierter Sitzungs-Speicher führt nicht mehr zu einem Fehler beim persönlichen App-Start.
- Zusätzliche Prüfungen für Speicherung, Datenintegrität und Projektpfade. Umzugs- und Installationsanleitung in START-HIER.md.
- Übungsdatenbank, Coachingregeln und wissenschaftliche Aussagen aus 1.3.0 unverändert. Videoanalyse weiterhin lokal; optionale Modell-/Laufzeitdateien werden online geladen.


## 1.3.0 · 30.09.2026

140 zusätzliche Übungen, insgesamt 275. Ausgebaut sind insbesondere Kreuzheben und Hinge-Varianten, weitere Geräte-/Griffvarianten, einseitige Übungen, Arme, Beine, Core und Trageübungen. Suche berücksichtigt jetzt auch das Bewegungsmuster sowie zusätzliche Kürzel und Namen wie RDL, SLDL und Hex Bar. Eigene IDs trennen die Verläufe; alle bisherigen IDs bleiben erhalten. Trap Bar ist als Equipmentfilter verfügbar. Halteübungen verwenden Sekunden, Ringübungen Körpergewicht, unterstützte Übungen keine 1RM-Metadatenfreigabe.

Neuer optionaler Leistungsvergleich über „Mehr“ und Übungsdetails. Geprüfte aggregierte Wettkampf-Referenzzellen, Median/P10/P90, Alters- oder Gewichtsklassenauswahl, bestehende Sätze und manuelle Leistungseingabe, relative Kraft und nur grobe Perzentilbereiche. Sichtbare Ausschlüsse bei fehlenden Daten, unpassenden Varianten, nicht abbildbaren Filtern und widersprüchlichen Quellenangaben. Jugendliche erhalten keine altersgemischte Gewichtsklasseneinordnung. Quelldaten und transparente Regeln sind offline verfügbar.

Vergleichsregeln 1.0.0, gezielte Recherche 30.09.2026. Datenformat/Backup bleiben 3, Trainings-Coachingregeln bleiben 1.0.0. Vergleichseingaben werden nur in dieser Ansicht gehalten und nicht als Profil gespeichert. Keine Übertragung persönlicher Daten.

## 1.2.0 · 29.09.2026

Gewicht und Wiederholungen pro Satz auch in Trainingsplänen. Jede Übung zeigt eigene Satzzeilen; leere Felder übernehmen die vorherige Leistung, feste Werte bleiben individuell. Zusätzliche große Gewicht-/Wiederholungsfelder in den Satzdetails des aktiven Workouts. Beim Speichern eines Workouts als Plan bleiben die erledigten Arbeitssätze mit ihren Werten erhalten.

Datenformat und Backupversion 3; bestehende Daten und Backups der Versionen 1 und 2 werden ohne Verlust übernommen. Ältere App-Tabs vor weiterer Nutzung schließen und aktualisieren, damit sie neue Satzvorgaben nicht verwerfen.

## 1.1.1 · 28.09.2026

Neun zusätzliche Rudervarianten: eng und breit an Multipresse, Langhantel, brustgestützter Maschine und T-Bar sowie enges Kabelrudern. Der vorhandene breite Kabelzug-Eintrag bleibt unter derselben ID erhalten. Damit umfasst die Basisbibliothek 135 Übungen. Die Varianten enthalten eigene Ausführungshinweise, Muskelfokus und Suchbegriffe; Historie, PRs und Coaching werden pro Variante getrennt geführt. Bisherige allgemeine Rudereinträge, eigene Übungen, Pläne und Favoriten bleiben erhalten.

Einheitliche Suche in Bibliothek, Workout-/Planauswahl und Fortschritt: mehrere Suchwörter in beliebiger Reihenfolge, deutsche/englische Namen, Griffbezeichnungen und Umlaute. Anatomische Einordnung und Grenzen anhand zweier akuter EMG-Studien in EVIDENCE.md ergänzt. Datenformat 2 und Coachingregeln 1.0.0 bleiben unverändert.

## 1.1.0 · 28.09.2026

„Mein Fortschritt“ auf der Startseite und als eigene Ansicht: freiwillige Körpergewichtseinträge mit interaktivem Diagramm, Bearbeitung, Tagesmedianen und geglättetem Verlauf. Zeitraum von einem ausgewählten Tag bis zur gesamten Aufzeichnung, einschließlich eigener Datumsgrenzen.

Übungsübersicht mit Suche, Favoriten, sechs Sortierungen und Muskel-/Geräte-/Planfiltern. Detailseiten mit sechs geeigneten Leistungskennzahlen, antippbaren Satzdetails, Historie und automatisch abgeleiteten Bestwerten. Prozententwicklung nur mit ausreichenden vergleichbaren Arbeitssätzen; ein einzelner schlechter Tag wird nicht als anhaltender Rückgang bewertet. Vergleichsregeln und Unsicherheiten stehen in PROGRESS_METHOD.md. Trainings-Coachingregeln bleiben auf 1.0.0.

Datenformat 2 ergänzt Gewichtseinträge. Bestehende Version-1-Daten und Backups werden beim Lesen validiert und verlustfrei um das leere Feld ergänzt. Export enthält Gewichtseinträge; alte App-Versionen können neue Backups nicht importieren. Nach Aktualisierung alte App-Tabs schließen.

## 1.0.0 · 23.09.2026

Erste implementierte Version mit local-first Training, Vorlagen, Historie, 126 Basisübungen, Diagrammen, PRs, eigener Muskelgrafik, Backup/Import-Rücknahme und PWA-Build. Transparente Coachingregeln 1.0.0; Literaturprüfung 22.–23.09.2026. Optionale Videoauswertung experimentell. Automatische Datensynchronisation und Hintergrund-Push gehören nicht zu dieser Version.

Regeländerungen werden künftig hier mit ihren Auswirkungen beschrieben. Daten werden bei einer neuen wissenschaftlichen Einordnung nicht still verändert.
