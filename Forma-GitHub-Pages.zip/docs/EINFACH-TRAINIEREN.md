# 4REPS 1.13.0 · Einfach trainieren

1. Starte deinen Plan wie gewohnt. Kleine Bewegungssymbole helfen beim Erkennen der Übungen; der Name bleibt daneben. Antippen öffnet die Übungsbeschreibung.
2. Trage Gewicht und Wiederholungen direkt in der Satzzeile ein. Tippe auf den Haken: Die aktivierte Pausenautomatik startet mit **3:00 Minuten**. Das gilt auch für ältere gespeicherte Pläne.
3. Öffne **Mit + / − anpassen**, wenn du die großen Tasten verwenden möchtest. Auf dem Handy hat jeder Regler eine eigene Zeile. Gewicht und Einheit bleiben zusammen, zum Beispiel **82,5 kg**.
4. **Weitere Satzangaben** zeigt die Zusatzfelder deines Layouts. Über die Satznummer öffnest du weiterhin alle Satzdetails. Die drei Punkte an der Übung öffnen ihre Vorgaben und Notizen.

Ist die Pausenautomatik ausgeschaltet, kannst du sie direkt im Workout über **3-Minuten-Pause aktivieren** einschalten. Du kannst einen Timer weiterhin schließen oder manuell verlängern. Ein beim Update laufender Timer wird nicht neu gestartet; die nächste Pause beginnt mit drei Minuten.

Historische Einheiten und tatsächlich gemessene Pausen bleiben erhalten. Die dreiminütige Vorgabe ist kein automatisch eingetragener Messwert. Deine individuellen Layouts, Satznotizen, Gewichte und Backups bleiben nutzbar.

Die Bilder sind kleine Bewegungssymbole. Geräte können anders aussehen; Details zur Ausführung findest du durch Antippen des Übungsnamens. Eigene oder nicht zugeordnete Übungen zeigen das passende Gerätesymbol. Alle Symbole sind ohne Internet verfügbar.

## Update

Nutze die Ausgabe für dein Gerät. Ersetze die bisherige ZIP im GitHub-Repository unter dem exakten Namen **Forma-GitHub-Pages.zip**. Namenszusätze wie **(1)** vor dem Hochladen entfernen. Nach dem erfolgreichen GitHub-Lauf in 4REPS nach Updates suchen. Unter derselben App-Adresse bleiben deine Trainingsdaten erhalten. Erwartete Versionsanzeige: **1.13.0**.
