# 4REPS 1.17.0 · Einfach trainieren

1. Starte deinen Plan wie gewohnt. Übungen stehen mit ihrem Namen und Gerät in der Liste. Die ungenauen Bewegungszeichnungen sind entfernt. Antippen des Namens öffnet die Übungsbeschreibung.
2. Trage Gewicht und Wiederholungen direkt in der Satzzeile ein. Tippe auf den Haken: Die aktivierte Pausenautomatik startet deine gespeicherte Pause, standardmäßig **3:00 Minuten**. Die Vorgabe gilt für alle Übungen und Sätze, auch in älteren Plänen.
3. Über **Pause: 3:00** kannst du die Dauer einmal einstellen und mit **Timer speichern** dauerhaft übernehmen. **+30s** verlängert nur die aktuelle Pause.
4. Öffne **Mit + / − anpassen**, wenn du die großen Tasten verwenden möchtest. Auf dem Handy hat jeder Regler eine eigene Zeile. Gewicht und Einheit bleiben zusammen, zum Beispiel **82,5 kg**.
5. **Weitere Satzangaben** zeigt die Zusatzfelder deines Layouts. Über die Satznummer öffnest du alle Satzdetails. Die drei Punkte an der Übung öffnen ihre Vorgaben und Notizen.
6. **Layout bearbeiten → Vorlagen** zeigt dir Beispiele von Standard, Schnell und Detailliert. Mit **Groß ansehen** liest du die vollständige Vorschau. **Übernehmen** und danach **Layout speichern** aktiviert den Entwurf.

Nach einem abgeschlossenen Satz kannst du die Aktion über **Rückgängig** zurücknehmen. Eine neuere Pause oder später bearbeitete Satzwerte bleiben erhalten. **Nächster offener Satz** hilft beim Fortsetzen.

## Update

Nutze die Ausgabe für dein Gerät. Ersetze die bisherige ZIP im bestehenden GitHub-Repository unter dem exakten Namen **Forma-GitHub-Pages.zip**. Namenszusätze wie **(1)** vor dem Hochladen entfernen. Nach dem erfolgreichen GitHub-Lauf in 4REPS nach Updates suchen. Unter derselben App-Adresse bleiben deine Trainingsdaten erhalten. Erwartete Versionsanzeige: **1.17.0**. Diese Dateien wurden hier nicht veröffentlicht.
