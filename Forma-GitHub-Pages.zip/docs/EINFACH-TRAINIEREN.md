# 4REPS 1.24.0 · Einfach trainieren

1. Starte deinen Plan. Antippen eines Übungsnamens öffnet die Beschreibung.
2. Trage Gewicht und Wiederholungen ein und hake den Satz ab. Die aktivierte Pausenautomatik startet deine gespeicherte Pause, standardmäßig **3:00 Minuten**.
3. Über **Pause: 3:00 → Timer speichern** stellst du die Dauer einmal für alle Übungen und künftigen Trainings ein. **+30s** verlängert nur die aktuelle Pause.
4. **Weitere Satzangaben** zeigt die Zusatzfelder deines Layouts. Die Satznummer öffnet alle Satzdetails. Die Plus/Minus-Schnelleingabe entfällt. Gewicht und Wiederholungen gibst du direkt in die Satzfelder ein.
5. **Workout beenden** ganz unten öffnet den Abschluss. **Workout speichern** bestätigt ihn.

**Unterbrechen** hält Trainingszeit und Satzpause an; **Fortsetzen** lässt beide weiterlaufen. Die Unterbrechung bleibt nach dem Schließen der App erhalten und zählt nicht zur Trainingsdauer.

**Rückgängig** öffnet einen gerade abgeschlossenen Satz wieder. Eine neuere Pause oder später bearbeitete Satzwerte bleiben erhalten. **Nächster offener Satz** hilft beim Fortsetzen.

Unter **Ansicht & Check-in → Layout bearbeiten** findest du Einfach, Standard, Detailliert und Individuell mit Bildern. Unter **Anpassen → Elemente hinzufügen / entfernen** bearbeitest du die Auswahl. Änderungen werden automatisch als Individuell übernommen. **Vorschau** öffnet das große Beispiel, **Anpassen** die Reihenfolge und Darstellung. Erst **Layout speichern** aktiviert die Auswahl. Weitere Hilfe: [LAYOUT.md](LAYOUT.md).

Weitere Bedienung: [TRAININGSABLAUF.md](TRAININGSABLAUF.md).

## Update

Nutze die Ausgabe für dein Gerät. Ersetze die bisherige ZIP im bestehenden Repository unter dem exakten Namen **Forma-GitHub-Pages.zip**, ohne Namenszusätze wie **(1)**. Nach dem erfolgreichen GitHub-Lauf in 4REPS nach Updates suchen. Erwartete Version: **1.24.0**.

Unter derselben App-Adresse bleiben deine Trainingsdaten erhalten. Website-Daten nicht löschen. Diese Dateien wurden hier nicht veröffentlicht.
