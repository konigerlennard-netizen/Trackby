# 4REPS 1.21.0 · Einfach trainieren

1. Starte deinen Plan. Antippen eines Übungsnamens öffnet die Beschreibung.
2. Trage Gewicht und Wiederholungen ein und hake den Satz ab. Die aktivierte Pausenautomatik startet deine gespeicherte Pause, standardmäßig **3:00 Minuten**.
3. Über **Pause: 3:00 → Timer speichern** stellst du die Dauer einmal für alle Übungen und künftigen Trainings ein. **+30s** verlängert nur die aktuelle Pause.
4. **Weitere Satzangaben** zeigt die Zusatzfelder deines Layouts. Die Satznummer öffnet alle Satzdetails. Unter **Mit + / − anpassen** findest du große Tasten; Zahl und Gewichtseinheit bleiben zusammen.
5. **Beenden** oben im Workout öffnet den Abschluss. **Workout speichern** bestätigt ihn.

**Rückgängig** öffnet einen gerade abgeschlossenen Satz wieder. Eine neuere Pause oder später bearbeitete Satzwerte bleiben erhalten. **Nächster offener Satz** hilft beim Fortsetzen.

**Layout bearbeiten** zeigt Einfach, Standard, Detailliert und Individuell mit Bildern. Unter **Anpassen → Elemente hinzufügen / entfernen** bearbeitest du die Auswahl. Änderungen werden automatisch als Individuell übernommen. **Vorschau** öffnet das große Beispiel, **Anpassen** die Reihenfolge und Darstellung. Erst **Layout speichern** aktiviert die Auswahl. Weitere Hilfe: [LAYOUT.md](LAYOUT.md).

Weitere Bedienung: [TRAININGSABLAUF.md](TRAININGSABLAUF.md).

## Update

Nutze die Ausgabe für dein Gerät. Ersetze die bisherige ZIP im bestehenden Repository unter dem exakten Namen **Forma-GitHub-Pages.zip**, ohne Namenszusätze wie **(1)**. Nach dem erfolgreichen GitHub-Lauf in 4REPS nach Updates suchen. Erwartete Version: **1.21.0**.

Unter derselben App-Adresse bleiben deine Trainingsdaten erhalten. Website-Daten nicht löschen. Diese Dateien wurden hier nicht veröffentlicht.
