# Update auf 4REPS 1.8.5

Neu: Dein bereitgestelltes gläsernes 4R-Motiv ist als App-Icon und Browser-Symbol eingebunden. Beide Ausgaben behalten alle bisherigen Funktionen einschließlich der korrekten Gewicht-/Wiederholungszuordnung. App-Adresse, Manifest-ID und Datenspeicher bleiben unverändert. [Details zu beiden Ausgaben](PLATTFORMEN.md).

Die vollständige neue Datei heißt **Forma-GitHub-Pages.zip**. Ersetze im GitHub-Repository genau diese ZIP, damit dein vorhandener Workflow sie verwendet. Zusätze wie `(2)` im Dateinamen entfernen. Es wird nur diese eine ZIP zum Veröffentlichen benötigt; Forma-Quellcode.zip ist für die weitere Entwicklung.

Nach grünem Deployment deine App öffnen → Mehr → Nach App-Update suchen → verfügbares Update übernehmen. Unter Mehr muss **4REPS 1.8.5 · iPhone** bzw. **Android** stehen. Kein Löschen der Website-Daten und kein neuer Import nötig, solange du dieselbe Adresse und denselben Browser/PWA-Speicher verwendest.

**Die alte Seite bleibt weiß?** Nach erfolgreicher Veröffentlichung [Startreparatur](https://konigerlennard-netizen.github.io/Trackby/repair.html) öffnen und **App-Dateien erneuern** antippen. Dies löscht keine Trainingsdatenbank. Andere offene 4REPS-Tabs vorher schließen.

1.7.2 korrigiert den Schriftzug zu **4REPS ohne zusätzliche Lücke zwischen 4 und R** und enthält das überarbeitete Home-Bildschirm-Icon mit dem vollständigen Namen. Der Fortschritt steht oben, der kleinere Kalender darunter; auf breiten Bildschirmen stehen beide nebeneinander. Der doppelte Fortschritt-Knopf entfällt. In der Kraftübersicht siehst du zunächst fünf Übungen mit Gerätesymbolen, weitere auf Knopfdruck. Körpergewicht weiterhin antippen für die große Ansicht. Unter **Mehr → Dein Look → Farben & Hintergrund → Eigenes Bild** kannst du ein Foto wählen. Es bleibt lokal auf diesem Gerät und ist nicht im JSON-Backup oder in der Cloud enthalten.

**Wichtig:** Trotz neuem Namen bleibt die Datei `Forma-GitHub-Pages.zip`, damit dein Workflow weiter funktioniert. Repository, Internetadresse und bisheriger Datenspeicher bleiben gleich. Name/Icon einer bereits installierten App müssen auf deinem iPhone geprüft werden; die Anzeige kann noch die alte Version behalten. Dafür nicht die App oder Website-Daten löschen.

Eine bereits eingerichtete Cloud-Verbindung bleibt erhalten. Falls du Cloud noch nicht eingerichtet hast, bleibt die Speicherung lokal; die freiwillige Einrichtung ist in CLOUD-SYNC.md beschrieben.

---

# 4REPS auf dem iPhone aktualisieren

Version 1.7.2, 13.10.2026. Diese Anleitung gilt für dein bestehendes Repository **Trackby** mit dem bereits eingerichteten ZIP-Workflow.

Du brauchst für dieses Update **nur die neue Forma-GitHub-Pages.zip**. Keine zweite Datei, kein neues Repository, keine neue YAML-Datei, kein Entpacken. Der vorhandene GitHub-Workflow entpackt die ZIP bereits automatisch.

## 1. Deinen Trainingsstand sichern

1. Deine bisherige App wie gewohnt über dein App-Symbol öffnen.
2. Unten **Mehr** antippen.
3. **JSON exportieren** wählen und den Download in der iPhone-App **Dateien** aufbewahren.

Diese JSON-Datei ist dein privates Backup, nicht die Website. **Nicht bei GitHub hochladen.** Deine Daten speichern sich im Alltag weiterhin automatisch. Das Backup ist eine zusätzliche Absicherung vor dem Update.

## 2. Die Website-Datei austauschen

1. Die neue **Forma-GitHub-Pages.zip** aus der Nachricht herunterladen.
2. In **Dateien → Downloads** prüfen, dass sie genau `Forma-GitHub-Pages.zip` heißt. Falls Safari eine `2` oder `(1)` ergänzt hat: die **neu heruntergeladene** Datei lange drücken → **Umbenennen**. Bei einem Namenskonflikt zuerst die alte ZIP anders benennen. ZIP nicht antippen oder entpacken.
3. In Safari [Upload für Trackby öffnen](https://github.com/konigerlennard-netizen/Trackby/upload/main). Bei Bedarf mit deinem GitHub-Konto anmelden.
4. **choose your files** antippen und in **Dateien** die neue `Forma-GitHub-Pages.zip` auswählen.
5. Auf der Upload-Seite sollte nur diese Website-ZIP erscheinen, nicht dein JSON-Backup.
6. Unten **Commit changes** wählen. Falls eine Auswahl erscheint: direkt in **main** speichern. Dadurch wird die gleichnamige ZIP ersetzt.
7. Unter **More → Actions** warten, bis der **neueste** Lauf grün ist. Der alte grüne Lauf reicht nicht als Updatebestätigung.

Nichts an Settings → Pages, Repositoryname, Workflow-Datei oder Internetadresse ändern. Deine bisherigen App-Dateien und der Veröffentlichungsablauf werden durch die neue ZIP aktualisiert. Der Quellcode-Export ist nur für Entwicklung und wird hier nicht zusätzlich hochgeladen.

## 3. Update in der App öffnen

1. Ein aktives Workout vorher speichern/beenden.
2. Andere offene App-Tabs schließen, danach deine installierte App mit Internet öffnen.
3. Wenn **Eine neue App-Version ist bereit** erscheint: **Jetzt aktualisieren** antippen. Falls noch nichts erscheint, kurz warten und die App erneut öffnen.
4. Direkt oben unter **Mehr** sollte **4REPS 1.7.2** stehen. Dort gibt es zusätzlich **Nach App-Update suchen**.
5. Deinen bestehenden Trainingsplan öffnen und die Satzvorgaben prüfen. Die Daten sollten ohne Import weiter vorhanden sein.

Die Adresse bleibt [deine bisherige App](https://konigerlennard-netizen.github.io/Trackby/). Bei gleicher Adresse und gleichem Browser beziehungsweise App-Speicher bleibt die IndexedDB erhalten. Nicht die App oder Safari-Website-Daten löschen, um ein Update zu erzwingen.

## Backup in eine andere Forma-Version übernehmen

Alte App: **Mehr → JSON exportieren**. Ziel-App: zuerst aktualisieren, danach **Mehr → JSON importieren**, Datei wählen und Zusammenfassung bestätigen. Die Ziel-App benötigt einen kompatiblen Forma-Importer. Ein Import **ersetzt** deren bisherigen Stand; er führt zwei Datenstände nicht zusammen. Bei Bedarf beide Stände vorher exportieren.

Eine andere Adresse, Safari statt Home-Bildschirm-App oder ein anderes Gerät kann einen getrennten Speicher haben. In dem Fall dient der JSON-Import zum Umzug. Das ist keine automatische Synchronisation.

Neue Übungs-IDs können in älteren App-Versionen fehlen. Deshalb aktuelle Backups nicht ungeprüft in eine ältere Bearbeitungs-/Vorschauversion importieren. Backups mit bisherigen Übungen bleiben in der neuen Version lesbar. Zwischen 1.3.2 und 1.4.1 bleiben sämtliche Übungs-IDs und das Datenformat unverändert.

## Bereits enthaltene Verbesserungen

- In 1.4.1: sanftere Übergänge, stabil schließende Fenster und Fortschritt direkt unter Heute ohne doppelten Mehr-Eintrag.

- Einheitliches dunkles Design, bewegliche Glas-Auswahl in der Navigation, sanfte Übergänge und nach unten schließbare Dialoge.
- Schnelle Gewichts-/Wiederholungsschritte gehen nicht mehr durch veraltete Eingabewerte verloren.
- Schutz ungespeicherter Planentwürfe und Bestätigung vor dem Ersetzen einer Übung mit ihren Sätzen.
- Korrekte Zurück-Navigation; kompaktere Satzeingabe auf kleinen Displays; weniger unnötige Aktualisierungen beim Timer.
- Vorhandene 300 Basisübungen, eGym-Varianten, eigene Übungen, Statistiken und Coach bleiben enthalten.
- Versionswechsel mit unveränderten Workouts, Plänen, Körpergewicht, Einstellungen und Video-Metadaten getestet. Kein routinemäßiger JSON-Import nach dem Update.

GitHub-Verfahren: [Dateien über den Browser hochladen](https://docs.github.com/en/repositories/working-with-files/managing-files/adding-a-file-to-a-repository). Der ZIP-Workflow von Trackby wurde am 05.10.2026 öffentlich gelesen; er reagiert auf Änderungen und entpackt `Forma-GitHub-Pages.zip` selbst.


## Wenn nach dem Upload noch die alte Version erscheint

1. Für deine bisherige iPhone-Website nur die iPhone-ZIP verwenden. Der Name muss exakt `Forma-GitHub-Pages.zip` bleiben, ohne „(2)“ oder anderen Zusatz. Nicht zusätzlich beide Ausgaben in denselben Website-Ordner legen.
2. Upload mit „Commit changes“ speichern. Unter Actions den **neuesten Lauf passend zu diesem Upload** öffnen. Erst ein erfolgreicher Pages-Deploy veröffentlicht diese Änderung; ein älterer grüner Lauf genügt nicht.
3. Nach erfolgreichem Deploy dieselbe App-Adresse öffnen. Unter Mehr nach App-Update suchen, das angebotene Update übernehmen, danach Versionsanzeige 1.8.3 prüfen.
4. Ist der aktuelle Deploy grün, aber bleibt die App alt oder weiß: `repair.html` unter derselben App-Adresse öffnen, dann „App-Dateien erneuern“. Bei Trackby: https://konigerlennard-netizen.github.io/Trackby/repair.html . Diese Seite funktioniert erst, wenn eine Ausgabe mit Reparaturseite veröffentlicht wurde. Sie löscht keine Trainingsdatenbank.
5. Bei rotem Lauf oder „Something went really wrong“ einen Screenshot der konkreten Meldung und der betroffenen Seite schicken. Nicht vorsorglich den Workflow ersetzen oder Website-Daten löschen.

Offizielle Grundlage: https://docs.github.com/en/pages/getting-started-with-github-pages/configuring-a-publishing-source-for-your-github-pages-site (geprüft am 14.10.2026). Der aktuelle Inhalt deines GitHub-Repositories wurde nicht authentifiziert geprüft.
