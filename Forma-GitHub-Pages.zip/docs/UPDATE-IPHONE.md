# Forma auf dem iPhone aktualisieren

Version 1.3.2, 05.10.2026. Diese Anleitung gilt für dein bestehendes Repository **Trackby** mit dem bereits eingerichteten ZIP-Workflow.

Du brauchst für dieses Update **nur die neue Forma-GitHub-Pages.zip**. Keine zweite Datei, kein neues Repository, keine neue YAML-Datei, kein Entpacken. Der vorhandene GitHub-Workflow entpackt die ZIP bereits automatisch.

## 1. Deinen Trainingsstand sichern

1. Forma wie gewohnt über dein App-Symbol öffnen.
2. Unten **Mehr** antippen.
3. **JSON exportieren** wählen und den Download in der iPhone-App **Dateien** aufbewahren.

Diese JSON-Datei ist dein privates Backup, nicht die Website. **Nicht bei GitHub hochladen.** Deine Daten speichern sich im Alltag weiterhin automatisch. Das Backup ist eine zusätzliche Absicherung vor dem Update.

## 2. Die Website-Datei austauschen

1. Die neue **Forma-GitHub-Pages.zip** aus der Nachricht herunterladen.
2. In **Dateien → Downloads** prüfen, dass sie genau `Forma-GitHub-Pages.zip` heißt. Falls Safari eine `2` oder `(1)` ergänzt hat: die **neu heruntergeladene** Datei lange drücken → **Umbenennen**. Bei einem Namenskonflikt zuerst die alte ZIP anders benennen. ZIP nicht antippen oder entpacken.
3. In Safari [Upload für Trackby öffnen](https://github.com/konigerlennard-netizen/Trackby/upload/main). Bei Bedarf mit deinem GitHub-Konto anmelden.
4. **choose your files** antippen und in **Dateien** die neue `Forma-GitHub-Pages.zip` auswählen.
5. Auf der Upload-Seite sollte nur diese Website-ZIP erscheinen, nicht dein JSON-Backup.
6. Unten **Commit changes** wählen. Falls eine Auswahl erscheint: direkt in **main** speichern. Dadurch wird die gleichnamige ZIP ersetzt.
7. Unter **More → Actions** warten, bis der **neueste** Lauf grün ist. Der alte grüne Lauf reicht nicht als Updatebestätigung.

Nichts an Settings → Pages, Repositoryname, Workflow-Datei oder Internetadresse ändern. Deine bisherigen App-Dateien und der Veröffentlichungsablauf werden durch die neue ZIP aktualisiert. Der Quellcode-Export ist nur für Entwicklung und wird hier nicht zusätzlich hochgeladen.

## 3. Update in Forma öffnen

1. Ein aktives Workout vorher speichern/beenden.
2. Andere offene Forma-Tabs schließen, danach deine installierte Forma-App mit Internet öffnen.
3. Wenn **Eine neue App-Version ist bereit** erscheint: **Jetzt aktualisieren** antippen. Falls noch nichts erscheint, kurz warten und die App erneut öffnen.
4. Unter **Mehr** sollte **Forma 1.3.2** stehen.
5. Deinen bestehenden Trainingsplan öffnen und die Satzvorgaben prüfen. Die Daten sollten ohne Import weiter vorhanden sein.

Die Adresse bleibt [deine bisherige Forma-App](https://konigerlennard-netizen.github.io/Trackby/). Bei gleicher Adresse und gleichem Browser beziehungsweise App-Speicher bleibt die IndexedDB erhalten. Nicht die App oder Safari-Website-Daten löschen, um ein Update zu erzwingen.

## Backup in eine andere Forma-Version übernehmen

Alte App: **Mehr → JSON exportieren**. Ziel-App: zuerst aktualisieren, danach **Mehr → JSON importieren**, Datei wählen und Zusammenfassung bestätigen. Die Ziel-App benötigt einen kompatiblen Forma-Importer. Ein Import **ersetzt** deren bisherigen Stand; er führt zwei Datenstände nicht zusammen. Bei Bedarf beide Stände vorher exportieren.

Eine andere Adresse, Safari statt Home-Bildschirm-App oder ein anderes Gerät kann einen getrennten Speicher haben. In dem Fall dient der JSON-Import zum Umzug. Das ist keine automatische Synchronisation.

Neue Übungs-IDs können in älteren App-Versionen fehlen. Deshalb Daten aus 1.3.2 nicht ungeprüft in eine ältere Bearbeitungs-/Vorschauversion importieren. Backups mit bisherigen Übungen bleiben in der neuen Version lesbar.

## Was geändert wurde

- Native Geräteauswahl statt eines zweiten Scrollmenüs im Formular; Formular bleibt unabhängig scrollbar.
- 300 Basisübungen, einschließlich eGym-Geräten und Reverse Preacher Curls als eigene Griffvariante.
- Überkopf-Trizepsstrecken über den Suchbegriff „Trizepsdrücken über den Kopf“ auffindbar.
- Keine erfundenen Vergleichswerte oder 1RM-Umrechnung für eGym. Trainingsmodus und Gerät für persönliche Vergleiche gleich halten.
- Bestehende Übungen werden im eigenen Plan nicht automatisch ersetzt. Nur die gewünschten Positionen bewusst anpassen; die alte Historie bleibt bei ihrer bisherigen Variante.

GitHub-Verfahren: [Dateien über den Browser hochladen](https://docs.github.com/en/repositories/working-with-files/managing-files/adding-a-file-to-a-repository). Der ZIP-Workflow von Trackby wurde am 05.10.2026 öffentlich gelesen; er reagiert auf Änderungen und entpackt `Forma-GitHub-Pages.zip` selbst.
