# Übungsvarianten und eGym

Geräteinformationen geprüft: 05.10.2026. Keine unabhängige Geräte- oder anatomische Fachprüfung; keine Kooperation oder automatische Verbindung mit EGYM.

## Neue Einträge

19 eGym-Einträge: 18 Bewegungen der offiziellen Smart-Strength-Geräteliste sowie eine separat geführte Reverse-Grip-Variante des Bizepsgeräts. Dazu kommen Reverse Preacher Curls an Maschine, Kabel, SZ-Stange und Kurzhantel, einarmiges Überkopf-Trizepsstrecken mit Kurzhantel und Überkopf-Trizepsstrecken an dafür vorgesehenen Maschinen. Insgesamt 300 Basisübungen.

Überkopf-Trizepsstrecken am Kabel und mit Kurzhantel war bereits vorhanden. Verständlichere Namen und Suchaliase wie „Trizepsdrücken über den Kopf“ verbessern die Auffindbarkeit. Die bisherigen IDs bleiben unverändert. Bestehende Pläne, Historien und selbst angelegte Übungen werden nicht umgeschrieben oder zusammengeführt.

Muskelgruppen beschreiben eine praktische anatomische Zuordnung, keine exakte Verteilung der Beanspruchung. Beim Reverse Curl zählen Brachialis und Unterarmmuskulatur einschließlich Brachioradialis zum Fokus, der Bizeps bleibt beteiligt. Obergriff und Untergriff werden als unterschiedliche Varianten protokolliert. An Maschinen sind Griffmöglichkeiten konstruktionsabhängig: Der Reverse-Grip-Eintrag ist keine Aussage, dass EGYM diese Ausführung für jedes Modell freigibt. Nur nutzen, wenn Griffe und Geräteeinweisung sie erlauben; sonst im Studio klären.

## Geräte und Vergleichbarkeit

- Quelle für verfügbare Gerätetypen: [EGYM Smart Strength](https://de.egym.com/de/workouts/smartstrength). Herstellerquelle, nicht als unabhängiger Wirksamkeitsnachweis genutzt.
- Quelle für wechselnden Widerstand: [EGYM Trainingsmethode Adaptiv](https://de.egym.com/de-de/egym-trainingsmethode-adaptiv). Verwendet wird ausschließlich die Beschreibung der Gerätefunktion. Werbliche Aussagen zu Muskelaufbau, Hormonen, Überlegenheit oder Training über Muskelversagen werden nicht in Forma übernommen.
- Aktuelle Bezeichnungen der Modi: [EGYM Software-Updates](https://de.egym.com/de-de/maschinen-software-updates), Veröffentlichung Juli 2026: „Regulär“ heißt „Standard“, „Negativ“ heißt „Exzentrisch“. Verfügbarkeit und Bezeichnungen hängen vom installierten Softwarestand ab.

Produktentscheidung: keine Umrechnung von eGym-Gewichten auf Hanteln, andere Maschinen oder Perzentile. Keine Epley-1RM-Schätzung bei eGym und keine automatische Laststeigerung ohne ausreichend erfassten Modus. Im externen Leistungsvergleich erscheint „Nicht genügend verlässliche Vergleichsdaten“.

Die lokale Historie dokumentiert trotzdem jeden Satz. Für persönliche Verlaufsvergleiche denselben Gerätetyp, Griff, Modus, Sitz und Bewegungsumfang verwenden und Änderungen in der Techniknotiz der Einheit festhalten. Bei dauerhaft anderer Ausführung eine eigene Übung anlegen. Die App erkennt Moduswechsel nicht automatisch; Angaben in Freitext werden nicht in einen Widerstandsverlauf umgerechnet. Angezeigtes Lastvolumen ist nur Last × Wiederholungen, keine gemessene mechanische Arbeit. Bei wechselndem Widerstand ist eine einzelne Last ein Protokollwert, keine vollständige Leistungskennzahl.

## Backup-Kompatibilität

Datenformat und Exportversion bleiben 3. Alle 275 bisherigen Basis-IDs bleiben gültig. Bestehende Workouts, Planvorgaben, eigene Übungen und Einstellungen werden beim Update nicht ersetzt. Eine neue App liest Backups der Formate 1–3. Ein altes Programm kann ein Backup mit inzwischen neu hinzugekommenen Basisübungen ablehnen; deshalb vor einem Import auch die Ziel-App aktualisieren. Ein Import ersetzt nach Bestätigung den dortigen Stand, er führt Daten nicht zusammen.
