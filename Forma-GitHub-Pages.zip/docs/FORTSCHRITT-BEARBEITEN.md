# Fortschritt und Einträge · 4REPS 1.26.0

## Weniger Bedienelemente

Unter **Mein Fortschritt** bleiben Übungssuche und Sortierung direkt sichtbar. **Filter** aufklappen, um Muskel, Gerät oder Trainingsplan auszuwählen. Die Zahl am Filter zeigt aktive Einschränkungen. **Suche und Filter zurücksetzen** entfernt sie gemeinsam; Sortierung und Zeitraum bleiben erhalten. Die Suche findet auch noch nicht trainierte Übungen.

In den Übungsdetails erscheint die Änderungsanzeige einmal. Eine 1RM-Karte gibt es nur bei geeigneten Übungen mit externer Last und aktivierter Schätzung. Einzelwerte und gleiche Leistungswerte werden im Diagramm benannt und erhalten ausreichend Achsenabstand. Gleiche Werte bilden weiterhin eine waagerechte Reihe. Das ist keine erfundene Steigerung und keine neue Berechnungsmethode. Die eigentliche Anzeige auf einem Handy wurde für diese Version nicht geprüft.

## Körpergewicht korrigieren

Einen Eintrag über den Stift öffnen. Gewicht und Zeitpunkt sind direkt sichtbar, die optionale Notiz lässt sich aufklappen. Eine reine Notizänderung erhält den ursprünglichen Messwert und Zeitstempel exakt, auch bei gerundeter kg-/lb-Anzeige.

Nach Speichern, Ändern oder Löschen erscheint **zehn Sekunden lang „Rückgängig“**. Die Aktion nimmt genau diese Änderung zurück. Inzwischen veränderte oder gelöschte Einträge werden dabei nicht überschrieben. Gleichzeitige Änderungen verschiedener Felder bleiben erhalten; widersprüchliche Eingaben melden einen Konflikt. Nach Ablauf kannst du den Eintrag erneut bearbeiten oder eine vorhandene Sicherung nutzen.

## Neue Pläne erst fertigstellen

**Trainingspläne → Neuer Plan** bietet einen leeren Start, Vorlagen und das letzte abgeschlossene Training an. Die Auswahl öffnet einen Entwurf. Erst **Plan speichern** legt ihn in der Übersicht an. Beim Verwerfen wird kein neuer Plan angelegt. Der ungespeicherte Entwurf ist nicht für einen App-Neustart gesichert.

Beim Übernehmen des letzten Trainings bleiben die Satzvorgaben und eine vorhandene planbezogene Workout-Ansicht im Entwurf. Beim endgültigen Speichern gilt die dann gespeicherte globale Pause. Bereits bestehende Pläne und das laufende Training werden dadurch nicht verändert. Direktes **Kopieren** beziehungsweise **Als Plan speichern** im Verlauf bleiben ausdrückliche Speicheraktionen.
