# 1.9.3 · Korrigieren und nachprüfen

Unter **Zählung prüfen** lassen sich Wiederholungen ergänzen, entfernen oder zeitlich anpassen. **Hier** übernimmt die aktuelle Position des geöffneten Videos relativ zum Beginn des analysierten Ausschnitts. Die Vorschau spielt die ausgewählten Grenzen ab. Gespeicherte Analysen ohne geöffnetes Original erlauben nur die Zeitbearbeitung; das Original bleibt weiterhin in Fotos und wird nicht heimlich gespeichert oder hochgeladen.

Alle Zeiten müssen innerhalb des Ausschnitts liegen, mindestens 0,1 Sekunden umfassen und dürfen einander nicht überlappen. Die 0,1 Sekunden sind eine Eingabegrenze, kein sportwissenschaftlicher Grenzwert. Vor dem Speichern wird zeitlich sortiert. Auch eine bestätigte Zählung von 0 ist zulässig; dann wird keine durchschnittliche Dauer erfunden.

`review` speichert Version 1.0, Bearbeitungszeit und korrigierte Zeitgrenzen. Automatische Rohzählung, Amplitude, Samples und Hinweissnapshot bleiben unverändert. Die UI kennzeichnet die korrigierte Anzahl/Dauer und die ursprünglichen Bildmesswerte. Die Technikhinweise beziehen sich weiterhin auf die ursprünglichen Zyklen; es entsteht keine neue Technikbewertung durch manuelle Eingaben. Automatische Videovergleiche schließen korrigierte Analysen aus, bis die Korrektur zurückgesetzt wird.

Korrektur speichern erstellt bei einer neuen Aufnahme zugleich ihren Analyse-Eintrag. Bei vorhandenen Analysen wird nur das Review geändert; zwischenzeitlich gelöschte oder anders korrigierte Einträge werden nicht still überschrieben. Entwürfe bleiben bei Speicherfehlern offen. Die Rohdaten lassen sich über **Ursprüngliche Erkennung wiederherstellen** erneut anzeigen.

Zusätzliche Prüfung: VIDEO_BENCHMARK.md beschreibt 38 annotierte Sätze aus bereits berechneten 2D-Posen. Die Ergebnisse zeigen deutliche Grenzen der Zählung. Die Prüfung validiert weder das in der App verwendete Pose-Modell noch die Technikhinweise oder die Wiedergabe/Decodierung auf Handys.

---

# 1.9.1 · Kameraperspektive und Technikhinweise

Stand und gezielte Quellenprüfung: **19. Oktober 2026**. Messmethode bleibt „4REPS Video 2.0“; neue Hinweismethode **1.0**. Kein neues Modell und kein Versprechen höherer gemessener Pose-Genauigkeit.

## Was die Funktion tut

Sie schätzt sichtbare Gelenkpunkte, zählt geeignete 2D-Bewegungszyklen und beschreibt Veränderungen innerhalb des gefilmten Satzes. Sie liefert keine vollständige biomechanische Analyse, keine Diagnose, keine Beurteilung von Wirbelsäule/Schulterblättern, keine tatsächliche Gelenk-ROM und keine Ermittlung von RIR, Muskelaktivierung oder Hantelgeschwindigkeit.

## Kameraperspektive

Der Nutzer wählt vorne, hinten, seitlich links, seitlich rechts, schräg/wechselnd oder unbekannt. Links/rechts beziehen sich auf die Körperseite vor der Kamera, nicht auf den Bildschirm. Die Analyse übernimmt diese Angabe, sie verifiziert sie nicht automatisch. Gespiegelte Aufnahmen beachten.

- Ellenbogen-, Knie- und Hüftwinkel: für Verlaufshinweise seitliche Perspektive erforderlich.
- Schulterprofil für Seitheben: Front- oder Rückansicht; keine Schulterblattbewertung. Gesicht/Orientierung und Überlappungen können die Erkennung besonders von hinten erschweren.
- Unbekannte/schräge Perspektive, nicht abgestimmte Bewegung (z. B. Core, Tragen, Waden) und widersprüchliche Kamera-/Körperseite: keine aus den Messwerten abgeleiteten Technikempfehlungen.
- Die Zählung kann trotzdem versucht und im Original geprüft werden. Bei ungeeigneter Aufnahme manuell markieren. Körper einschließlich Kopf und relevanter Gelenke im Bild lassen, Kamera ruhig halten, gutes Licht.

## Transparente Produktregeln

Voraussetzung für Verlaufshinweise: passende angegebene Perspektive, mindestens 85 % auswertbare Bilder, mindestens vier vollständige Zyklen, gültige nicht überlappende Messungen, mindestens vier Messpunkte je Zyklus, keine Sichtlücke über 0,45 s und abgedeckte Zyklusgrenzen. Diese Schwellen sind **nicht als klinische oder sportwissenschaftliche Technik-Grenzwerte validiert**. Hohe Bildabdeckung ist keine Genauigkeitsquote.

| Beobachtung | Regel | Prüfschritt |
| --- | --- | --- |
| Bildamplitude nimmt ab | Median letzte zwei Zyklen mehr als 20 % unter Median erste zwei | Anfang/Ende ansehen; bei ungewollter Verkürzung eine Belastung wählen, mit der der vorgesehene Umfang kontrollierbar bleibt; keine Tiefe erzwingen |
| Dauer steigt | Median letzte zwei Zyklen mehr als 30 % über Median erste zwei | Bewusstes Tempo und Pausen prüfen; nicht automatisch beschleunigen |
| Amplitude schwankt | Variationskoeffizient über 20 %, ohne bereits gezeigten Verkürzungshinweis | Kleinsten/größten Zyklus vergleichen, Kamera und springende Gelenkpunkte prüfen |
| Keine dieser Regeln trifft zu | Obige Datenanforderungen erfüllt | Keine zusätzliche Änderung ableiten; keine Bestätigung perfekter/sicherer Technik |
| Daten reichen nicht | Perspektive, Abdeckung, Seitenzuordnung oder Zykluszahl ungeeignet | Konkreter Aufnahmehinweis; keine erfundene Technikkorrektur |

Die ersten/letzten zwei Wiederholungen sind nur die **erkannten** vollständigen Zyklen. Sehr kleine oder verdeckte Wiederholungen können ganz fehlen. Dauer umfasst beide Bewegungsphasen und mögliche Pausen. Die Veränderung beweist weder Ermüdung noch einen Ausführungsfehler. Prozente sind gerundete Beschreibungen des Signals.

## Speichern und Vergleich

`cameraView` und `feedback` sind optionale neue Felder in Schema 3. `feedback` enthält Regelversion, Status und den damaligen Hinweistext. Eine neue Regelversion darf frühere Hinweise nicht heimlich ersetzen. Alte Ergebnisse ohne diese Felder bleiben lesbar und bekommen keinen nachträglich geratenen Blickwinkel.

Vergleich erfordert gleiche bekannte Perspektive, Übungs-ID, Körperseite, Gelenkmethode, Modellmethodenversion und Analysequalität. Eingeschränkte neue Auswertungen sind ausgeschlossen. Kameraabstand und Geräteeinstellung können damit weiterhin nicht verifiziert werden.

Zusatzdaten liegen in derselben IndexedDB-Transaktion unter `video-context-v1`; ältere 1.9.0-Tabs überschreiben diesen Schlüssel nicht. JSON, lokale Sicherungsstände, Import und Rücknahme enthalten die neuen Metadaten. Es werden keine Video-Bilddateien hochgeladen oder dauerhaft in der App abgelegt.

## Prüfung

Automatisierte Tests prüfen mathematische Fälle, Kameramatrix, Lücken, ungültige Daten, alte Tabs, JSON/Neustart, Import-Rücknahme und beide Oberflächenzweige. Die Messmodell-Dateien bleiben bytegleich und werden separat verifiziert. **Keine reale Geräte- oder Video-Validierung in dieser Umgebung.** Primärquellen und Übertragungsgrenzen: EVIDENCE.md, Ergänzung 19.10.2026.

---

# 1.9.0 · Kamera, Tempo und Offline-Vorbereitung

- Standard: weiterhin maximal 640 Pixel längste Seite und 8 analysierte Bilder/s. Zügig: 480 Pixel und 6 Bilder/s. Dasselbe lokal bereitgestellte Full-Modell; kein neuer Genauigkeitsanspruch. Weniger Abtastung kann schnelle/kleine Bewegungen verpassen.
- Hinweise nennen für den gewählten Winkel nötige Gelenke, geeignete Perspektive und Verdeckungsgrenzen. Core/Tragen/Waden haben kein abgestimmtes Zählprofil und bekommen einen Hinweis auf manuelles Zählen.
- Grobe Restzeit erst nach mehreren analysierten Bildern; kein Versprechen einer festen Dauer. Initiales Modell-Laden wird separat angezeigt.
- Offline-Status prüft nur Caches des eigenen App-Pfads auf Modell und vollständiges JS-/WASM-Paar. Vorab-Download ist optional, gleicher Ursprung, abbrechbar. Kein Upload von Videos. Browserbereinigung kann Cache löschen.
- Eigener Name und Notiz werden mit der Analyse gespeichert/exportiert. Video selbst weiter in Fotos behalten.
- Vergleich nur gleiche Übung, Gelenkmethode, Seite, bekannte Methodenversion und Qualität. Standard-Altanalysen der gleichen Methode bleiben kompatibel; unbekannte/manuelle Methoden bekommen keine Pose-Vergleiche.
- Kürzeste/längste erkannte Wiederholungsdauer enthält Pausen; weder Hantelgeschwindigkeit noch Verletzungsbeurteilung.

Prüfung: automatisierte Abbruch-/Fehler-/Pose-Mathematik-/Vergleichstests und lokale Assets mit Hash-/WASM-Verifikation. **Nicht geprüft:** reale Kameravideos, Modellgenauigkeit, Mobiltemperatur, echte Download-/Browserverarbeitung auf iPhone/Android. Bei ungeeignetem Video bleiben Fehlermeldung und manuelle Zählung verfügbar.

---

# Videoanalyse 2.0 · 4REPS 1.8.11

Technischer Stand geprüft: **17. Oktober 2026**. Experimentelle, lokal ausgeführte
Bewegungsanalyse. Kein medizinisches Verfahren; keine gemessene Genauigkeitsquote.

## Schnell ausprobieren

1. Mehr → Videoanalyse. Übung auswählen.
2. Kurzen Satz mit einer Person bei gutem Licht filmen. Kamera fest aufstellen;
   bei Curls/Kniebeugen seitlich, relevante Gelenke vollständig sichtbar.
3. Video auswählen. Vorschlag für Bewegung prüfen; Körperseite auf Automatik lassen.
4. Optional Start/Ende wählen, maximal 120 Sekunden. „Video analysieren“ antippen.
   Beim ersten Mal Internet aktivieren und die App im Vordergrund lassen.
5. Auf die erkannten Wiederholungen tippen und die Zählung im Video kontrollieren.
6. Nur passende Ergebnisse speichern. Bei ungeeigneter Aufnahme manuell markieren.

## Was geändert wurde

- Bisher wurden MediaPipe 0.10.21 und das Lite-Modell zur Laufzeit extern geladen.
  Die neue Ausgabe enthält den geprüften SDK-Stand **1.1.1** und das **Full-Modell
  float16, Version 1**. Es werden keine unversionierten CDN-Dateien importiert.
- Das Modell läuft bevorzugt in einem klassischen Web Worker. Falls Worker oder
  OffscreenCanvas/WebGL2 dort fehlen, wird die gleiche Analyse im Hauptkontext
  versucht. Zwischen Bildern wird die Oberfläche freigegeben. Auch dieser Weg
  benötigt WebGL2; sonst bleibt die manuelle Zählung verfügbar.
- 8 Bilder/s, Verarbeitung mit maximal 640 Pixeln auf der längsten Seite.
  Hochformat-4K erzeugt dadurch keine übergroßen Zwischenbilder mehr.
- Metadaten und tatsächlich dekodierte Bilder werden unterschieden. Abbruch gilt
  auch während eines Seek-Vorgangs; verspätete Ressourcen werden freigegeben.
- Der Nutzer kann aus längeren Videos einen Ausschnitt von 2–120 Sekunden wählen.
  Dateien maximal 150 MiB. MOV ohne vom Betriebssystem gelieferten MIME-Typ wird
  anhand der Endung zugelassen; das garantiert keine Codec-Unterstützung.
- Gleiche Datei lässt sich erneut auswählen. Analyse-/Speicheraktionen sind gegen
  schnelle Doppelklicks gesperrt. Manuelles Zurück nimmt die zuletzt gesetzte
  Markierung zurück, auch bei Markierungen außerhalb zeitlicher Reihenfolge.
- Frühere gespeicherte Ergebnisse bleiben unverändert. Ein Notizfeld kennzeichnet
  neue Ergebnisse als „4REPS Video 2.0“; das Datenbankschema bleibt Version 3.

## Wie Messwerte entstehen

1. Die Pose-Erkennung kann bis zu zwei Personen erfassen. Bei mehreren klar
   sichtbaren Personen werden betreffende Bilder verworfen. Sind es mehr als
   10 % der Bilder, wird die automatische Auswertung abgelehnt. Das ist keine
   Garantie, jede Hintergrundperson zu erkennen.
2. Drei Landmarks definieren Ellenbogen-, Knie-, Hüft- oder Schulterwinkel.
   Bildkoordinaten werden mit tatsächlicher Breite und Höhe skaliert. Gelenke
   müssen im Bild liegen, visibility ≥ 0,65, presence ≥ 0,5; Segmente ≥ 6 Pixel.
3. Automatik wählt für den ganzen Ausschnitt die Körperseite mit mehr gültigen
   Beobachtungen. Es wird nicht zwischen linker/rechter Seite pro Bild gewechselt.
   Mindestens 65 % der Bilder müssen für die gewählte Seite auswertbar sein.
4. Ein Median über bis zu drei benachbarte Beobachtungen reduziert Einzelrauschen.
   Sichtlücken > 0,45 Sekunden trennen die Verarbeitung vor der Glättung.
5. Das 5./95. Perzentil bestimmt eine robuste Winkelauslenkung. Mindestens 25 Grad
   sichtbare Bewegung sind nötig. Hystereseschwellen bei 22/78 % erkennen die
   Abfolge eines Extrems zum anderen und zurück, unabhängig vom Ausgangsextrem.
   Vollständige Zyklen zwischen 0,6 und 20 Sekunden werden gezählt.
6. Kleine unvollständige Bewegungen und Zyklen über Sichtlücken zählen nicht.
   Eine lange Pause am Start wird möglichst nicht als Bewegungszeit mitgerechnet.

Diese Schwellen sind **konservative Produktheuristiken**, keine wissenschaftlich
validierten Grenzwerte für alle Übungen. Sie können Wiederholungen übersehen,
insbesondere bei kleinen Bewegungen, sehr schnellem Tempo oder Verdeckungen.
Nicht als echte ROM, Bewegungsgeschwindigkeit der Hantel oder Kraftmessung lesen.

Abdeckung in Prozent bedeutet nur Anteil auswertbarer Bilder, nicht Genauigkeit.
Amplitude ist eine Veränderung des Winkels im 2D-Bild. Zeitwerte sind Zyklusdauern,
keine separat gemessene konzentrische/exzentrische Geschwindigkeit. Symmetrie,
Muskelaktivierung, RIR, Verletzungen oder Gelenkbelastung werden nicht bestimmt.

Vergleiche sind nur bei gleicher Übung, Körperseite, Winkeldefinition,
Analyse-Generation und ähnlicher Kameraposition sinnvoll. Die App filtert die
technischen Kriterien; Kamera und Ausführung muss der Nutzer selbst prüfen.
Bei Schmerzen Belastung beenden und bei Bedarf fachlich abklären lassen.

## Datenschutz und Offline

Videobilder bleiben auf dem Gerät. Originalvideos und Pose-Rohdaten werden nicht
hochgeladen oder dauerhaft abgelegt. Gespeichert werden nur bisherige
`VideoResult`-Messwerte einschließlich Dateiname und Notizen. Bei freiwillig
aktivierter Cloud-Sicherung können diese Messwerte wie andere App-Daten in der
gewählten Sicherung enthalten sein; keine Videobilder.

SDK, WASM und Modell werden von derselben GitHub-Pages-Adresse ausgeliefert.
Das Laden des gewählten WASM-Pfads und des Modells benötigt beim ersten Start
ungefähr 23 MB. Der Hostinganbieter sieht übliche Zugriffsmetadaten. Die im SDK
enthaltene Telemetrie wurde mit einem dokumentierten, lokalen Patch deaktiviert:
`vendor/mediapipe/PRIVACY-PATCH.md`. Keine globale Netzwerkfunktion wird verändert.

Die großen Modell-Dateien gehören nicht zum Installations-Precache. Erfolgreich
abgerufene Dateien werden bei verfügbarer Cache API nach Bedarf gespeichert und
können danach offline wiederverwendet werden. Der Browser kann Caches unter
Speicherdruck entfernen. Das ist keine Garantie dauerhafter Offline-Verfügbarkeit
der automatischen Analyse. Normales Workout-Tracking bleibt unabhängig davon.

## Primärquellen und technische Grenzen

- Google: [Pose Landmarker für Web](https://developers.google.com/edge/mediapipe/solutions/vision/pose_landmarker/web_js).
  API, Landmarks, synchroner Inferenzaufruf und Worker-Empfehlung.
- Google: [Pose Landmarker Übersicht](https://developers.google.com/edge/mediapipe/solutions/vision/pose_landmarker).
  Modellvarianten und Ausgabeformat. Modellparameter beweisen keine Genauigkeit
  bei den konkreten Gym-Aufnahmen des Nutzers.
- Google: [Web-Setup](https://developers.google.com/edge/mediapipe/solutions/setup_web).
  Web-Laufzeit und unterstützte Browser. Geräteabhängige Einschränkungen bleiben.
- MediaPipe-Maintainer: [Issue 6306](https://github.com/google-ai-edge/mediapipe/issues/6306),
  Stellungnahme 10.06.2026: Apache-2.0 für SDK/Full-Modell, Telemetrie darf blockiert
  werden. Der tatsächliche 1.1.1-Code wurde zusätzlich geprüft und gepatcht.
- [Exaktes npm-Artefakt](https://registry.npmjs.org/@mediapipe/tasks-vision/1.1.1).
  Hashes, Integrität und Modell-URL stehen in `vendor/mediapipe/sources.json`.

Automatisierte Prüfungen stehen in `tests/video.test.tsx` und
`scripts/verify-video-assets.mjs`. Sie prüfen Mathematik, Abbruch, Fehlerpfade,
Datenkompatibilität, Asset-Integrität und den deaktivierten Telemetriesender.
**Kein repräsentativer Pose-/Zählbenchmark, kein realer iPhone-/Android-Test und
keine aktuelle Browser-Abnahme in dieser Umgebung.** Das Full-Modell kann länger
rechnen; tatsächliche Geschwindigkeit/Genauigkeit muss auf Geräten geprüft werden.
