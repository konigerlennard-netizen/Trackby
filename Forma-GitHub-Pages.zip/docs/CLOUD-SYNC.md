# Forma: Cloud-Sicherung einmalig einrichten

Die Website bleibt auf GitHub Pages. Die freiwillige Cloud-Sicherung verwendet dein eigenes Supabase-Projekt. Ohne Einrichtung und Anmeldung bleiben alle Trainingsdaten lokal. Ein ZIP-Upload zu GitHub richtet noch keine Cloud ein.

## Einmalig auf deinem Handy oder Computer

1. Öffne https://supabase.com/dashboard und erstelle ein Konto bzw. melde dich an.
2. Erstelle ein neues Projekt. Wähle einen Projektnamen und eine geeignete Region, z. B. eine EU-Region. Das Datenbankpasswort bleibt bei dir und gehört nicht in Forma oder GitHub.
3. Öffne im Projekt den **SQL Editor** und eine neue Abfrage.
4. Kopiere den vollständigen Inhalt der mitgelieferten Datei [supabase/setup.sql](supabase/setup.sql) hinein. Führe sie mit **Run** aus. Sie erstellt die Tabellen, Zugriffsschutz und die Funktion für den Abgleich.
5. Öffne **Authentication → Email Templates → Magic Link**. Setze den E-Mail-Inhalt auf:

```html
<h2>Dein Forma-Anmeldecode</h2>
<p>Gib diesen Code in Forma ein: <strong>{{ .Token }}</strong></p>
```

6. Stelle sicher, dass E-Mail-Anmeldung aktiviert ist. Für beliebige Nutzer brauchst du einen eigenen Mailversand unter **Authentication → SMTP Settings**. Der integrierte Supabase-Testversand ist stark begrenzt und erlaubt nur bestimmte Projektteam-Adressen. Wenn kein Code ankommt, prüfe zuerst diese Einstellung und den Spamordner.
7. Kopiere aus dem Projekt die **Project URL** und den öffentlichen **Publishable Key** (alternativ den alten `anon` Key). Du findest sie über **Connect** bzw. die Projekt- und API-Einstellungen. **Nie einen `secret` oder `service_role` Key in eine Website eintragen.**
8. Öffne deine aktualisierte Forma-App. Unter **Mehr → Cloud-Sicherung → Cloud einrichten** trägst du die beiden öffentlichen Werte ein.
9. Gib deine E-Mail ein, aktiviere die freiwillige Cloud-Sicherung und fordere einen Anmeldecode an. Trage den Code aus der E-Mail in Forma ein.
10. Prüfe die Anzeige **Letzter erfolgreicher Abgleich**. Erst dann ist dein Stand zusätzlich online gespeichert.

Für andere Besucher derselben Website kann der Betreiber die beiden öffentlichen Werte in `public/cloud-config.json` im Quellcode setzen und neu bauen. Dann müssen Besucher nur noch ihre eigene E-Mail anmelden. Die Zugriffspolicies aus Schritt 4 sind dafür zwingend. Niemals private Trainingsbackups in das öffentliche GitHub-Repository hochladen.

## Neues Handy oder zweites Gerät

Öffne dieselbe Forma-Adresse, richte gegebenenfalls dieselbe Projektverbindung ein und melde dich mit derselben E-Mail an. Bei der ersten Anmeldung mit bereits vorhandenen Cloud-Daten wählst du ausdrücklich **Cloud-Stand auf diesem Gerät übernehmen**. Der bisherige lokale Stand wird als Rückfallsicherung aufbewahrt.

Danach gleicht Forma bei geöffneter App Änderungen ab. Ohne Internet wird weiterhin lokal gespeichert. Beim nächsten Online-Öffnen wird der Abgleich fortgesetzt. Im geschlossenen oder vom iPhone angehaltenen Zustand ist kein Hintergrundabgleich zugesichert.

## Wenn zwei Geräte verschiedene Änderungen haben

Forma führt widersprüchliche Datensätze nicht automatisch zusammen. Es zeigt beide Stände mit Anzahl der Workouts und Pläne. Du kannst zuerst beide als JSON herunterladen und dann einen vollständigen Stand auswählen. Ein laufendes Workout wird nicht durch einen Cloud-Download ersetzt. Wurden nach der Vorschau neue Eingaben gespeichert, wird die Auswahl abgewiesen und du gleichst erneut ab.

Die Cloud behält die letzten zehn ersetzten Stände. Unter **Cloud verwalten → Ältere Cloud-Sicherungen** kannst du sie herunterladen. Ein ersetzter lokaler Stand lässt sich unter **Mehr → Letzten Import rückgängig machen** zurückholen. Diese Rückfallsicherung wird beim nächsten Import/Cloud-Übernehmen ersetzt. Regelmäßige JSON-Exporte bleiben deshalb sinnvoll.

## Datenschutz und Grenzen

Nach deiner Zustimmung werden Workouts, Pläne, Satzdaten, eigene Übungen, Körpergewicht, Einstellungen, Notizen, Check-ins und Videoanalyse-Metadaten im Supabase-Projekt gespeichert. Videodateien selbst werden nicht übertragen. Die Daten sind pro angemeldetem Konto durch Row Level Security getrennt. Der Projektbetreiber hat administrativen Zugriff. Dies ist keine Ende-zu-Ende-Verschlüsselung. Wenn Freunde die App verwenden, müssen sie wissen, wer das Projekt betreibt.

Anmeldetokens liegen getrennt von den Trainingsdaten in einer zusätzlichen lokalen IndexedDB. JSON-Backups enthalten keine Tokens. Abmelden entfernt keine Trainingsdaten. Derselbe lokale Datenbereich bleibt an sein erstes Cloud-Konto gebunden, damit Daten nicht versehentlich einem anderen Konto zugeordnet werden. Für getrennte Konten getrennte Browserprofile verwenden.

Die Cloud benötigt ein laufendes, korrekt konfiguriertes Supabase-Projekt und funktionierenden Mailversand. Tariflimits und Pausierung des Projekts können den Abgleich unterbrechen. Forma zeigt Fehler; bereits lokale Daten bleiben erhalten. Ein einzelner Cloud-Datenstand ist auf ungefähr 20 MB begrenzt. Cloud-Daten können über die Projektverwaltung gelöscht werden; automatisches Zusammenführen, Apple-/Google-Login, Cloud-Videoablage und Ende-zu-Ende-Verschlüsselung sind noch nicht enthalten.

## Technische Prüfung

Client: offizieller Supabase-JavaScript-Client, lazy geladen. SQL: `SECURITY INVOKER`, explizite RLS-Policies auf Benutzer-ID, atomarer Versionsvergleich, Wiederherstellungspunkte. Lokales Daten-/Backupschema bleibt Version 3; keine Migration und kein Umbenennen der bisherigen Datenbank.

Anmeldung, Abgleich, Konfliktfälle und Offline-Verhalten werden im Browser gegen einen simulierten Supabase-Endpunkt geprüft (gleicher Test-Origin; produktives CORS separat zu prüfen). Die SQL-Datei wird zusätzlich in PostgreSQL (PGlite) mit zwei getrennten Rollen/Benutzern getestet. Eine echte Anmeldung und Mailzustellung gegen dein Projekt muss nach der Einrichtung geprüft werden; ohne deine Projektwerte war das nicht möglich.

Quellen, geprüft am 07.10.2026:
- https://supabase.com/docs/guides/auth/auth-email-passwordless
- https://supabase.com/docs/guides/auth/auth-smtp
- https://supabase.com/docs/guides/database/postgres/row-level-security
- https://supabase.com/docs/guides/getting-started/api-keys
