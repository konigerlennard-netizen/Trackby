# Leistungsvergleich · Methode und Grenzen

Version **1.0.0**, gezielte Literatur- und Tabellenprüfung **30.09.2026**. Die Coachingregeln bleiben bei 1.0.0. Diese optionale Ansicht ist über „Mehr → Leistungsvergleich“ und die Übungsdetails erreichbar. Sie beeinflusst weder Lastvorschläge noch PRs oder Trainingspläne.

## Was die Ansicht tatsächlich vergleicht

Die Referenz sind aggregierte **Kraftdreikampf-Wettkampfergebnisse**, keine repräsentative Stichprobe der Bevölkerung oder aller Fitnessstudiobesucher. Die App enthält keine Namen, Ranglisten einzelner Personen oder personenbezogenen OpenPowerlifting-Datensätze.

Geeignet sind nur die hinterlegten IDs `bench`, `squat`, `deadlift` und `sumo-deadlift`: freie Langhantel, passende Lastzählweise und ungefähr wettkampfübliche Ausführung. Die beiden Kreuzhebevarianten haben getrennte persönliche Verläufe, aber eine **gemeinsame, in der Quelle nicht nach Technik aufgeteilte** Referenz. Die Anzeige sagt das ausdrücklich. RDL, Stiff-Leg, Trap Bar, Frontkniebeuge, Kurzhantel, Multipresse, Maschinen und Kabel erhalten keine abgeleiteten Vergleichswerte. Auch eigene Übungen mit ähnlichen Namen werden nicht automatisch zugeordnet.

## Verwendete Daten

**van den Hoek DJ, Beaumont PL, van den Hoek AK et al. (2024).** *Normative data for the squat, bench press and deadlift exercises in powerlifting: Data from 809,986 competition entries.* Journal of Science and Medicine in Sport 27:734–742. [DOI: 10.1016/j.jsams.2024.07.005](https://doi.org/10.1016/j.jsams.2024.07.005). [Offizieller UniSC-Volltext](https://research.usc.edu.au/view/pdfCoverPage?download=true&filePid=13277467740002621&instCode=61USC_INST).

- Retrospektive Querschnittsauswertung, keine Trainingsintervention. 809.986 Wettkampfeinträge, davon 571.650 männlich und 238.336 weiblich; dieselbe Person kann mehrfach vorkommen.
- Zeitraum 1968–2022, 15 getestete Verbände weltweit, unequipped. Unterschiedliche Wettkampfregeln und Jahrzehnte, keine Erfassung individueller Trainingsjahre. Drug-tested bedeutet keine Garantie für jede einzelne Leistung.
- Relative Leistung = bester erfolgreicher Einzelversuch / Körpergewicht beim Wettkampf. Die App nutzt veröffentlichte P10-, P50- und P90-Schwellen.
- Tabellen 3/4: getrennte Altersgruppen. Tabellen 5/6: getrennte Gewichtsklassen mit gemischten Altersgruppen. **Diese Randverteilungen werden nicht miteinander verrechnet.** Die gemeinsamen Alters-/Gewichtstabellen im Supplement wurden für diese Version nicht ausreichend verifiziert und sind nicht implementiert.

### Bewusste Ausschlüsse nach Quellenprüfung

Die Alterszellen für Kniebeugen beider Geschlechtskategorien sowie für weibliches Bankdrücken bleiben gesperrt. Die veröffentlichten N-Angaben passen nicht zu den Summen der Gewichtstabellen: weibliche Kniebeugen ergeben in Tabelle 5 insgesamt 167.766 Einträge, ihr Alterskopf in Tabelle 3 summiert sich dagegen auf 216.445. Für weibliches Bankdrücken verhält es sich umgekehrt. Der männliche Kniebeugen-Alterskopf wiederholt die weiblichen Bankdrücken-Kopfzahlen und ergibt 167.766 statt 340.223 Einträgen aus Tabelle 6. Es wird **keine vermutete Korrektur** vorgenommen. Die Perzentile dieser gesperrten Zellen werden ebenfalls nicht importiert.

Weitere Inkonsistenzen der Quelle: männliches Bankdrücken 18–35, P90: 1,95 im Abstract gegenüber 1,96 in Tabelle 4. Die App verwendet den ausdrücklich dokumentierten Tabellenwert 1,96. Einzelne andere Dezile haben widersprüchliche Konfidenzintervallgrenzen; diese Dezile werden nicht verwendet. Die Anzeige gibt keine individuelle Genauigkeit von 0,01 oder exakten Rang vor. Konfidenzintervalle über eine mehrfach besetzte Wettkampfstichprobe wären ohnehin kein individuelles Vorhersageintervall.

Gruppen mit weniger als **100 Einträgen** werden unterdrückt. Diese konservative Grenze ist eine Produktentscheidung, keine statistisch validierte Güteschwelle. Gewichtsklassen 43 kg (weiblich) und 53 kg (männlich) werden nicht als allgemeine Erwachsenenreferenz angeboten, da die Quelle sie Junioren-/Subjuniorenklassen zuordnet. Außerhalb der beobachteten Alters- und Körpergewichtsgrenzen wird nicht extrapoliert.

### Jüngere Forschung und Einordnung

**Montenegro S, Wicker P, Wiedenmann T, Rappelt L, Donath L (2026).** *Percentile-Based Normative Standards for Strength Assessment Beyond Linear Bodyweight Multipliers in Competitive Powerlifters.* Sports Medicine – Open 12:136, veröffentlicht 16.09.2026. [DOI: 10.1186/s40798-026-01111-z](https://doi.org/10.1186/s40798-026-01111-z).

Diese Beobachtungsstudie nutzt 101.898 Athletenprofile (21–49 Jahre), je den Wettkampf mit dem besten Total, Raw/IPF und nationale Mitgliedsverbände, 2015 bis 08.03.2026. Sie berücksichtigt Gewichtsklassen und verringert Mehrfachgewichtung durch wiederholte Starts. Namensbasierte Identifikation, Auswahl der Bestleistung und fehlende Trainingsjahre bleiben Grenzen. Die Ergebnisse unterstreichen, dass ein einfacher Last-/Körpergewichtsquotient nicht alle Gewichtsklassen fair angleicht. Kein Widerspruch zu einer deskriptiven Quotientenanzeige; wohl aber zu deren Interpretation als universelle Norm. Die unterschiedliche Population und Auswahl verbieten stilles Mischen mit 2024. Ihre graphischen Atlanten werden in dieser Version nicht numerisch digitalisiert und nicht als Jugenddaten benutzt.

## Persönliche Leistung

1. Optional einen **abgeschlossenen Arbeitssatz** derselben Übungs-ID aus dem Verlauf auswählen oder eine bereits absolvierte Leistung eingeben. Aktive Workouts, Warm-ups, Back-off- und Drop-Sätze werden aus dem Verlauf nicht angeboten.
2. Alter und Körpergewicht gelten **zum Zeitpunkt des Satzes**. Ein vorhandener Körpergewichtseintrag innerhalb von ±7 Tagen kann bewusst übernommen werden, nie stillschweigend. Die 7-Tage-Grenze ist eine Bedienheuristik; bei starken Schwankungen ist eine passendere Messung nötig.
3. Für 2–10 Wiederholungen: Epley-Schätzung `Last × (1 + Wiederholungen/30)`. Es werden nur Sätze mit bekannter Reserve RIR 0–2 oder RPE 8–10 eingeordnet. RIR wird nicht auf die Wiederholungen aufgeschlagen. Diese Anwendungsgrenzen sind vorsichtige Produktregeln, keine Validierung der Formel für jedes Individuum. Weitere Quellen zur 1RM-Schätzung stehen in [PROGRESS_METHOD.md](PROGRESS_METHOD.md).
4. Ein Einzelversuch wird nur bei dokumentiertem RIR 0 / RPE 10 als solcher angezeigt, nicht mit Epley hochgerechnet. Seine Ausführung und Maximalität sind nicht unabhängig geprüft. Ein neuer Maximalversuch wird nicht verlangt.
5. Relative Leistung = dokumentierter Einzelversuch oder geschätztes 1RM / Körpergewicht. kg und lb werden aus demselben internen kg-Wert berechnet.
6. Die grobe persönliche Zuordnung benötigt außerdem die ausdrückliche Bestätigung von Ausführung und Lastzählweise. Mögliche Ausgaben: unter P10, P10–P50, P50–P90, über P90 oder „nahe P…“ an einer auf zwei Dezimalen gerundeten Schwelle. Es findet keine Interpolation eines exakten Perzentils statt.

Eine e1RM-Schätzung aus einem Trainingssatz ist keine direkt geprüfte Wettkampfleistung; Schätzfehler können einen Grenzübertritt verursachen. Die Ansicht benennt deshalb „Schätzung“ und „grober Referenzbereich“, nicht „stärker als X % aller Menschen“. Keine Einstufungen wie schwach, Elite oder „du solltest …“.

## Fehlende Daten und Jugendliche

Ohne passende Quelle, bei ausgeschlossenen Gruppen oder gewünschten Filtern „Alter und Gewicht gemeinsam“ bzw. „nur gleiche Trainingserfahrung“ erscheint **„Nicht genügend verlässliche Vergleichsdaten“** mit konkretem Grund. Ein gewählter Filter wird nicht heimlich gelockert. Fehlende persönliche Satzdaten werden getrennt von fehlenden Referenzdaten erklärt.

Unter 18 wird keine altersgemischte Gewichtsklassentabelle verwendet. Die Altersgruppe 12–17 ist höchstens eine grobe Orientierung; biologische Reife und Trainingsalter fehlen. Unter 12 werden gar keine Referenzen gezeigt. Für Jugendliche werden keine Ziele, Maximaltests oder Körperveränderungen aus dem Vergleich abgeleitet.

## Reproduzierbarkeit, Speicherung und Updates

- `reference-data.json` enthält 69 aggregierte Zellen inklusive Geschlechtskategorie, Gruppierung, Grenzen, Tabellen-N, Perzentilen und Quellenangabe. Darunter sind auch kleine Gruppen, die der Code bewusst nicht anzeigt.
- `scripts/extract-reference-data.py` extrahiert mit Poppler exakt die ausgewählten Spalten und dokumentiert die Ausschlüsse. Aufruf: `python scripts/extract-reference-data.py /pfad/zum/paper.pdf`.
- Prüfsumme der gelesenen PDF einschließlich UniSC-Deckblatt: SHA-256 `0cc8ca2adc95d1292401fb4dbeab96e21d49dff6491a33b2ee0cffb1e0c38425`.
- Originaltabellen stehen unter **CC BY 4.0**; Bearbeitung: Auswahl, maschinenlesbare Übertragung, deutsche Darstellung. Autoren, DOI und [Lizenz](https://creativecommons.org/licenses/by/4.0/) bleiben in Datei und Ansicht sichtbar. Keine geschützte App-Grafik übernommen.
- Vergleichsangaben sind nur React-Ansichtszustand. Keine neuen sensiblen Profilfelder, kein Schemawechsel, keine Übertragung an Dritte. Die Referenzen gehören zum Offline-App-Bundle; Quellenlinks öffnen externe Seiten.
- Änderungen an Daten, Ausschlüssen oder Regeln benötigen erneute Prüfung, Tests, Versionsnummer und Changelog. Keine automatischen oder unsichtbaren Datenupdates.

Die Quelle bietet eine begrenzt passende Leistungsreferenz. Die persönliche Entwicklung über vergleichbare Trainingseinheiten bleibt eine eigenständige Information und wird nicht durch einen Wettkampfrang bewertet.
