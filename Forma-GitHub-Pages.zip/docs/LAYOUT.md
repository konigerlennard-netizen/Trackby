# Dein Layout · 4REPS 1.20.0

Öffne **Layout bearbeiten** auf Heute, im Workout oder unter **Mehr → Dein Layout**.

1. Wähle **Einfach**, **Standard** oder **Detailliert** als Ausgangspunkt.
2. Tippe auf **Elemente hinzufügen**. Wähle für Startseite oder Workout einzelne Extras mit kleinen Beispielen. Der Haken und **Dabei** zeigen deine Auswahl. Erneutes Antippen entfernt ein Element aus der Ansicht.
3. **Vorschau** zeigt deinen aktuellen Entwurf als großes Handy-Beispiel. **Layout speichern** übernimmt ihn.

Du kannst etwa bei Einfach nur Coach und Satznotiz ergänzen. Ein Wechsel zu Detailliert ist dafür nicht nötig. Die übrigen Einstellungen bleiben beim Ergänzen erhalten. Eigene Änderungen erscheinen als **Individuell angepasst**.

## Anordnung und Aussehen

Unter **Anpassen** verschiebst du Karten und Workout-Bereiche mit den Pfeilen. Das durchgestrichene Auge blendet sie aus. **Namen & Farben** enthält eigene Kartentitel und Farbakzente. Abstände und Schnellaktionen sind separat aufklappbar.

**Kartenbreite · große Bildschirme** zeigt zwei Bilder je Karte:

- **Halbe Zeile:** Die Karte belegt eine der beiden Spalten.
- **Ganze Zeile:** Die Karte belegt beide Spalten und steht allein in der Zeile.

Die Vorschau darüber folgt deiner tatsächlichen Kartenauswahl und Reihenfolge. Auf schmalen Bildschirmen bis 650 CSS-Pixeln, etwa dem Handy im Hochformat, stehen alle Karten untereinander. Dort ist zwischen beiden Einstellungen kein Unterschied sichtbar.

## Workout

Unter **Elemente hinzufügen → Workout** findest du sämtliche optionalen Satzangaben, Übungsbereiche und die Trainingsnotiz, unabhängig von der gewählten Vorlage. Gewichte, Wiederholungen und Abschluss bleiben erreichbar. Ausblenden löscht keine gespeicherten Daten.

Unter **Anpassen** wählst du per Bild **Untereinander** oder **Einzeln**, entfernst einzelne ausgewählte Satzfelder oder änderst die Bereichsreihenfolge.

**Gemessene Pause** zeigt die erfasste Satzpause. Das Feld verändert deinen Timer nicht. Deine gespeicherte Pausendauer gilt weiter für alle Übungen; ändern kannst du sie über **Pause: 3:00 → Timer speichern**.

## Eigene Vorlagen und Pläne

Unter **Eigene Vorlagen** kannst du deine aktuelle Ansicht benennen und hinzufügen (höchstens acht). Eine Vorlage antippen lädt sie in den Entwurf. Eine neue Grundvorlage ersetzt die aktuelle Auswahl im Entwurf. Erst **Layout speichern** bestätigt diese Änderungen.

Unter **Trainingspläne → Workout-Layout** bearbeitest du nur diesen Plan. Auch dort kannst du jede Vorlage einzeln ergänzen. Freie Workouts und andere Pläne folgen weiter ihren jeweiligen Ansichten. Über **Anpassen → Allgemeines Layout verwenden → Layout speichern** folgt der Plan wieder dem allgemeinen Layout.

## Speichern

Ungesicherte Änderungen werden beim Schließen abgefragt. Bei einem Speicherfehler bleibt der Entwurf offen. Gleichzeitige Änderungen aus einem anderen Layout-Editor werden nicht überschrieben.

Die App speichert lokal. JSON-Backups enthalten deine Layouts. Beim Update unter derselben App-Adresse bleiben Trainingsdaten und Einstellungen erhalten. Website-Daten nicht löschen. Automatisierte Ergebnisse stehen in RELEASE_VALIDATION.json; ein interaktiver Browser- und echter Handytest wurde nicht durchgeführt.
