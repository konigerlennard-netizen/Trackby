# Dein Layout · 4REPS 1.21.0

Öffne **Layout bearbeiten** auf Heute, im Workout oder unter **Mehr → Dein Layout**.

Es gibt vier Auswahlen: **Einfach**, **Standard**, **Detailliert** und **Individuell**. Die ersten drei sind feste Vorlagen. **Individuell** ist dein eigener Speicherplatz.

## Eine Vorlage anpassen

1. Wähle Einfach, Standard oder Detailliert und tippe **Anpassen**.
2. Über **Elemente hinzufügen / entfernen** wählst du Karten, Satzangaben und Übungsbereiche mit kleinen Beispielen aus. Ein Haken markiert enthaltene Elemente.
3. Sobald du etwas änderst, wechselt die Auswahl automatisch zu **Individuell**. Die feste Vorlage bleibt unverändert.
4. **Vorschau** zeigt deinen Entwurf. **Layout speichern** übernimmt die Auswahl und deinen individuellen Platz.

Das bloße Öffnen von Anpassen verändert noch nichts. Ungesicherte Änderungen bleiben ein Entwurf; beim Schließen wirst du gefragt, ob du sie verwerfen möchtest.

## Direkt individuell gestalten

Wähle **Individuell → Anpassen**. Wenn du noch kein eigenes Layout hast, beginnt die Startseite ohne optionale Karten und das Workout nur mit den nötigen Satzangaben. Über Elemente hinzufügen / entfernen baust du deine Ansicht auf. Workout starten, Gewicht, Wiederholungen und Abschluss bleiben erreichbar.

Dein bisheriges selbst angepasstes Layout wird übernommen. Du kannst zwischen den festen Vorlagen und Individuell wechseln: Deine letzte individuelle Auswahl bleibt im vierten Platz. Wird eine weitere feste Vorlage angepasst, ersetzt deren bearbeitete Fassung den individuellen Entwurf. Erst **Layout speichern** bestätigt alles.

## Anordnung und Kartenbreite

Unter Anpassen verschiebst du Karten und Workout-Bereiche mit den Pfeilen. **Namen & Farben** enthält eigene Titel und Farbakzente; weitere Optionen bleiben aufklappbar.

**Kartenbreite · große Bildschirme** zeigt Bilder und die Anordnung deiner Karten:

- **Halbe Zeile:** Die Karte belegt eine der beiden Spalten.
- **Ganze Zeile:** Die Karte belegt beide Spalten und steht allein.

Auf schmalen Bildschirmen bis 650 CSS-Pixeln, etwa dem Handy im Hochformat, stehen alle Karten untereinander. Dort sieht man keinen Unterschied zwischen beiden Breiten.

## Workout, Pläne und weitere Vorlagen

Unter **Anpassen → Workout** wählst du Einzeln/Untereinander, Satzangaben und die Reihenfolge. **Gemessene Pause** ändert deinen Timer nicht; die gespeicherte Dauer stellst du über **Pause: 3:00 → Timer speichern** ein. Ausblenden entfernt keine Trainingsdaten.

**Trainingspläne → Workout-Layout** hat für jeden Plan eine getrennte individuelle Ansicht. Andere Pläne und das allgemeine Layout bleiben beim Bearbeiten erhalten. Kopieren eines Plans kopiert seine Layoutauswahl und seinen individuellen Platz unabhängig mit. **Allgemeines Layout verwenden** entfernt die eigene Planansicht einschließlich ihres individuellen Platzes.

Unter **Eigene Vorlagen** kannst du zusätzlich bis zu acht benannte Layouts speichern. Der vierte individuelle Platz zählt nicht zu diesen acht. Beim Laden einer benannten Vorlage wird sie als Individuell übernommen.

## Speichern

Die App speichert lokal. JSON-Backups und ein vorhandener Cloud-Abgleich enthalten auch die individuelle Auswahl. Ältere offene App-Versionen können den individuellen Speicherplatz nicht versehentlich entfernen. Gleichzeitige Änderungen aus einem anderen Editor werden nicht überschrieben; bei einem Speicherfehler bleibt dein Entwurf offen.

Beim Update unter derselben App-Adresse bleiben Trainingsdaten und Einstellungen erhalten. Website-Daten nicht löschen. Automatisierte Ergebnisse stehen in RELEASE_VALIDATION.json; kein interaktiver Browser- oder echter Handytest dieser Version.
