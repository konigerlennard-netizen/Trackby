# Dein Layout · 4REPS 1.19.0

Öffne **Layout bearbeiten** auf Heute, im Workout oder unter **Mehr → Dein Layout**.

1. Wähle **Einfach**, **Standard** oder **Detailliert**. Das Häkchen markiert deinen Entwurf.
2. **Vorschau** zeigt ihn als großes Handy-Beispiel. Dort kannst du zwischen Startseite und Workout wechseln und zusätzliche Satzangaben aufklappen. Alle Zahlen sind Beispieldaten.
3. **Anpassen** öffnet die Bearbeitung. **Layout speichern** übernimmt den Entwurf.

## Startseite anpassen

Verschiebe sichtbare Karten mit den Pfeilen. Das durchgestrichene Auge blendet sie aus; **Karte hinzufügen** holt ausgeblendete Karten zurück.

**Namen & Farben** enthält die Kartenbeschriftung und Farbakzente. **Weitere Optionen** enthält Abstände, Breite am Computer und Schnellaktionen. Auf dem Handy stehen Karten untereinander. Ausblenden löscht keine Daten.

## Workout anpassen

Wähle per Bild **Untereinander** oder **Einzeln**. Gewicht, Wiederholungen und Haken bleiben sichtbar. Zusätzliche Felder wählst du unter **Satzangaben**; seltene Felder unter **Weitere Satzangaben**. **Bereiche & Abstände** enthält die Reihenfolge, optionale Bereiche und die Trainingsnotiz.

Das Feld **Gemessene Pause** stellt keinen Timer ein. Deine gespeicherte Pausendauer gilt weiterhin für alle Übungen. Du änderst sie über **Pause: 3:00 → Timer speichern**.

## Eigene Vorlagen und Pläne

Auf der ersten Editor-Seite unter **Eigene Vorlagen** kannst du deine aktuelle Ansicht benennen und hinzufügen (höchstens acht). Eine gespeicherte Vorlage antippen lädt sie in den Entwurf. Entfernen und Hinzufügen werden ebenfalls erst mit **Layout speichern** bestätigt.

Unter **Trainingspläne → Workout-Layout** bearbeitest du nur die Ansicht dieses Plans. Freie Workouts und Pläne ohne eigene Ansicht folgen dem allgemeinen Layout. Eine eigene Planansicht setzt du unter **Anpassen → Allgemeines Layout verwenden → Layout speichern** zurück.

Die große Vorschau berücksichtigt Reihenfolge, Sichtbarkeit, Namen, Farben, Satzfelder, Einheit und deine gespeicherte Pause. Sie ändert keine Trainingsdaten. Die kleinen Auswahlbilder zeigen schematische Ausschnitte.

## Speichern

Schließen mit ungesicherten Änderungen fragt nach. Bei einem Speicherfehler bleibt der Entwurf offen. Änderungen aus einem anderen Layout-Editor werden nicht unbemerkt überschrieben.

Die App speichert lokal. JSON-Backups enthalten deine Layouts. Beim Update unter derselben App-Adresse bleiben Einstellungen und Trainingsdaten erhalten. Website-Daten nicht löschen. Die Version 1.19.0 wurde automatisiert geprüft; ein echter Browser-/Handytest steht aus.
