# Dein Layout · 4REPS 1.17.0

Unter **Layout bearbeiten → Vorlagen** siehst du Beispielbilder der Ansichten Standard, Schnell und Detailliert. Sie sind direkt aus den Layouteinstellungen aufgebaut und funktionieren offline. **Startseite ansehen** und **Workout ansehen** wechseln die Vorschau; im Planeditor gibt es nur das Workout.

**Groß ansehen** öffnet das vollständige, lesbare Beispiel. Die kleine Vorschau zeigt einen beschrifteten Ausschnitt. In der großen Workout-Vorschau lassen sich **Weitere Satzangaben** und **Schnelle Satzeingabe** öffnen. Die Beispielwerte sind nicht bearbeitbar und werden nie als Training gespeichert. Einheit und Pausenvorgabe entsprechen deinen Einstellungen. Die zweite Übung wird im Beispiel zusammengefasst.

Auch deine eigenen Vorlagen zeigen diese Bilder. Beim Bearbeiten von Startseite oder Workout aktualisiert sich der aktuelle Entwurf direkt. Eigene Namen, Farben, Reihenfolge, ausgeblendete Karten, Abstände und Fokus sind darin sichtbar. Auf dem Handy stehen Karten untereinander; die Option für volle Desktop-Breite wirkt nur auf großen Bildschirmen.

**Übernehmen** lädt eine Vorlage in deinen Entwurf. Sie ist erst nach **Layout speichern** aktiv. Das reine Ansehen verändert nichts. Die ungenauen Bewegungszeichnungen neben Übungen sind entfernt; Übungsnamen öffnen weiterhin ihre Beschreibungen.

# Pausentimer ab 1.14.0

Über **Pause: 3:00** oben im Workout kannst du deine globale Pausendauer dauerhaft speichern. Sie gilt unabhängig vom gewählten Layout und für alle Übungen. Weitere Zugänge stehen unter Mehr und am laufenden Timer. Die Anzeige **Gemessene Pause** in den Satzdetails ist eine optionale Messangabe; sie stellt den Timer nicht ein.

# Einfachere Workout-Ansicht ab 1.13.0

Übungen werden seit 1.17.0 ohne Bewegungszeichnungen angezeigt. In der Satztabelle bleiben Gewicht, Wiederholungen und Haken direkt sichtbar. Deine ausgewählten Zusatzfelder erreichst du über **Weitere Satzangaben**, die Schnellregler über **Mit + / − anpassen**. Die persönliche Reihenfolge und Auswahl im Layout-Editor gelten weiter. Der Timer startet nach einem abgehakten Satz mit deiner gespeicherten Pause, standardmäßig drei Minuten, wenn die Automatik aktiv ist.

# Dein Layout · 4REPS 1.11.0

Öffne **Layout bearbeiten** auf Heute oder im Workout. Unter **Mehr → Dein Layout** findest du denselben Editor.

## Startseite

Halte den Griff einer Karte kurz gedrückt und ziehe sie an die gewünschte Position. Du kannst auch die Pfeile verwenden. Am Computer unterstützt der fokussierte Griff die Pfeiltasten oben/unten. Das Auge blendet eine Karte ein oder aus. Die Vorschau zeigt die geplante Anordnung.

Zur Wahl stehen Fortschritt, Kalender, Trainingspläne, Schnellaktionen, Körpergewicht, letztes Training und Coach. Auf größeren Bildschirmen können Karten die volle Breite belegen; auf dem Handy stehen sie untereinander. Mit „Kompakt“ verkleinerst du die Abstände. Touchflächen bleiben bedienbar.

Unter **Name & Farbe** gibst du einer Karte einen eigenen Namen mit bis zu 40 Zeichen und wählst Standard, Grün, Blau, Violett, Rosé oder Bernstein. Der Farbakzent markiert den Kartenrand; die Schriftfarben folgen weiterhin deinem gewählten Design. Ein leeres Namensfeld verwendet den ursprünglichen Namen. **Name & Farbe zurücksetzen** betrifft nur diese Karte.

Bei den Schnellaktionen wählst und sortierst du freies Workout, letztes Training wiederholen, Pläne, Statistiken und Videoanalyse. Ein laufendes Training wird fortgesetzt.

## Workout

Wähle die Zusatzfelder, die du über **Weitere Satzangaben** öffnen möchtest: vorherige Werte, RIR, RPE, gemessene Pause, Notiz, Tempo und Bewegungsumfang. Gewicht, Wiederholungen bzw. Sekunden und Satzabschluss bleiben sichtbar. Über die Satznummer sind alle Satzdetails erreichbar. Ausblenden entfernt keine eingetragenen Daten.

Du kannst Satzeingabe, schnelle Gewichtsschritte, Übungsnotiz und Coach anordnen. Satzeingabe bleibt verpflichtend. Zusätzlich sind Fokus auf eine Übung und die Trainingsnotiz wählbar. Das allgemeine Layout gilt für freie Workouts und Pläne ohne eigene Ansicht.

RIR und RPE sind alternative Einschätzungen. Eine neue Eingabe in eine Skala leert die andere. Pause bezeichnet die aufgezeichnete Pause, nicht die Zielzeit des Pausentimers. Die Timer-Einstellung bleibt unter „Mehr“.

## Eigene Ansicht pro Trainingsplan

Öffne **Trainingspläne → Workout-Layout** beim gewünschten Plan oder **Layout bearbeiten** in dessen laufendem Workout. Jede Anpassung erstellt ein eigenes Layout für diesen Plan. Du kannst zum Beispiel bei einem Plan nur Gewicht und Wiederholungen zeigen, bei einem anderen zusätzlich RIR, Pause und Tempo. Auch die Abstände sind pro Plan wählbar. Die Startseite wird dabei nicht verändert.

**Allgemeines Layout verwenden → Layout speichern** entfernt die eigene Ansicht. Der Plan übernimmt dann auch spätere Änderungen am allgemeinen Layout. Neue Pläne folgen ebenfalls dem allgemeinen Layout. Beim Kopieren eines Plans wird seine eigene Ansicht unabhängig mitkopiert. Beim erneuten Starten aus dem Verlauf oder von Heute bleibt die Planzuordnung erhalten. Wurde der ursprüngliche Plan gelöscht, verwendet das Workout die allgemeine Ansicht.

## Vorlagen und Speichern

„Standard“, „Schnell“ und „Detailliert“ laden Einstellungen in den Entwurf. Bis zu acht eigene Vorlagen lassen sich mit Namen speichern und später wieder übernehmen. Das Entfernen einer Vorlage betrifft nur diese Vorlage; das aktuelle Layout und Planansichten bleiben erhalten. Im Editor eines Plans werden nur Workout-Einstellungen und Abstände aus einer Vorlage übernommen. Eigene Vorlagen halten eine unabhängige Kopie der gerade sichtbaren Einstellungen fest.

**Layout speichern** übernimmt den gesamten Entwurf. Abbrechen verwirft ihn. Beim Schließen über die Schließen-Taste, die Zurück-Navigation oder die Hintergrundfläche fragt die App nach, wenn Änderungen offen sind. Bei Speicherfehlern bleibt der Entwurf zur Wiederholung erhalten. Hat ein anderer Tab inzwischen das Layout geändert, öffne den Editor erneut.

Gespeicherte Layouts gehören zum JSON-Backup und zur optionalen bestehenden Cloud-Sicherung. Die bisherigen Trainingsdaten und die Datenbankkennung bleiben erhalten. Das Update erfordert bei gleicher App-Adresse keinen Neuimport. Das allgemeine Farbschema, Hell/Dunkel und Hintergrund findest du weiterhin unter „Mehr → Aussehen“.

Die neue Touch-Verschiebung und das konkrete Bildschirm-Layout wurden in dieser Umgebung nicht auf einem echten iPhone/Android-Gerät getestet. Die Pfeile stehen als alternative Bedienung bereit.
