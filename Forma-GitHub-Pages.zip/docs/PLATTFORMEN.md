# 4REPS 1.24.0 · iPhone und Android

Beide Ausgaben haben denselben Funktionsumfang, dieselben Übungen, dieselbe Trainingslogik und dieselben Berechnungen. Sie entstehen aus demselben Quellcode. Nur die Darstellung und Bedienung der Steuerelemente unterscheidet sich. Größere Auswahleinträge meinen die Touch-Fläche, nicht eine andere Zahl an Übungen oder Funktionen.

Es gibt zwei fertige Website-Pakete:

- `Forma-GitHub-Pages.zip`: iPhone-Design, Glasnavigation, vertraute iOS-Formularauswahl.
- `android/Forma-GitHub-Pages.zip`: Android-Design mit flächigen Material-orientierten Bedienelementen, eigenen Auswahlfenstern und Suchfunktion bei langen Optionslisten.

Die ZIP-Dateien heißen bewusst gleich, damit der bestehende GitHub-Entpackworkflow weiter funktioniert. Unterscheidung erfolgt über den Download-Link bzw. den Ordner. Lade pro Website **nur eine** der ZIP-Dateien hoch. Bei einer einzigen Website sehen alle Nutzer deren ausgewähltes Design; es gibt keinen automatischen Plattformwechsel. Die beiden Ausgaben sind PWAs, keine APK-/IPA-Dateien.

## Neues App-Icon

Beide Ausgaben enthalten dasselbe bereitgestellte gläserne 4R-Motiv. Android erhält zusätzlich ein Icon mit mehr Rand für die Maskierung durch den Launcher. Die iPhone-Ausgabe verknüpft ein neues Apple-Touch-Icon. Die App heißt weiterhin 4REPS; Name, Manifest-ID und Speicherscope ändern sich nicht. Bestehende installierte Symbole können vom Betriebssystem weiter zwischengespeichert werden.

## Dein bestehendes Trackby aktualisieren

1. Die gewünschte ZIP herunterladen. Für dein bisheriges iPhone-Trackby die iPhone-Ausgabe wählen.
2. [Datei in GitHub hochladen](https://github.com/konigerlennard-netizen/Trackby/upload/main).
3. Die vorhandene `Forma-GitHub-Pages.zip` durch die neue Datei gleichen Namens ersetzen. Nicht entpacken. Zusätze wie `(2)` im Dateinamen vorher entfernen.
4. Änderungen mit **Commit changes** speichern und unter **Actions** den grünen Veröffentlichungslauf abwarten.
5. Die bestehende App-Adresse öffnen, unter **Mehr** nach Updates suchen und ein angebotenes Update übernehmen. Die Anzeige lautet anschließend **4REPS 1.24.0**.

Nicht beide ZIP-Dateien in dasselbe Repository hochladen. Für eine parallel erreichbare Android-Website einen separaten Veröffentlichungsort verwenden. Dort beginnt die lokale Speicherung leer; vorhandene Daten können per JSON-Backup übertragen werden. Backups niemals ins öffentliche GitHub-Repository hochladen.

## Falls die alte Seite weiß bleibt

Erst nach Veröffentlichung dieses Pakets [Startreparatur öffnen](https://konigerlennard-netizen.github.io/Trackby/repair.html). Auf **App-Dateien erneuern** tippen. Die unabhängige Seite prüft zuerst, ob die Website online erreichbar ist, und entfernt danach nur den Service Worker und die App-Caches für diesen Website-Pfad. Trainingsdatenbank, Foto, Einstellungen, andere Apps und Backups werden nicht gelöscht. Andere offene 4REPS-Tabs vorher schließen.

Bei einer anderen App-Adresse liegt dieselbe Seite unter `repair.html` im jeweiligen App-Verzeichnis. Nicht die Safari-/Chrome-Websitedaten löschen. Die genaue Ursache des gemeldeten weißen Bildschirms auf dem privaten Gerät konnte hier nicht reproduziert werden.

## Navigation im Querformat

Auf Touch-Handys im Querformat bis 600 CSS-Pixel Höhe steht die Navigation rechts senkrecht. Die fünf Tabs bleiben gleich. iOS behält die gläserne Pill und den beweglichen Auswahlindikator; Android behält die flächige Leiste mit aktivem Symbolhintergrund. Labels und Icons bleiben aufrecht. Im Hochformat steht die Leiste wieder unten. Inhalte, Timer und Hinweise reservieren Platz für die rechte Leiste; ein Drehwechsel setzt die aktuelle Seite nicht zurück. Bei sehr geringer Höhe lässt sich die Leiste scrollen, damit alle Tabs erreichbar bleiben.

## Höchster Eintrag

Gewicht und Wiederholungszahl in der Übungsübersicht stammen aus demselben abgeschlossenen Arbeitssatz. Beispiel: 65 kg × 6 und vorher 60 kg × 8 ergeben **65 kg × 6**. Bei gleichem Höchstgewicht zählt der Satz mit mehr Wiederholungen. Die zweite Kennzahl heißt „Wdh. im selben Satz“. Das geschätzte 1RM bleibt ausdrücklich eine eigenständige Kennzahl. Keine Daten werden umgeschrieben.

## Was gemeinsam verbessert wurde

Zeitraumwahl (Tag bis Gesamt und eigener Zeitraum) mit einzeiligen Labels, begrenzte Datumsfelder auf schmalen Displays, fünf Haupttabs rechts im Handy-Querformat, klar gegliederte Leistungszeilen, farbige absolute und prozentuale Änderung, unveränderte Vergleichsregeln. Wie bisher erscheinen zunächst fünf Übungen; Suche, Filter und weitere Übungen bleiben verfügbar.

## Prüfgrenzen

Automatisierte Daten-, Berechnungs-, Markup- und simulierte Update-/Offline-Tests. Echte Touch-, TalkBack-/VoiceOver-, Chrome-Android- und Safari-iPhone-Prüfungen sind in dieser Umgebung nicht möglich. Das Layout ist dafür vorbereitet, aber nicht als auf beiden Geräten geprüft auszugeben.
