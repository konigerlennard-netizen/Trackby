# Abschlussprüfung 1.9.0 · 18.10.2026

Ausgangspunkt war das gespeicherte Quellpaket 1.8.11 (SHA-256 1058184f31d9dda57a1c91860d7bc25db2af534a9b000a84931e908ced44818c). Vor Änderungen bestanden 170 automatisierte Tests.

Konkrete Befunde und Korrekturen:

1. Importvorschau war nicht an eine konkrete Revision gebunden. Neue Eingaben werden nun durch eine atomare Revisionsprüfung geschützt.
2. „Zuletzt“ verließ sich auf Array-Reihenfolge. Jetzt absteigend nach Workout-Zeitpunkt.
3. Übungsauswahl schloss vor dem Speicherergebnis. Jetzt async bestätigt; bei Fehler bleibt die Auswahl offen und Doppeltipps sind gesperrt.
4. Neue Personalisierung hätte in älteren Tabs verlorengehen können. Separate Metadaten in derselben Transaktion, Hauptschema bleibt lesbar.
5. Wiederherstellungsstände dürfen bei Speichermangel niemals das eigentliche Workout-Speichern scheitern lassen. Getrennte Zusatztransaktion mit Quotenfehler-Test.
6. Große Schrift braucht andere Satzzeilen: frühere Werte werden auf kleinen Displays darunter angeordnet, Gewichts-/Wdh.-/RIR-Felder bleiben erreichbar.

Kein vollständiger visueller Geräte-Audit in dieser Umgebung möglich. Nicht als getestete Ergebnisse ausgeben: reale Touch-/Tastatur-/Scrollabläufe, PWA-Installation am Handy, echte Pose-Erkennungsgenauigkeit. Kein Browser- oder Gerätestart wurde improvisiert.

---

# Prüfung 1.8.11 · Video und App-Stabilität · 17.10.2026

Ausgangspunkt: unverändertes Quellpaket 1.8.10. Vor Änderungen: TypeScript und 149 vorhandene Tests bestanden. Prüfung von Video/Worker, Mathematik, PWA, Repository, Einstellungen und zugehörigen UI-Komponenten. Keine pauschale Neugestaltung und keine Änderung des Datenschemas.

| Befund | Maßnahme |
|---|---|
| Externer alter SDK-Import im Worker, Modellaufrufe bei Drittanbietern | Gebündelte geprüfte 1.1.1-Laufzeit und Full-Modell, gleiche Website |
| Neuer SDK enthält Telemetrie | Deaktivierter Sender, keine Warteschlange/Sendetimer, Änderungsnachweis und Hashprüfung |
| Feste linke Seite trotz schlechter Sicht | Eine automatisch ausgewählte Körperseite für den ganzen Ausschnitt |
| Zählung setzt ein bestimmtes Ausgangsextrem voraus | Beide Bewegungsrichtungen; keine Zyklen über Sichtlücken |
| Seek kann vor Dekodierung fertig melden; Abbruch greift nicht überall | Explizites Warten, Abbruchsignale, Timeouts und Ressourcenfreigabe |
| Hochformat sehr große Zwischenbilder | 640 Pixel an längster Seite |
| Ganzes Video muss unter 2 Minuten sein | Ausschnitt aus längerer Datei auswählbar |
| Ergebnisse schwer direkt kontrollierbar | Wiederholung antippen → passenden Abschnitt abspielen |
| Manuelle Speichervorgänge können später erneut dupliziert werden | Sperre identischer Markierungen zusätzlich zur laufenden Speicherung |
| Update-Prüfung endet während Download mit unklarem Hinweis | Zustände bereit/aktuell/wird geladen getrennt |

Die übrigen bestehenden Funktionsprüfungen werden erneut ausgeführt. Vollständige visuelle Regression, Touch-Latenz, echte Codec-/Poseverarbeitung und Installation auf iPhone/Android sind in dieser Umgebung nicht prüfbar. Kein individuelles Fehlschlagen des Nutzer-Videos ohne diese Originalaufnahme reproduziert. Details: TESTING.md und VIDEO_ANALYSIS.md.

# Audit 1.6.1 · 12.10.2026

Ausgangspunkt: gespeicherte Version 1.6.0, Quell-ZIP SHA-256 `181030cdb34be74bc8c2c57bdf8a191fbd5882912c420c08ab1060bd3ae883b0`. Vor Eingriff TypeScript und alle 91 Kernprüfungen bestanden.

Der gemeldete Schalterfehler ist im Quellcode nachvollziehbar: Die Thumb-Utility erzeugt eine eigenständige CSS-Translation, während globals.css zusätzlich `transform: translateX(21px)` setzt. Diese Verschiebungen werden addiert. Ein gemeinsamer Switch mit eigenem Track, 3 px Rand und ausschließlich einem Transform ersetzt beide konkurrierenden Regeln. Alle Toggle-Verwendungen nutzen die Korrektur.

Neue Aussehensoptionen sind vom Trainingsmodell getrennt. Alte Datensätze benötigen keine Migration. Ein beschädigter Farbwert wird auf einen Standard gesetzt, ohne ansonsten gültige Workouts zu blockieren. Andere Datenvalidierung bleibt streng.

Die 1.6.0-Berichte unten sind historische Ergebnisse, keine erneut durchgeführten Browserprüfungen von 1.6.1.

---

# Audit 1.6.0 · 09.10.2026

Ausgangspunkt: unverändertes Produktionspaket 1.5.1; Quellenabgleich und Kern-/Browserprüfung vor der neuen Veröffentlichung. Keine kritischen Speicherfehler festgestellt.

| Befund | Änderung |
| --- | --- |
| Mehrere Startaktionen und Rückblicke überladen Heute | Kalender und ein Start-/Fortsetzenknopf, danach persönliche Pläne und kompakter Fortschritt |
| Kalender zeigt nur sieben nicht interaktive Tagesmarken | Tage auswählbar, Woche/Monat blätterbar; lokale Kalenderarithmetik statt fester Millisekunden |
| 300 Übungen werden sofort gerendert | Zuerst fünf Treffer; gesamte Bibliothek wird vor Begrenzung durchsucht; bewusste Aufklappfunktion |
| Filter und Herkunftswissen belasten den Einstieg | Filter eingeklappt, wissenschaftliche Belege als optionale Dokumentation |
| Leistungsvergleich ist für die genutzten Maschinen unhilfreich | Sämtliche Einstiege/Ansicht aus der App entfernt; keine Referenzzahlen oder neue Ersatzheuristik |
| Bestehende Daten dürfen nicht neu importiert werden müssen | Speicher-/Schema-/Backupcode unverändert; tatsächliches PWA-Update mit vorher/nachher Datenvergleich geprüft |

Details und Grenzen der erneuten Funktionsprüfung: TESTING.md. Ein WebKit-Testtreiberproblem beim echten Offline-Neuladen wurde in der Vorversion reproduziert und als Testgrenze dokumentiert. Keine App-Daten wurden für Tests verwendet.

---

## Navigationskorrektur 1.5.1 · 08.10.2026

- Meldung: Die untere Leiste verschwindet beim Wechsel der Bereiche.
- Vor der Korrektur in 1.5.0 nachgestellt: Wechsel von Heute zur langen Übungsliste, Übergang bei 140 ms angehalten. Die Navigation bleibt im DOM sichtbar, wird aber im tatsächlichen Bild von der Seitenaufnahme überdeckt. Ein Pixeltest scheitert reproduzierbar am unveränderten Produktionsbuild.
- Ursache: Die View-Transition-Ebene wird vor sämtlichem normalen Seiteninhalt einschließlich fester Navigation gezeichnet. Ein höherer z-index der Navigation allein löst das nicht. Technische Grundlage: [W3C CSS View Transitions, View Transition Layer](https://www.w3.org/TR/css-view-transitions-1/#view-transition-layer).
- Korrektur: Animation direkt auf dem lebenden Seiteninhalt mit Web Animations; feste Steuerelemente liegen außerhalb. Keine dokumentweite Aufnahme, keine ausgesparte oder unsichtbar geschaltete Leiste während Tabwechseln. Laufende Inhaltsanimation wird bei einem weiteren Wechsel abgebrochen.
- Der Glass-Pill-Drag und die bisherigen Safe-Area-Abstände bleiben unverändert. Bei aktiver Bildschirmtastatur bleiben schwebende Leisten weiterhin absichtlich ausgeblendet; nach Verlassen des Felds werden sie eingeblendet.
- Ausschließlich künstliche Testdaten. Datenbank, Backupformat, Übungsdaten und Coaching unverändert. Ergebnisse und Hardwaregrenzen in TESTING.md.

## Prüfung vor und während 1.5.0 · 07.10.2026

- Unveränderten Ausgangsstand 1.4.1 mit dem gesicherten Quellcodepaket verglichen: keine Abweichungen; alle 79 bestehenden Kernprüfungen bestanden.
- Doppelte Planungseingabe: Satzanzahl/Range standen oberhalb der bereits vollständigen Einzelzeilen. Jetzt Anzahl aus Zeilen, pro Zeile Gewicht/Wiederholungen und Entfernen; Range/RIR unter Coach-Zielen. Keine Änderung bestehender Werte.
- WebKit-Regression fand ein Rennen zwischen dem Zurück-Schritt eines schließenden Sheets und dem Wechsel zur Trainings- bzw. Abschlussansicht. Navigation wartet jetzt auf den internen Zurück-Schritt; die Abschlussansicht öffnet nach dem Seitenwechsel. Ein eigener Hash-Wechsel schließt sie nicht mehr nachträglich.
- Cloud-Zugriff bewusst opt-in; öffentliche Konfiguration geprüft, geheime Schlüssel abgewiesen, Konto-Zuordnung vor Upload, lokale Speicherung und Auth getrennt. Konflikte und aktive Workouts verhindern unbemerkte Ersetzung.
- Keine Kundendaten gelesen oder in Tests verwendet. Keine Datenbankmigration. Teststand und Einschränkungen in TESTING.md.

# Forma – Ausgangsprüfung und Überarbeitung

## Verfeinerung 1.4.1 · 07.10.2026

Vor der Verfeinerung wurde der vorhandene Bedienungs-Regressionslauf auf 1.4.0 in Chromium erneut bestanden. Geändert wurden ausschließlich Oberfläche, Navigation und die Vorbereitung nachgeladener Ansichten; die Datenbank und fachlichen Berechnungen bleiben unverändert.

| Befund | Korrektur |
|---|---|
| Fortschritt ist auf Heute und unter Mehr doppelt einsortiert; Detail-Zurück führt zu Mehr | Fortschritt gehört zu Heute. Eine gemeinsame Aktion unter der Übersicht öffnet die vollständige Analyse; ausgewählter Zeitraum und aktiver Tab bleiben passend. |
| Seiten verschwinden abrupt, nachgeladene Ansichten können kurz einen Ladeplatzhalter zeigen | Seiten vor dem Übergang laden; kurze Überblendung mit kleinen Wegen, direkter Ersatzpfad ohne API/bei reduzierter Bewegung. |
| Glasregler springt beim ersten Kontakt unter den Finger | Ausgangsposition bis zur tatsächlichen Ziehbewegung beibehalten, Tipp und Drag unterscheiden. |
| Sheet-Inhalt wird vor dem Ende der Schließanimation entfernt; abgebrochenes Ziehen startet Öffnungsanimation erneut | Inhalt und Höhe bis zum Ende behalten; Öffnungsanimation nach Interaktion nicht neu starten; Schließen setzt an der gezogenen Position an. |
| Sehr schmale Heute-Ansicht läuft in WebKit seitlich über | Mindestbreite der Grid-Kinder lösen, Planüberschrift umbrechen lassen, Wochenanzeige an 320 px anpassen. |
| Bibliotheksüberschrift verbreitert den mobilen Layout-Viewport; Speichern der eigenen Übung nach Scrollen schlägt im Chromium-Bedientest fehl | Responsive Schriftgrößen und Umbruch ohne Abschneiden. Die Messung prüft jetzt gegen die tatsächliche Displaybreite statt den bereits verbreiterten Layout-Viewport. |

Nach Korrektur bestehen die betroffenen Tests in Chromium und WebKit: 41 schnelle Tab-Aktionen, unveränderte Sheet-Höhe beim Schließen, kurze und lange Ziehbewegungen, reduzierte Bewegung, API-Fallback, 320/390/1440 px, eigene Übungen, native Auswahl und Wiederöffnen. Der Service-Worker-Wechsel 1.4.0 → 1.4.1 erhält die exportierten Workouts, Pläne, Körpergewichte, eigenen Übungen, Video-Metadaten und Einstellungen exakt (abgesehen vom durch den Export aktualisierten Backupzeitpunkt). Das alte Backup lässt sich importieren, die aktualisierte App offline öffnen.

79 Logik-/Speichertests, Typprüfung und PWA-Artefaktprüfung sind erfolgreich. Weitere Bedienungsregressionen und Grenzen stehen in TESTING.md. Ein physisches iPhone und eine feste Bildrate wurden nicht geprüft.

## Vorherige Überarbeitung 1.4.0

Ausgangsprüfung: 6. Oktober 2026. Abschluss: 7. Oktober 2026. Ausgangsversion: 1.3.2. Keine echten Nutzerdaten werden für Tests verwendet.

## Prüfung vor der Überarbeitung

`npm run verify`: 79 erfolgreiche Logik-/Speichertests, TypeScript, Produktionsbuild und statische Offline-Artefaktprüfung. `npm run test:browser`: Kernablauf in Chromium erfolgreich: Erststart, einzelne Satzgewichte, RIR, Timer, Abschluss, JSON-Rundreise, ungültiger Import, Rückfallsicherung, kompletter Browser-Neustart offline, getrennte Projektpfade, Desktopdarstellung. Keine Laufzeitfehler in diesem Ablauf.

Zusätzlich wurden die Ansichten und ihre gemeinsamen Eingabe-/Overlay-Komponenten geprüft. Reproduzierbare Befunde (`scripts/audit-baseline.mjs`, Screenshots/JSON unter `test-results/baseline`):

| Priorität | Befund vor Änderungen | Ursache / geplante Korrektur |
|---|---|---|
| Hoch | 10 schnelle Klicks auf +2,5 ab 50 ergeben 52,5 statt 75 kg; +1 Wdh. ergibt 9 statt 18 | Veralteter Renderwert in parallel wartenden Schreibvorgängen. Innerhalb der bestehenden IndexedDB-Transaktion vom neuesten Satzwert rechnen. |
| Hoch | Zurück wechselt zu #workout, Übungsdetail bleibt offen | Overlays besitzen keinen eigenen Navigationszustand. Einheitliche Zurück- und Schließverwaltung. |
| Hoch | Planentwurf wird beim Schließen ohne Rückfrage verworfen | Ungespeicherte Änderungen schützen; versehentliches Wegwischen darf nicht löschen. |
| Mittel | Bei 320 px wird rechts die Satzabschlusstaste abgeschnitten, obwohl das Dokument keinen horizontalen Überlauf meldet | Mindestbreiten der Tabelle übersteigen den Karteninhalt. Eigene kompakte Satzanordnung. |
| Mittel | Haupt-App und Workout rechnen jede Sekunde alles neu | Countdown und Trainingsdauer in getrennte Komponenten verlagern. |
| Mittel | Historisches RIR kann gleichzeitig mit widersprüchlichem RPE gespeichert werden | Gleiche wechselseitige Priorität wie bei aktuellen Sätzen verwenden. |
| Mittel | Übung ersetzen verwirft bereits eingetragene Sätze ohne ausdrückliche Bestätigung | Vor dem Ersetzen vorhandener Daten eine Bestätigung anzeigen. |
| Mittel | Speichern/Kopieren einzelner Entwürfe hat keinen Schutz gegen schnelle Mehrfachbetätigung | Sofortige Sperre bis zum Ende der Transaktion; Formulare bei Fehlschlag offen halten. |
| Mittel | Nur beim Start wird nach App-Updates gesucht | Bei Rückkehr und auf ausdrücklichen Knopfdruck prüfen, Reload erst ohne laufendes Training und ohne offene Speichervorgänge. |
| Gestaltung | Viele kleine Touchziele, mehrere verschachtelte Scrollbereiche, grün getönte Flächen und inkonsistente Rundungen | Gemeinsame neutrale Tokens, ausreichend große Steuerelemente, begrenztes Glasmaterial auf Navigation und Overlays. |

## Datenerhalt

Unverändert bleiben Datenbankname, Pfadzuordnung, Object Store, Schema 3, Backupformat 3, sämtliche Übungs-IDs und Coachingregeln. Die atomare Read-Modify-Write-Transaktion, Importprüfung und Rückfallsicherung werden weiterverwendet. Ein Update derselben Installation erfordert keinen JSON-Import.

## Abschlussprüfung

Alle oben aufgeführten reproduzierten Eingabe-, Navigations- und Layoutfehler wurden korrigiert. Die verpflichtende zweite Prüfung ist abgeschlossen: 79 Tests, Typprüfung, Produktionsbuild, PWA-Artefakte sowie Kernabläufe in Chromium und WebKit. 10 schnelle +2,5-Schritte ergeben jetzt 75 kg statt 52,5; 10 Wiederholungsschritte ergeben 18 statt 9. Acht schnell hinzugefügte Sätze sind vollständig vorhanden. Rücknavigation, verschachtelte Dialoge, Entwurfsschutz und schmale Satzsteuerungen sind geprüft.

Ein echter Service-Worker-Wechsel vom unveränderten Produktionsbuild 1.3.2 auf 1.4.0 erhält im Exportvergleich Workouts, Satzdetails, individuelle Planvorgaben, eigene Übungen, Favoriten, Einstellungen, Körpergewicht und Video-Metadaten. PRs und Statistiken werden weiter aus denselben Workouts abgeleitet. Altes Backup importiert, neue Version offline geöffnet. Tests verwenden ausschließlich künstliche Daten in temporären Browserprofilen.

Ergebnisse, Reproduktion und offene Hardwareprüfungen stehen in `TESTING.md`. Linux-WebKit ist kein physischer iPhone-Test. Native Tastatur, tatsächliche Bildrate, Home-Bildschirm-Installation, VoiceOver und Posequalität echter Aufnahmen bleiben offen. Kein vollständiger formaler Accessibility- oder Sicherheits-Audit; kein Versprechen, dass Browser lokale Daten niemals löschen.
