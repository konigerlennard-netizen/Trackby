# Prüfung 1.17.0 · 23.10.2026

Erweiterung des vorhandenen 1.16.0-Quellcodes. Die ungenauen Bewegungszeichnungen und ihre Verwendungen in Workout, Planeditor, Bibliothek und Picker sind entfernt. Normale Bedienicons und die separate Muskelübersicht bleiben bestehen.

Layout-Vorschauen sind lokale React-/CSS-Ansichten mit eindeutig gekennzeichneten synthetischen Werten, keine Bilder fremder Übungen oder behaupteten echten Nutzertrainings. Sie erhalten nur Layoutkonfiguration, Einheit und globale Pausenvorgabe. Es gibt keinen Zugriff auf schreibende Trainingsaktionen. Kleine Vorschauen sind beschnitten und ausdrücklich als Ausschnitt bezeichnet; sie enthalten keine fokussierbaren Elemente. Die große Vorschau ist scrollbar und erlaubt nur das Öffnen zusätzlicher Beispielangaben.

Vorlagenvergleich und aktuelle Vorschau verwenden denselben Renderer. Karten-/Bereichsreihenfolge, Ein-/Ausblenden, Namen, Akzente, Abstände, Fokus und Zusatzfelder werden aus derselben Konfiguration gelesen. Die Desktop-Breite von Karten wird in der ausdrücklich als Handy-Vorschau bezeichneten Ansicht nicht simuliert. Der vorhandene Entwurfsablauf mit atomarem Speichern, Konfliktschutz und Planbeschränkung bleibt bestehen.

Keine neuen Abhängigkeiten, Datenfelder, Datenbank-/Backup-Schemata oder Änderungen am Timerablauf. Automatisierte Prüfungen sind dokumentiert; kein erfolgreicher interaktiver Browser-, Touch- oder Gerätetest und keine Veröffentlichung.

# Prüfung 1.16.0 · 23.10.2026

Beobachteter Codefehler: `completeWorkoutSet` löschte beim Wiederöffnen jedes Satzes bedingungslos `timerEnd`, auch wenn danach ein anderer Satz eine neue Pause gestartet hatte. Die Korrektur entfernt nur den unveränderten Countdown der eindeutig letzten Abschlusszeit. Bei identischen Abschlusszeiten oder nach manueller Verlängerung bleibt der Countdown bestehen; er lässt sich weiterhin bewusst am Timer schließen. Für Altbestände wird keine neue Timerzuordnung erfunden.

Die Oberfläche übergibt den tatsächlich angezeigten Abschlussstatus und Zeitstempel an die atomare Änderung. Stimmen sie nicht mehr mit dem Speicher überein, wird die alte Aktion ignoriert. Ein kurzer Schutz vor Doppeltipps ergänzt die vorhandene Serialisierung; fehlgeschlagene Speicheraufrufe bleiben sofort erneut versuchbar.

Die Rückgängig-Aktion trägt Ziel-IDs, Abschlusszeit und die vom Abschluss geänderte Pausenangabe. Sie setzt nur denselben noch gültigen Abschluss zurück und erhält neuere Eingaben. Ein späterer Satz, ein verlängerter Countdown oder ein erneut abgeschlossener Zielsatz wird nicht zurückgesetzt. Die kurz sichtbare Rückgängig-Aktion lebt nur in der Oberfläche; der gespeicherte Trainingsstand verwendet weiterhin das vorhandene Datenformat. Eine zuvor überschriebene ältere Pause wird durch Rückgängig nicht neu gestartet.

Der nächste offene Satz folgt der aktuellen Reihenfolge einschließlich Aufwärmsätzen und zuvor übersprungener Sätze. In der Fokusansicht wird beim Öffnen die erste offene Übung gewählt. Der Sprung setzt den Fokus auf eine beschriftete Satzgruppe, nicht auf ein Eingabefeld; reduzierte Bewegung wird berücksichtigt. Es erfolgt kein automatisches Weiterscrollen nach Satzabschluss.

Keine neue Datenbank-, Backup- oder Schema-Version; keine Änderungen an Video-Modell, Coach-Regeln oder Nutzerhistorie. Automatisierte Speicher-, Logik-, Render- und Paketprüfungen sind möglich. Browser-/Touch-/Handyprüfung und Veröffentlichung bleiben offen.

# Prüfung 1.15.0 · 22.10.2026

Weiterarbeit am vorhandenen 1.14.0-Projekt, keine neue App und keine neue Website-Adresse. Datenbankversion 1, Haupt-/Backupschema 3 und vorhandene Inhalte bleiben erhalten. Keine zusätzlichen Abhängigkeiten.

`settings.restKeepAwake` ist optional und standardmäßig aus. Der unabhängige atomare Zusatzwert `rest-display-v1` verhindert Verlust durch ältere offene Tabs, die `rest-settings-v1` bereits kennen. Einstellungen werden gemeinsam validiert und auf konkurrierende Änderungen geprüft. Bewusster Import und Reset entfernen fehlende Werte; Rücknahme stellt sie wieder her. Keine echten Nutzerdaten oder Cloud-Konten wurden in den Tests verwendet.

Der Screen-Wake-Lock-Controller räumt auch nachträglich gewährte Anfragen auf, reagiert auf Freigaben und beendet seine eigene Sperre bei Ende, Hintergrundwechsel oder Abschalten. Automatisches Wiederanfordern erfolgt beim erneuten Sichtbarwerden mit aktivem Timer. Eine OS-Ablehnung wird nicht endlos erneut angefragt. Keine Hintergrundausführung, kein Push-Server und kein garantierter Sperrbildschirmalarm; frühere gegenteilige Erwartungen werden in der Oberfläche ausdrücklich begrenzt.

Der Kameracheck arbeitet nur mit bereits vorhandenen Schulter-/Hüftpunkten, berücksichtigt das Bildformat und benötigt ausreichende Einzelpersonen-Abdeckung. Er unterscheidet nur seitliche, breite frontale/rückwärtige oder unklare Geometrie. Schwellen sind Produktheuristiken, nicht empirisch validiert. Er überschreibt keine Nutzerangabe. Bei deutlichem Widerspruch gibt es einen Aufnahmehinweis statt abgeleiteter Technikempfehlungen. Die neue Seitenpräferenz gilt nur für automatische Auswahl mit ausreichend sichtbarer angegebener Seite; eine manuelle Seitenwahl bleibt erhalten. Modell und Zählalgorithmus bleiben unverändert.

Heute lud zuvor über die Fortschrittsansicht auch die große Diagrammbibliothek. Extrahierte leichte Komponenten und ein kleines SVG-Diagramm entfernen diesen statischen Pfad; die volle Detailansicht wird nachgeladen. Das Diagramm verwendet dieselben Messwerte und echte Zeitabstände, keine interpolierten zusätzlichen Messungen. Auch die Übungssuche und ungenutzte kollabierbare Navigationsinfrastruktur sind aus dem Startpfad entfernt. Finales Entry-Bundle: 536.622 statt 596.159 Bytes, gzip 160.371 statt 180.792 (gleiche Node-gzip-Einstellungen, Referenz aus dem ausgelieferten 1.14.0-Paket). Die 500-kB-Buildempfehlung wird weiterhin überschritten; keine behauptete Geräteladezeit oder kleinere vollständige Offline-Installation.

Prüfgrenzen: Automatisierte Logik-, Render-, Speicher- und Artefakttests. Interaktive Browserprüfung durch Sicherheitsrichtlinie blockiert, keine Umgehung versucht. Keine echten Handys, keine realen Videos und keine Veröffentlichung; der Nutzer hat die GitHub-Verbindung abgelehnt. Die passenden Update-ZIPs werden bereitgestellt.

# Prüfung 1.14.0 · 21.10.2026

Die gewünschte Timerdauer wird jetzt ausdrücklich unter `settings.restSeconds` gespeichert. Lesen nutzt für ältere Daten ohne dieses Feld den Standard 180 Sekunden. Start und Satzabschluss lesen den aktuellen gespeicherten Wert. Das Speichern ändert Dauer und Startautomatik gemeinsam, prüft konkurrierende Änderungen und verändert weder laufenden Countdown noch Trainingsdaten. Kontrollierte Eingaben liefern auch den zuletzt bearbeiteten Wert ohne zusätzlichen Blur oder zweiten Tastendruck.

`rest-settings-v1` schützt den optionalen Wert, wenn ein noch offener älterer Tab unbekannte Hauptfelder entfernt. Schreiben, Löschen, Import und Rücknahme aktualisieren Hauptdaten und Zusatzwert im selben vorhandenen IndexedDB-Vorgang. Datenbankschema 1 und Backup-/Zustandsschema 3 bleiben erhalten. Die Cloud-Payload enthält die neue Einstellung; es wurde keine Verbindung zu einem echten Cloud-Konto getestet.

Timer-Tastendrücke prüfen den tatsächlich angezeigten Countdown, bevor sie ihn schließen oder verlängern. Der Ablaufhinweis wird erst bei sichtbarer App als gemeldet markiert. Betriebssystemseitige Hintergrundbenachrichtigungen wurden nicht ergänzt; Sound bei gesperrtem Handy ist nicht zugesichert.

# Prüfung 1.13.0 · 21.10.2026

Die feste Pause ist eine ausdrücklich gewünschte Produkteinstellung von 180 Sekunden. Neue Trainings normalisieren nur ihre eigenen Vorgaben. Das Abschließen eines Satzes verwendet denselben Wert im vorhandenen atomaren Speichervorgang, auch bei alten/importierten Workouts. Die gespeicherte tatsächliche Pause wird weiterhin nur aus markiertem Satzstart und vorherigem Abschluss ermittelt oder als manuelle Angabe erhalten. Frühere Trainings werden nicht verändert. Alte Pläne müssen nicht migriert oder gelöscht werden.

Die ehemalige schmale Standardtabelle verwendet jetzt denselben flexiblen Vier-Spalten-Aufbau wie individuelle Layouts. Zusatzfelder bleiben gespeichert und aufklappbar. Bei Zeitübungen entfällt die Gewichtsangabe in der aktiven Satztabelle. Layout-Reihenfolge, gewählte Bereiche und Felder bleiben unverändert. Bewegungssymbole sind lokale SVG-Komponenten; eigene und unbekannte Übungen erhalten ein Gerätesymbol.

Prüfgrenze: automatisierte Logik-, Speicher-, Render- und Artefaktprüfungen. Keine ausgeführte Browser-, Touch- oder Offline-Geräteprüfung; die tatsächliche Darstellung muss am Gerät bestätigt werden.

# Prüfung 1.12.0 · 21.10.2026

Die vorhandene Wochenplanung, vorherige Satzwerte und Fortschrittsansichten waren bereits implementiert. Die Überarbeitung ergänzt deren Bedienung: feste Schnellschritte werden durch die vorhandene allgemeine beziehungsweise übungsbezogene Einstellung ersetzt. Datenbankmutationen lesen immer den aktuellen Satz; schnelle Tipps summieren sich ohne Überschreiben durch veraltete Anzeigen. Kopieren berücksichtigt Satztyp und Reihenfolge, Rückgängig prüft die seitdem gespeicherten Werte. Zusatzdaten wie Reserve und Pausen bleiben erhalten.

Die Ersteinrichtung schreibt nur explizit bearbeitete Einstellungen und Wochentage. Konflikte und inzwischen gelöschte Pläne werden vor Änderungen geprüft. Der optionale Status `setupSeenAt` wird atomar mit dem Zusatzschlüssel `setup-v1` gesichert, damit ältere offene Tabs den Einstieg nicht unbeabsichtigt erneut anzeigen. Hauptschema 3 und IndexedDB-Version 1 bleiben erhalten.

Der neue Wochenvergleich verwendet lokale Kalendertage für denselben Wochenabschnitt, auch über Zeitumstellungen. Nur bis zum jeweiligen Zeitpunkt abgeschlossene Workouts zählen. Es wird keine Leistungsbewertung aus mehr Volumen oder längerer Trainingszeit abgeleitet.

Prüfgrenze: automatisierte Logik-, Speicher-, Render- und Artefaktprüfungen; keine echten Browser-, Touch- oder Offline-Gerätetests dieser neuen Oberfläche.

# Prüfung 1.11.0 · 21.10.2026

Die Herkunft des Codes ist nun zusätzlich durch einen bytegenauen Vergleich belegt: der unveränderte Quellstand 1.9.3 reproduziert alle 114 App-Dateien der originalen Pages-ZIP. Es handelt sich um eine Erweiterung dieser App.

Kartenstile sind optionale, validierte Layout-Metadaten: Text bis 40 Zeichen und feste Akzentpalette. Titel werden als React-Text gerendert. Akzente verändern weder Statusfarben noch die Schriftfarben des Designs.

Planansichten speichern nur Workout-Felder/Bereiche, Fokus, Trainingsnotiz und Abstände. Die Startseite bleibt global. Fehlende oder gelöschte Pläne verwenden das allgemeine Layout; beim Speichern eines inzwischen gelöschten Plans wird der Entwurf abgewiesen. Kopieren erstellt unabhängige Konfigurationen. Das Wiederholen behält die Planzuordnung, das Speichern eines Workouts als neuer Plan erzeugt weiter eine neue ID.

`layout-details-v1` ergänzt `layout-v1`, weil 1.10-Tabs den älteren Zusatzschlüssel bereits kennen. Neue Metadaten bleiben bei deren Schreibvorgängen erhalten. Es werden nur noch vorhandene gespeicherte Vorlagen ergänzt, keine entfernten Vorlagen wiederhergestellt. Absichtliches Zurücksetzen, Import und Rücknahme schreiben oder entfernen Hauptdaten und Zusatzschlüssel gemeinsam.

Prüfgrenze: automatisierte Logik-, Render-, Speicher- und Artefaktprüfungen; keine Aussage über einen erfolgreich ausgeführten Touch-/Gerätetest der neuen Oberfläche.

# Prüfung 1.10.0 · 21.10.2026

Ausgangspunkt: unverändertes Quellpaket 1.9.3; Typprüfung und 250 Ausgangstests bestanden. Der Nutzer bestätigt die bisherige Funktion auf seinem Handy.

Die bisherige Anpassung erlaubte nur drei Startseiten-Bereiche. Der neue Editor erweitert diese vorhandene Grundlage und erhält deren Auswahl beim Erststart. Trainingswerte, Workout-Abschluss, Schmerz-Hinweise und Satzdetails bleiben unabhängig von ausgeblendeten Layout-Bereichen verfügbar. Die bestehende Trainingslogik wird für Coach, Wiederholung von Workouts und Messwerte weiterverwendet.

Neue Layout-Einstellungen werden in derselben IndexedDB-Transaktion und im Zusatzschlüssel `layout-v1` abgelegt. Alte Tabs können dieses Feld aus ihrem Hauptdatensatz entfernen, aber den neuen Zusatzschlüssel nicht überschreiben. Ein veralteter Layout-Entwurf wird abgewiesen; gleichzeitige Satzeingaben bleiben erhalten. Ein absichtlicher Import ohne Layout entfernt auch den Zusatzschlüssel, damit keine alte Ansicht unbemerkt wiederkehrt.

Prüfgrenze: kein unterstützter Browser-/Touch-Test in dieser Umgebung. Die neuen Drag-Gesten, Bildschirmtastatur und Abstände wurden nicht auf einem echten Handy vermessen. Render-, Logik-, Speicher- und Paketprüfungen ersetzen diesen Gerätetest nicht.

# Prüfung 1.9.3 · 20.10.2026

Ausgangspunkt: gespeichertes Quellpaket 1.9.2, SHA-256 d1d4e9752997c76f926cd938eb236e4fcd4934ca0b3ed6aec9679f4140a92f56; 230 bestandene Ausgangstests.

1. Automatisch erkannte Zyklen waren nur abspielbar, nicht korrigierbar. Neue lokale Review-Ebene mit erhaltener Rohanalyse, explizitem Reset und Backup-/Alt-Tab-Schutz.
2. Nachladen war unvollständig: vier Hauptansichten wurden statisch importiert; die manuelle Diagrammgruppe zog 385 kB zusätzlich in den statischen Startpfad. Automatische Chunk-Aufteilung plus gezieltes Nachladen senken den statischen JS-Bedarf um 44,4 % (gzip 42,8 %). Kein behaupteter Handymesswert.
3. Der äußere Suspense-Bereich konnte die gesamte Heute-Ansicht verdecken, solange Fortschritt geladen wurde. Der Fortschritt hat nun eine eigene Ladegrenze.
4. Die externe Zählprüfung zeigt keine ausreichende Grundlage für eine Zuverlässigkeitsgarantie. Alle 38 ausgewählten Sätze, Abweisungen und Fehlzählungen werden berichtet; keine nachträgliche Auswahl besonders guter Ergebnisse und keine Optimierung auf die Testlabels.

5. Eine unvollständige temporäre WASM-Kopierdatei lag noch im vorherigen Quellpaket. Entfernt; Paketierung weist solche Dateien jetzt zurück. Reguläre Modell-/WASM-Dateien bleiben unverändert und hashgeprüft.

Nicht verändert: Übungen, Coach, absolvierte Trainings, PRs, Pläne, Körpergewichtsdaten, Icon, Plattformauswahl, Datenbankname und Update-Verfahren. Browser-/Gerätetests sind hier nicht verfügbar; die konkrete Touch- und Videowiedergabe auf iPhone/Android bleibt vor Ort zu prüfen.

---

# Prüfung 1.9.2 · 19.10.2026

Ausgangspunkt: Quellpaket 1.9.1, SHA-256 3c0c0a354f7be03074da01e15a186a5e9c1562ca3321f4d21dcd082c4c03abb3. Vor Änderungen bestanden 219 automatisierte Tests.

Gemeldet: „Alles übernehmen“ braucht einen zweiten Tipp. Im bisherigen Code bestätigte der Button nur den Satzabgleich; andere Eingaben liefen unabhängig über onBlur. Ein blur-Aufruf vor der Bestätigung garantierte keine gemeinsame erfolgreiche Speicherung. Der reale Touchfehler des Nutzers ist ohne sein Gerät nicht reproduziert.

Korrektur: ein kontrollierter Entwurf mit synchron aktualisierter Referenz, Validierung aller Eingaben und einem atomaren Commit. Der Submit-Controller sperrt Mehrfachausführung, bestätigt erst nach Erfolg, behält fehlgeschlagene Entwürfe und lässt Wiederholung zu. Kein künstliches Verzögern, kein Pointer-Down-Speichern und kein Speichern beim bloßen Scrollen. Der Button steht unter den Eingaben. Unsaved-Entwürfe benötigen beim Schließen eine Verwerfbestätigung. Frischer Editorsitzungsschlüssel auch bei schnellem Wiederöffnen.

Geänderte Felder werden gegen den aktuellen Datenbankstand angewandt. Satzarrays werden nie aus dem Entwurf zurückkopiert. Bestehende Schutzregeln verhindern die Entfernung begonnener/abgeschlossener Sätze. Ungültiger Satzabgleich schreibt auch Pause und Notiz nicht teilweise. Erfasste Satzwerte, Trainingspläne und historische Daten behalten ihr bisheriges Schema. Datenbank- und Backupcode wurden nicht geändert.

Video: Auswahl von vorne/hinten/seitlich, erklärende Einleitung und Technikhinweise anhand vorhandener Messwerte in 1.9.1 verifiziert und unverändert übernommen. Keine automatische Front-/Rückenerkennung und keine vollständige biomechanische Bewertung zugesagt.

Prüfgrenze: automatisierte Logik-, IndexedDB-, Render- und Artefaktprüfungen; keine reale Tastatur-/Touch-/Browserprüfung. Genauigkeit an echten Trainingsvideos weiterhin nicht validiert.

---

# Prüfung 1.9.1 · 19.10.2026

Ausgangspunkt: gespeichertes Quellpaket 1.9.0, SHA-256 dd63e4b9572933408ff2d1321de927a78057344786103a4d6decbecc45509d53. Vor Änderungen bestanden 194 automatisierte Tests.

Befunde und Korrekturen:

1. Körperseite war auswählbar, Blickrichtung nicht. Getrennte Kameraperspektive ergänzt; keine automatische Blickrichtungsbehauptung.
2. Allgemeine Hinweise waren in kleinen Messnotizen versteckt und nicht perspektivabhängig. Eigener sichtbarer Bereich mit Beobachtung, Handlung, Grenze und Wiedergabestellen; ungültige/ungeeignete Daten sperren konkrete Aussagen.
3. Gleiche Winkelmethode allein machte Front-/Seitenaufnahmen vergleichbar. Bekannte gleiche Perspektive wird jetzt vorausgesetzt; historische Daten bleiben unangetastet.
4. Neue Metadaten hätten durch alte 1.9.0-Tabs verloren gehen können. Eigener atomarer Zusatzschlüssel, mit simuliertem Alt-Tab-Schreibzugriff geprüft.
5. Namen/Notizen wurden erst bei Fokusverlust in den Entwurf übernommen. Jetzt sofort während des Tippens, damit anschließendes Speichern aktuelle Werte verwendet.
6. Gespeicherte manuelle Zählung zeigte ihr Ergebnis nicht direkt. Ergebnis wird geöffnet; doppelte schnelle Markierungen zusätzlich im Zustandsupdate abgefangen.

Keine Änderungen an Trainingscoach, Übungen, Navigation, Icon oder bestehenden Workout-/Gewichts-/Planstrukturen. Physische Geräte, Browserinteraktion, reale Videodateien und subjektive Animationswirkung sind in dieser Umgebung nicht geprüft. Tests sind keine Genauigkeitsvalidierung des Pose-Modells.

---

# Abschlussprüfung 1.9.0 · 18.10.2026

Ausgangspunkt war das gespeicherte Quellpaket 1.8.11 (SHA-256 1058184f31d9dda57a1c91860d7bc25db2af534a9b000a84931e908ced44818c). Vor Änderungen bestanden 170 automatisierte Tests.

Konkrete Befunde und Korrekturen:

1. Importvorschau war nicht an eine konkrete Revision gebunden. Neue Eingaben werden nun durch eine atomare Revisionsprüfung geschützt.
2. „Zuletzt“ verließ sich auf Array-Reihenfolge. Jetzt absteigend nach Workout-Zeitpunkt.
3. Übungsauswahl schloss vor dem Speicherergebnis. Jetzt async bestätigt; bei Fehler bleibt die Auswahl offen und Doppeltipps sind gesperrt.
4. Neue Personalisierung hätte in älteren Tabs verlorengehen können. Separate Metadaten in derselben Transaktion, Hauptschema bleibt lesbar.
5. Wiederherstellungsstände dürfen bei Speichermangel niemals das eigentliche Workout-Speichern scheitern lassen. Getrennte Zusatztransaktion mit Quotenfehler-Test.
6. Große Schrift braucht andere Satzzeilen: frühere Werte werden auf kleinen Displays darunter angeordnet, Gewichts-/Wdh.-/RIR-Felder bleiben erreichbar.

Kein vollständiger visueller Geräte-Audit in dieser Umgebung möglich. Nicht als getestete Ergebnisse ausgeben: reale Touch-/Tastatur-/Scrollabläufe, PWA-Installation am Handy, echte Pose-Erkennungsgenauigkeit. Kein Browser- oder Gerätestart wurde improvisiert.

---

# Prüfung 1.8.11 · Video und App-Stabilität · 17.10.2026

Ausgangspunkt: unverändertes Quellpaket 1.8.10. Vor Änderungen: TypeScript und 149 vorhandene Tests bestanden. Prüfung von Video/Worker, Mathematik, PWA, Repository, Einstellungen und zugehörigen UI-Komponenten. Keine pauschale Neugestaltung und keine Änderung des Datenschemas.

| Befund | Maßnahme |
|---|---|
| Externer alter SDK-Import im Worker, Modellaufrufe bei Drittanbietern | Gebündelte geprüfte 1.1.1-Laufzeit und Full-Modell, gleiche Website |
| Neuer SDK enthält Telemetrie | Deaktivierter Sender, keine Warteschlange/Sendetimer, Änderungsnachweis und Hashprüfung |
| Feste linke Seite trotz schlechter Sicht | Eine automatisch ausgewählte Körperseite für den ganzen Ausschnitt |
| Zählung setzt ein bestimmtes Ausgangsextrem voraus | Beide Bewegungsrichtungen; keine Zyklen über Sichtlücken |
| Seek kann vor Dekodierung fertig melden; Abbruch greift nicht überall | Explizites Warten, Abbruchsignale, Timeouts und Ressourcenfreigabe |
| Hochformat sehr große Zwischenbilder | 640 Pixel an längster Seite |
| Ganzes Video muss unter 2 Minuten sein | Ausschnitt aus längerer Datei auswählbar |
| Ergebnisse schwer direkt kontrollierbar | Wiederholung antippen → passenden Abschnitt abspielen |
| Manuelle Speichervorgänge können später erneut dupliziert werden | Sperre identischer Markierungen zusätzlich zur laufenden Speicherung |
| Update-Prüfung endet während Download mit unklarem Hinweis | Zustände bereit/aktuell/wird geladen getrennt |

Die übrigen bestehenden Funktionsprüfungen werden erneut ausgeführt. Vollständige visuelle Regression, Touch-Latenz, echte Codec-/Poseverarbeitung und Installation auf iPhone/Android sind in dieser Umgebung nicht prüfbar. Kein individuelles Fehlschlagen des Nutzer-Videos ohne diese Originalaufnahme reproduziert. Details: TESTING.md und VIDEO_ANALYSIS.md.

# Audit 1.6.1 · 12.10.2026

Ausgangspunkt: gespeicherte Version 1.6.0, Quell-ZIP SHA-256 `181030cdb34be74bc8c2c57bdf8a191fbd5882912c420c08ab1060bd3ae883b0`. Vor Eingriff TypeScript und alle 91 Kernprüfungen bestanden.

Der gemeldete Schalterfehler ist im Quellcode nachvollziehbar: Die Thumb-Utility erzeugt eine eigenständige CSS-Translation, während globals.css zusätzlich `transform: translateX(21px)` setzt. Diese Verschiebungen werden addiert. Ein gemeinsamer Switch mit eigenem Track, 3 px Rand und ausschließlich einem Transform ersetzt beide konkurrierenden Regeln. Alle Toggle-Verwendungen nutzen die Korrektur.

Neue Aussehensoptionen sind vom Trainingsmodell getrennt. Alte Datensätze benötigen keine Migration. Ein beschädigter Farbwert wird auf einen Standard gesetzt, ohne ansonsten gültige Workouts zu blockieren. Andere Datenvalidierung bleibt streng.

Die 1.6.0-Berichte unten sind historische Ergebnisse, keine erneut durchgeführten Browserprüfungen von 1.6.1.

---

# Audit 1.6.0 · 09.10.2026

Ausgangspunkt: unverändertes Produktionspaket 1.5.1; Quellenabgleich und Kern-/Browserprüfung vor der neuen Veröffentlichung. Keine kritischen Speicherfehler festgestellt.

| Befund | Änderung |
| --- | --- |
| Mehrere Startaktionen und Rückblicke überladen Heute | Kalender und ein Start-/Fortsetzenknopf, danach persönliche Pläne und kompakter Fortschritt |
| Kalender zeigt nur sieben nicht interaktive Tagesmarken | Tage auswählbar, Woche/Monat blätterbar; lokale Kalenderarithmetik statt fester Millisekunden |
| 300 Übungen werden sofort gerendert | Zuerst fünf Treffer; gesamte Bibliothek wird vor Begrenzung durchsucht; bewusste Aufklappfunktion |
| Filter und Herkunftswissen belasten den Einstieg | Filter eingeklappt, wissenschaftliche Belege als optionale Dokumentation |
| Leistungsvergleich ist für die genutzten Maschinen unhilfreich | Sämtliche Einstiege/Ansicht aus der App entfernt; keine Referenzzahlen oder neue Ersatzheuristik |
| Bestehende Daten dürfen nicht neu importiert werden müssen | Speicher-/Schema-/Backupcode unverändert; tatsächliches PWA-Update mit vorher/nachher Datenvergleich geprüft |

Details und Grenzen der erneuten Funktionsprüfung: TESTING.md. Ein WebKit-Testtreiberproblem beim echten Offline-Neuladen wurde in der Vorversion reproduziert und als Testgrenze dokumentiert. Keine App-Daten wurden für Tests verwendet.

---

## Navigationskorrektur 1.5.1 · 08.10.2026

- Meldung: Die untere Leiste verschwindet beim Wechsel der Bereiche.
- Vor der Korrektur in 1.5.0 nachgestellt: Wechsel von Heute zur langen Übungsliste, Übergang bei 140 ms angehalten. Die Navigation bleibt im DOM sichtbar, wird aber im tatsächlichen Bild von der Seitenaufnahme überdeckt. Ein Pixeltest scheitert reproduzierbar am unveränderten Produktionsbuild.
- Ursache: Die View-Transition-Ebene wird vor sämtlichem normalen Seiteninhalt einschließlich fester Navigation gezeichnet. Ein höherer z-index der Navigation allein löst das nicht. Technische Grundlage: [W3C CSS View Transitions, View Transition Layer](https://www.w3.org/TR/css-view-transitions-1/#view-transition-layer).
- Korrektur: Animation direkt auf dem lebenden Seiteninhalt mit Web Animations; feste Steuerelemente liegen außerhalb. Keine dokumentweite Aufnahme, keine ausgesparte oder unsichtbar geschaltete Leiste während Tabwechseln. Laufende Inhaltsanimation wird bei einem weiteren Wechsel abgebrochen.
- Der Glass-Pill-Drag und die bisherigen Safe-Area-Abstände bleiben unverändert. Bei aktiver Bildschirmtastatur bleiben schwebende Leisten weiterhin absichtlich ausgeblendet; nach Verlassen des Felds werden sie eingeblendet.
- Ausschließlich künstliche Testdaten. Datenbank, Backupformat, Übungsdaten und Coaching unverändert. Ergebnisse und Hardwaregrenzen in TESTING.md.

## Prüfung vor und während 1.5.0 · 07.10.2026

- Unveränderten Ausgangsstand 1.4.1 mit dem gesicherten Quellcodepaket verglichen: keine Abweichungen; alle 79 bestehenden Kernprüfungen bestanden.
- Doppelte Planungseingabe: Satzanzahl/Range standen oberhalb der bereits vollständigen Einzelzeilen. Jetzt Anzahl aus Zeilen, pro Zeile Gewicht/Wiederholungen und Entfernen; Range/RIR unter Coach-Zielen. Keine Änderung bestehender Werte.
- WebKit-Regression fand ein Rennen zwischen dem Zurück-Schritt eines schließenden Sheets und dem Wechsel zur Trainings- bzw. Abschlussansicht. Navigation wartet jetzt auf den internen Zurück-Schritt; die Abschlussansicht öffnet nach dem Seitenwechsel. Ein eigener Hash-Wechsel schließt sie nicht mehr nachträglich.
- Cloud-Zugriff bewusst opt-in; öffentliche Konfiguration geprüft, geheime Schlüssel abgewiesen, Konto-Zuordnung vor Upload, lokale Speicherung und Auth getrennt. Konflikte und aktive Workouts verhindern unbemerkte Ersetzung.
- Keine Kundendaten gelesen oder in Tests verwendet. Keine Datenbankmigration. Teststand und Einschränkungen in TESTING.md.

# Forma – Ausgangsprüfung und Überarbeitung

## Verfeinerung 1.4.1 · 07.10.2026

Vor der Verfeinerung wurde der vorhandene Bedienungs-Regressionslauf auf 1.4.0 in Chromium erneut bestanden. Geändert wurden ausschließlich Oberfläche, Navigation und die Vorbereitung nachgeladener Ansichten; die Datenbank und fachlichen Berechnungen bleiben unverändert.

| Befund | Korrektur |
|---|---|
| Fortschritt ist auf Heute und unter Mehr doppelt einsortiert; Detail-Zurück führt zu Mehr | Fortschritt gehört zu Heute. Eine gemeinsame Aktion unter der Übersicht öffnet die vollständige Analyse; ausgewählter Zeitraum und aktiver Tab bleiben passend. |
| Seiten verschwinden abrupt, nachgeladene Ansichten können kurz einen Ladeplatzhalter zeigen | Seiten vor dem Übergang laden; kurze Überblendung mit kleinen Wegen, direkter Ersatzpfad ohne API/bei reduzierter Bewegung. |
| Glasregler springt beim ersten Kontakt unter den Finger | Ausgangsposition bis zur tatsächlichen Ziehbewegung beibehalten, Tipp und Drag unterscheiden. |
| Sheet-Inhalt wird vor dem Ende der Schließanimation entfernt; abgebrochenes Ziehen startet Öffnungsanimation erneut | Inhalt und Höhe bis zum Ende behalten; Öffnungsanimation nach Interaktion nicht neu starten; Schließen setzt an der gezogenen Position an. |
| Sehr schmale Heute-Ansicht läuft in WebKit seitlich über | Mindestbreite der Grid-Kinder lösen, Planüberschrift umbrechen lassen, Wochenanzeige an 320 px anpassen. |
| Bibliotheksüberschrift verbreitert den mobilen Layout-Viewport; Speichern der eigenen Übung nach Scrollen schlägt im Chromium-Bedientest fehl | Responsive Schriftgrößen und Umbruch ohne Abschneiden. Die Messung prüft jetzt gegen die tatsächliche Displaybreite statt den bereits verbreiterten Layout-Viewport. |

Nach Korrektur bestehen die betroffenen Tests in Chromium und WebKit: 41 schnelle Tab-Aktionen, unveränderte Sheet-Höhe beim Schließen, kurze und lange Ziehbewegungen, reduzierte Bewegung, API-Fallback, 320/390/1440 px, eigene Übungen, native Auswahl und Wiederöffnen. Der Service-Worker-Wechsel 1.4.0 → 1.4.1 erhält die exportierten Workouts, Pläne, Körpergewichte, eigenen Übungen, Video-Metadaten und Einstellungen exakt (abgesehen vom durch den Export aktualisierten Backupzeitpunkt). Das alte Backup lässt sich importieren, die aktualisierte App offline öffnen.

79 Logik-/Speichertests, Typprüfung und PWA-Artefaktprüfung sind erfolgreich. Weitere Bedienungsregressionen und Grenzen stehen in TESTING.md. Ein physisches iPhone und eine feste Bildrate wurden nicht geprüft.

## Vorherige Überarbeitung 1.4.0

Ausgangsprüfung: 6. Oktober 2026. Abschluss: 7. Oktober 2026. Ausgangsversion: 1.3.2. Keine echten Nutzerdaten werden für Tests verwendet.

## Prüfung vor der Überarbeitung

`npm run verify`: 79 erfolgreiche Logik-/Speichertests, TypeScript, Produktionsbuild und statische Offline-Artefaktprüfung. `npm run test:browser`: Kernablauf in Chromium erfolgreich: Erststart, einzelne Satzgewichte, RIR, Timer, Abschluss, JSON-Rundreise, ungültiger Import, Rückfallsicherung, kompletter Browser-Neustart offline, getrennte Projektpfade, Desktopdarstellung. Keine Laufzeitfehler in diesem Ablauf.

Zusätzlich wurden die Ansichten und ihre gemeinsamen Eingabe-/Overlay-Komponenten geprüft. Reproduzierbare Befunde (`scripts/audit-baseline.mjs`, Screenshots/JSON unter `test-results/baseline`):

| Priorität | Befund vor Änderungen | Ursache / geplante Korrektur |
|---|---|---|
| Hoch | 10 schnelle Klicks auf +2,5 ab 50 ergeben 52,5 statt 75 kg; +1 Wdh. ergibt 9 statt 18 | Veralteter Renderwert in parallel wartenden Schreibvorgängen. Innerhalb der bestehenden IndexedDB-Transaktion vom neuesten Satzwert rechnen. |
| Hoch | Zurück wechselt zu #workout, Übungsdetail bleibt offen | Overlays besitzen keinen eigenen Navigationszustand. Einheitliche Zurück- und Schließverwaltung. |
| Hoch | Planentwurf wird beim Schließen ohne Rückfrage verworfen | Ungespeicherte Änderungen schützen; versehentliches Wegwischen darf nicht löschen. |
| Mittel | Bei 320 px wird rechts die Satzabschlusstaste abgeschnitten, obwohl das Dokument keinen horizontalen Überlauf meldet | Mindestbreiten der Tabelle übersteigen den Karteninhalt. Eigene kompakte Satzanordnung. |
| Mittel | Haupt-App und Workout rechnen jede Sekunde alles neu | Countdown und Trainingsdauer in getrennte Komponenten verlagern. |
| Mittel | Historisches RIR kann gleichzeitig mit widersprüchlichem RPE gespeichert werden | Gleiche wechselseitige Priorität wie bei aktuellen Sätzen verwenden. |
| Mittel | Übung ersetzen verwirft bereits eingetragene Sätze ohne ausdrückliche Bestätigung | Vor dem Ersetzen vorhandener Daten eine Bestätigung anzeigen. |
| Mittel | Speichern/Kopieren einzelner Entwürfe hat keinen Schutz gegen schnelle Mehrfachbetätigung | Sofortige Sperre bis zum Ende der Transaktion; Formulare bei Fehlschlag offen halten. |
| Mittel | Nur beim Start wird nach App-Updates gesucht | Bei Rückkehr und auf ausdrücklichen Knopfdruck prüfen, Reload erst ohne laufendes Training und ohne offene Speichervorgänge. |
| Gestaltung | Viele kleine Touchziele, mehrere verschachtelte Scrollbereiche, grün getönte Flächen und inkonsistente Rundungen | Gemeinsame neutrale Tokens, ausreichend große Steuerelemente, begrenztes Glasmaterial auf Navigation und Overlays. |

## Datenerhalt

Unverändert bleiben Datenbankname, Pfadzuordnung, Object Store, Schema 3, Backupformat 3, sämtliche Übungs-IDs und Coachingregeln. Die atomare Read-Modify-Write-Transaktion, Importprüfung und Rückfallsicherung werden weiterverwendet. Ein Update derselben Installation erfordert keinen JSON-Import.

## Abschlussprüfung

Alle oben aufgeführten reproduzierten Eingabe-, Navigations- und Layoutfehler wurden korrigiert. Die verpflichtende zweite Prüfung ist abgeschlossen: 79 Tests, Typprüfung, Produktionsbuild, PWA-Artefakte sowie Kernabläufe in Chromium und WebKit. 10 schnelle +2,5-Schritte ergeben jetzt 75 kg statt 52,5; 10 Wiederholungsschritte ergeben 18 statt 9. Acht schnell hinzugefügte Sätze sind vollständig vorhanden. Rücknavigation, verschachtelte Dialoge, Entwurfsschutz und schmale Satzsteuerungen sind geprüft.

Ein echter Service-Worker-Wechsel vom unveränderten Produktionsbuild 1.3.2 auf 1.4.0 erhält im Exportvergleich Workouts, Satzdetails, individuelle Planvorgaben, eigene Übungen, Favoriten, Einstellungen, Körpergewicht und Video-Metadaten. PRs und Statistiken werden weiter aus denselben Workouts abgeleitet. Altes Backup importiert, neue Version offline geöffnet. Tests verwenden ausschließlich künstliche Daten in temporären Browserprofilen.

Ergebnisse, Reproduktion und offene Hardwareprüfungen stehen in `TESTING.md`. Linux-WebKit ist kein physischer iPhone-Test. Native Tastatur, tatsächliche Bildrate, Home-Bildschirm-Installation, VoiceOver und Posequalität echter Aufnahmen bleiben offen. Kein vollständiger formaler Accessibility- oder Sicherheits-Audit; kein Versprechen, dass Browser lokale Daten niemals löschen.
