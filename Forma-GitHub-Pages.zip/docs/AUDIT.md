# Forma 1.4 – Ausgangsprüfung und Überarbeitung

Ausgangsprüfung: 6. Oktober 2026. Abschluss: 7. Oktober 2026. Ausgangsversion: 1.3.2. Keine echten Nutzerdaten werden für Tests verwendet.

## Prüfung vor der Überarbeitung

`npm run verify`: 79 erfolgreiche Logik-/Speichertests, TypeScript, Produktionsbuild und statische Offline-Artefaktprüfung. `npm run test:browser`: Kernablauf in Chromium erfolgreich: Erststart, einzelne Satzgewichte, RIR, Timer, Abschluss, JSON-Rundreise, ungültiger Import, Rückfallsicherung, kompletter Browser-Neustart offline, getrennte Projektpfade, Desktopdarstellung. Keine Laufzeitfehler in diesem Ablauf.

Zusätzlich wurden die Ansichten und ihre gemeinsamen Eingabe-/Overlay-Komponenten geprüft. Reproduzierbare Befunde (`scripts/audit-baseline.mjs`, Screenshots/JSON unter `test-results/baseline`):

| Priorität | Befund vor Änderungen | Ursache / geplante Korrektur |
|---|---|---|
| Hoch | 10 schnelle Klicks auf +2,5 ab 50 ergeben 52,5 statt 75 kg; +1 Wdh. ergibt 9 statt 18 | Veralteter Renderwert in parallel wartenden Schreibvorgängen. Innerhalb der bestehenden IndexedDB-Transaktion vom neuesten Satzwert rechnen. |
| Hoch | Zurück wechselt zu #workout, Übungsdetail bleibt offen | Overlays besitzen keinen eigenen Navigationszustand. Einheitliche Zurück- und Schließverwaltung. |
| Hoch | Planentwurf wird beim Schließen ohne Rückfrage verworfen | Ungespeicherte Änderungen schützen; versehentliches Wegwischen darf nicht löschen. |
| Mittel | Bei 320 px wird rechts die Satzabschlusstaste abgeschnitten, obwohl das Dokument keinen horizontalen Überlauf meldet | Mindestbreiten der Tabelle übersteigen den Karteninhalt. Eigene kompakte Satzanordnung. |
| Mittel | Haupt-App und Workout rechnen jede Sekunde alles neu | Countdown und Trainingsdauer in getrennte Komponenten verlagern. |
| Mittel | Historisches RIR kann gleichzeitig mit widersprüchlichem RPE gespeichert werden | Gleiche wechselseitige Priorität wie bei aktuellen Sätzen verwenden. |
| Mittel | Übung ersetzen verwirft bereits eingetragene Sätze ohne ausdrückliche Bestätigung | Vor dem Ersetzen vorhandener Daten eine Bestätigung anzeigen. |
| Mittel | Speichern/Kopieren einzelner Entwürfe hat keinen Schutz gegen schnelle Mehrfachbetätigung | Sofortige Sperre bis zum Ende der Transaktion; Formulare bei Fehlschlag offen halten. |
| Mittel | Nur beim Start wird nach App-Updates gesucht | Bei Rückkehr und auf ausdrücklichen Knopfdruck prüfen, Reload erst ohne laufendes Training und ohne offene Speichervorgänge. |
| Gestaltung | Viele kleine Touchziele, mehrere verschachtelte Scrollbereiche, grün getönte Flächen und inkonsistente Rundungen | Gemeinsame neutrale Tokens, ausreichend große Steuerelemente, begrenztes Glasmaterial auf Navigation und Overlays. |

## Datenerhalt

Unverändert bleiben Datenbankname, Pfadzuordnung, Object Store, Schema 3, Backupformat 3, sämtliche Übungs-IDs und Coachingregeln. Die atomare Read-Modify-Write-Transaktion, Importprüfung und Rückfallsicherung werden weiterverwendet. Ein Update derselben Installation erfordert keinen JSON-Import.

## Abschlussprüfung

Alle oben aufgeführten reproduzierten Eingabe-, Navigations- und Layoutfehler wurden korrigiert. Die verpflichtende zweite Prüfung ist abgeschlossen: 79 Tests, Typprüfung, Produktionsbuild, PWA-Artefakte sowie Kernabläufe in Chromium und WebKit. 10 schnelle +2,5-Schritte ergeben jetzt 75 kg statt 52,5; 10 Wiederholungsschritte ergeben 18 statt 9. Acht schnell hinzugefügte Sätze sind vollständig vorhanden. Rücknavigation, verschachtelte Dialoge, Entwurfsschutz und schmale Satzsteuerungen sind geprüft.

Ein echter Service-Worker-Wechsel vom unveränderten Produktionsbuild 1.3.2 auf 1.4.0 erhält im Exportvergleich Workouts, Satzdetails, individuelle Planvorgaben, eigene Übungen, Favoriten, Einstellungen, Körpergewicht und Video-Metadaten. PRs und Statistiken werden weiter aus denselben Workouts abgeleitet. Altes Backup importiert, neue Version offline geöffnet. Tests verwenden ausschließlich künstliche Daten in temporären Browserprofilen.

Ergebnisse, Reproduktion und offene Hardwareprüfungen stehen in `TESTING.md`. Linux-WebKit ist kein physischer iPhone-Test. Native Tastatur, tatsächliche Bildrate, Home-Bildschirm-Installation, VoiceOver und Posequalität echter Aufnahmen bleiben offen. Kein vollständiger formaler Accessibility- oder Sicherheits-Audit; kein Versprechen, dass Browser lokale Daten niemals löschen.
