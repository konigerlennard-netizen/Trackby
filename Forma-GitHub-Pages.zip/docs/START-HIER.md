# Forma auf GitHub Pages – in wenigen Schritten

Version 1.5.1 · eigenständiger Export vom 08.10.2026

**Dein Trackby ist bereits veröffentlicht?** Nicht neu anfangen. Öffne [UPDATE-IPHONE.md](UPDATE-IPHONE.md): nur die Website-ZIP austauschen, der vorhandene Workflow bleibt. Die folgenden Schritte beschreiben eine Erstveröffentlichung.

## 1. Bisherige Trainingsdaten sichern

Öffne die **bisherige Forma-App auf deinem iPhone**. Wähle **Mehr → JSON exportieren** und sichere die Datei in „Dateien“. Sie enthält deine Workouts, Pläne, Satzdaten, Körpergewicht, eigene Übungen, Einstellungen und Video-Messergebnisse.

Die neue GitHub-Adresse hat einen eigenen Datenspeicher. Die Website-Dateien enthalten keine persönlichen Trainingsdaten. Deine Backup-Datei bleibt privat: **nicht in das öffentliche GitHub-Repository hochladen**. Originalvideos sind nicht im JSON enthalten; behalte sie in Fotos oder Dateien.

## 2. Die fertige Website hochladen

Am einfachsten geht der Upload auf einem Computer:

1. **Forma-GitHub-Pages.zip entpacken.** Danach siehst du direkt `index.html`, `assets`, `sw.js`, Icons und weitere Dateien.
2. Auf [github.com/new](https://github.com/new) ein **öffentliches** Repository erstellen, zum Beispiel `forma`. Für eine eigene Kopie ist kein ChatGPT-Konto erforderlich.
3. Im Repository **Add file → Upload files** öffnen. Bei einem leeren Repository heißt der Link auch **uploading an existing file**.
4. Den **gesamten Inhalt** des entpackten Ordners hochladen, einschließlich `assets/`, `docs/`, Icons, Manifest, `sw.js` und `.nojekyll`. Die `index.html` muss direkt im Hauptverzeichnis des Repositorys liegen. **Nicht nur die ZIP-Datei hochladen.** Mit **Commit changes** speichern.
5. **Settings → Pages** öffnen. Unter **Build and deployment → Source** den Eintrag **Deploy from a branch** wählen. Branch **main**, Ordner **/ (root)** auswählen und **Save** drücken.
6. Warten, bis GitHub den erfolgreichen Pages-Lauf anzeigt. Unter **Settings → Pages → Visit site** steht dein dauerhafter HTTPS-Link, normalerweise `https://DEIN-BENUTZERNAME.github.io/forma/`.

Dieser Weg benötigt keinen eigenen Build und keine Serverinstallation. Die Adresse bleibt verfügbar, solange das Repository und Pages aktiviert sind. Es ist kein zeitlich begrenzter Vorschau-Link.

## 3. Auf dem iPhone installieren

1. Den neuen **HTTPS-Link in Safari** öffnen.
2. **Teilen → Zum Home-Bildschirm** wählen.
3. Falls angezeigt, **Als Web-App öffnen** aktivieren und **Hinzufügen** tippen.
4. Forma über das neue Icon starten und einmal online laden lassen.
5. Unter **Mehr** prüfen, dass „Offline-Dateien sind für diese Version bereit“ angezeigt wird.
6. **Mehr → JSON importieren** wählen, die zuvor gesicherte Datei auswählen, die Zusammenfassung prüfen und die Wiederherstellung bestätigen.
7. Ein vorhandenes Workout und deinen Trainingsplan öffnen. Die neue App schließen und erneut öffnen; die Daten sollen wieder da sein.

Safari und eine installierte Web-App können getrennte Speicher verwenden. Importiere deshalb am besten direkt in die installierte App. Die alte App erst entfernen, wenn das Backup vorhanden ist und die Daten in der neuen App geprüft sind.

## Speicherung und Backups

- IndexedDB speichert Änderungen lokal, einschließlich aktiver Workouts und einzelner Sätze. Es ist kein Konto erforderlich.
- Unter **Mehr → Dauerhafte Speicherung anfragen** kannst du zusätzlichen Schutz vor automatischer Speicherbereinigung anfragen. Der Browser entscheidet über die Freigabe.
- Regelmäßig **JSON exportieren** und die Datei behalten. Löschen von Website-Daten, privates Surfen, Gerätewechsel oder Speicherdruck können lokale Daten entfernen. IndexedDB ist kein Cloud-Backup.
- Der JSON-Import ersetzt nach Bestätigung den aktuellen Stand. **Letzten Import rückgängig machen** stellt den davor gespeicherten Stand wieder her.
- Gleiche Adresse bei Updates beibehalten. Ein anderer Repositoryname, eine andere Domain oder ein anderer Browser verwendet einen anderen Speicher; dort per JSON umziehen.

## Videoanalyse

Die vorhandene experimentelle Videoanalyse ist enthalten. Deine Aufnahmen werden lokal verarbeitet. Die automatische Erkennung lädt das MediaPipe-Modell und dessen Laufzeit bei Bedarf von Google/jsDelivr und braucht dafür Internet. Diese Dateien sind keine ChatGPT-Sites-Abhängigkeit. Manuelle Wiederholungsmarkierung funktioniert ohne Modell. Originalvideos bleiben in deinen Fotos/Dateien.

## Quellcode bearbeiten – optional

**Forma-Quellcode.zip** ist das Entwicklungsprojekt mit React, TypeScript, Vite, Tests und Dokumentation. Es wird **nicht zusätzlich in die fertige Website kopiert**.

Mit Node.js 24 LTS:

```sh
npm ci
npm run dev
```

Produktionsdateien erstellen:

```sh
npm run verify
```

Danach den gesamten Inhalt von `dist/` veröffentlichen. Alternativ das Quellcodeprojekt samt `.github/workflows/pages.yml` in ein eigenes Repository übernehmen und **Settings → Pages → Source → GitHub Actions** wählen. Der enthaltene Workflow prüft und baut die App automatisch.

## Falls die Seite nicht öffnet

- **404:** Ist `index.html` direkt im Hauptverzeichnis? Ist Pages auf **main / (root)** gestellt? Ist der Lauf unter **Actions** abgeschlossen? Öffnest du den Link von **Visit site**?
- **Leere Seite:** Wurden `assets/` und alle übrigen Dateien mit hochgeladen? Verwende die gebaute Website, nicht die Quellcode-`index.html`.
- **Lokal per Doppelklick:** `file://` ist kein geeigneter PWA-Start. Nutze den HTTPS-Link oder für Entwicklung `npm run dev`.
- **Noch keine Daten:** Die neue Adresse beginnt leer. Backup aus der bisherigen App importieren.
- **Alte Version:** Workout beenden, andere Forma-Tabs schließen und die angebotene Aktualisierung übernehmen. Vorher bei Bedarf JSON sichern; nicht als erste Maßnahme Website-Daten löschen.

Offizielle Anleitung (am 01.10.2026 geprüft): [GitHub Pages veröffentlichen](https://docs.github.com/en/pages/getting-started-with-github-pages/configuring-a-publishing-source-for-your-github-pages-site).
