# Eigene Übungen · 4REPS 1.24.0

## Eine eigene Übung ändern

1. **Übungen → Eigene** öffnen und die gewünschte Übung antippen.
2. **Eigene Übung bearbeiten** wählen.
3. Name, Gerät oder Hauptmuskel anpassen. Unter **Weitere Angaben** stehen englischer Name, Bewegungsmuster, zusätzliche Muskelgruppen, Ausführungshinweise und Suchnamen.
4. **Änderungen speichern** antippen. Ohne Änderungen bleibt die Taste deaktiviert.

Die Übung behält ihre Verbindung zu deinen Plänen, Trainings, Favoriten, Notizen und Videoanalysen. Namen und Muskelzuordnung werden auch für frühere Einträge aktualisiert. Eine geänderte Muskelzuordnung wirkt sich auf entsprechende Statistiken aus. Gespeicherte Satzwerte und Zeiten bleiben erhalten.

Ist die Übung bereits in einem Plan (einschließlich dessen Vorfassung), Workout oder Video enthalten, bleibt ihre Messart fest. Dadurch werden bisherige Wiederholungen nicht versehentlich zu Sekunden oder Unterstützungsgewichte zu Zusatzgewicht. Für eine andere Messart eine neue Variante anlegen.

## Neue Übung oder Gerätevariante

Unter **Übungen → Eigene Übung** beginnst du leer. Seit 1.25.0 geht das auch direkt in der Übungsauswahl von Workout, Plan und Verlauf über **Eigene Übung anlegen**. Der Suchtext wird zum Namensvorschlag; nach dem Speichern wird die Übung ausgewählt. Der Editor zeigt zunächst nur Name, Gerät, Hauptmuskel und Messart. Gerätenamen kannst du frei eintragen; vorhandene Namen werden vorgeschlagen. Weitere Angaben sind optional und aufklappbar.

Eine vorhandene Übung öffnest du über **Dein Gerät & Gewichtsschritt → Als eigene Gerätevariante anlegen**. Ihre Angaben werden in den Editor kopiert und lassen sich vor dem Speichern anpassen. Die neue Variante wird als Favorit markiert, solange dort Platz ist. Sie erhält einen eigenen Verlauf und übernimmt keine alten Leistungen. Die Basisübung bleibt erhalten.

Bei dauerhaft anderem Gerät, Griff oder anderer Ausführung eine Variante anlegen, statt unterschiedliche Leistungen unter einer Übung zu sammeln.

## Suchen und speichern

Eigene Gerätenamen erscheinen im Gerätefilter. Deutsche und englische Namen sowie **Weitere Suchnamen** werden bei der Suche berücksichtigt. Pro Zeile einen Suchnamen eintragen. Gleiche Namen oder leere Pflichtfelder werden vor dem Speichern gemeldet.

Beim Schließen eines geänderten Entwurfs fragt die App nach. Bei einem Speicherfehler bleiben die Eingaben offen. Bearbeiten zwei Fenster dasselbe Feld unterschiedlich, wird die neuere Änderung nicht überschrieben; den Editor dann schließen und neu öffnen.

Alle Änderungen werden lokal gespeichert und sind im JSON-Backup sowie im bestehenden Cloud-Abgleich enthalten. Datenbank- und Backupformat bleiben unverändert. Die drei Minuten Standardpause und deine Layouts werden durch den Übungseditor nicht verändert.
