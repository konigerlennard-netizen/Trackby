# Assets und Lizenzen

Anatomische SVGs, Beispieltrainings und Produkttexte wurden für dieses Projekt erstellt. Keine Bilder oder Anleitungen aus Konkurrenz-Apps kopiert. Keine externen Fonts.

Ab Version 1.8.5 stammt das App-Icon aus dem vom Nutzer bereitgestellten Bild `8B971287-6A89-4175-98EC-E949C0302922.jpeg`, auf dessen ausdrücklichen Wunsch in diese App übernommen. Das Original ist im Quellcode unter `assets/branding/4reps-glass-original.jpeg` enthalten. Die PNG-Ausgaben ändern nur Größe und bei maskierbaren Icons den Außenrand. Für das bereitgestellte Bild wird keine zusätzliche Open-Source-Lizenz behauptet.

Die von diesem Projekt erstellten Dateien können für die eigene App verwendet und geändert werden. Rechte und Lizenzbedingungen eingebundener Drittanbieter bleiben bestehen.

Version 1.7.0: Das 4REPS-Icon (`public/icon-4reps.svg`, daraus gerenderte PNGs) und die schematischen Gerätesymbole (`features/forma/EquipmentMark.tsx`) sind eigene Vektorzeichnungen. Keine Produktfotos oder Gerätegrafiken anderer Anbieter. Selbst ausgewählte Hintergrundfotos bleiben lokal; sie werden nicht als Projektassets mitgeliefert oder veröffentlicht.

## Direkte Komponenten

| Paket | Installierte Version | Lizenz laut Paketmetadaten |
|---|---|---|
| react | 19.2.6 | MIT |
| react-dom | 19.2.6 | MIT |
| vite | 8.0.13 | MIT |
| typescript | 5.9.3 | Apache-2.0 |
| radix-ui | 1.6.7 | MIT |
| lucide-react | 1.49.0 | ISC |
| recharts | 3.10.1 | MIT |
| zod | 3.25.76 | MIT |
| cmdk | 1.1.1 | MIT |
| sonner | 2.0.8 | MIT |
| tailwindcss | 4.2.1 | MIT |

shadcn-Komponenten basieren auf MIT-lizenzierten Vorlagen. Erhaltene Lizenzdateien: `vendor/shadcn-tailwind-4.13.0.LICENSE.md`. Die Lizenztexte der installierten Abhängigkeiten sind zusätzlich in `THIRD_PARTY_NOTICES.txt` enthalten und werden mit der Produktionswebsite ausgeliefert. `package-lock.json` dokumentiert die genauen Versionen einschließlich transitiver Abhängigkeiten. Die folgende Tabelle wurde für den Export aktualisiert; für alle Versionen gilt der Lockfile.

## Optionale Videoanalyse

Google MediaPipe Tasks Vision 0.10.21 (Apache-2.0), dynamisch von jsDelivr geladen; Pose Landmarker Lite von Google. Primärdokumentation: https://ai.google.dev/edge/mediapipe/solutions/vision/pose_landmarker und Quellcode/Lizenzen: https://github.com/google-ai-edge/mediapipe. Modell und Bibliothek werden nicht im Quellcodearchiv gebündelt. Die Nutzungsbedingungen des jeweiligen Distributionsartefakts gelten weiterhin.

## Forschung

Die aggregierten Referenzzellen in `features/forma/reference-data.json` sind eine maschinenlesbare Auswahl der Tabellen 3–6 aus van den Hoek et al. (2024), *Normative data for the squat, bench press and deadlift exercises in powerlifting: Data from 809,986 competition entries*, DOI https://doi.org/10.1016/j.jsams.2024.07.005. Der offizielle UniSC-Volltext kennzeichnet den Artikel als **Creative Commons Attribution 4.0 International**, https://creativecommons.org/licenses/by/4.0/. Bearbeitung durch Forma: Auswahl geprüfter Zellen/Spalten, Übertragung ins JSON-Format und deutsche Darstellung. Autoren-, Quellen- und Lizenzhinweise stehen auch in der Ansicht. Reproduzierbarer Import und Prüfsumme: `COMPARISON_METHOD.md` und `scripts/extract-reference-data.py`. Es werden keine Namen oder Einzelprofile importiert.

EVIDENCE.md paraphrasiert Forschung mit Originalquellen. Wissenschaftliche Volltexte und geschützte Grafiken werden nicht mitgeliefert. Die anatomische Grafik ist eine vereinfachte Eigenzeichnung, keine Kopie eines Anatomieatlas.

1.8.6: Dunkle Icon-Variante per Bildbearbeitung des vom Nutzer bereitgestellten Zeichens, auf dessen ausdrücklichen Wunsch. Original und bearbeitetes Masterbild unter assets/branding.
