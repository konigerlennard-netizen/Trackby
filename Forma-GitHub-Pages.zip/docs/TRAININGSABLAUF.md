# Weniger Schritte · 4REPS 1.19.0

## Training
Satz abhaken: Die gespeicherte Pause startet und der nächste offene Satz wird sichtbar. Drei Minuten bleiben der Standard. Unter **Mehr → So trainierst du → Nach dem Abhaken zum nächsten Satz** lässt sich der automatische Wechsel abschalten.

**Wie vorheriger Satz / Wie letzte Einheit** übernimmt abweichende Werte direkt. Bei Zeitübungen werden nur Sekunden kopiert. **Rückgängig** ist danach erreichbar. Der Coach zeigt seine Kernaussage; **Warum?** öffnet die Begründung, längere Details sind separat aufklappbar. Wichtige Warnungen bleiben sichtbar.

Fehlende Wiederholungen/Sekunden müssen ergänzt werden. Bei Nullgewicht, auffälligen Lastsprüngen oder markierten Schmerzen prüfst du die Eingabe vor dem Speichern. Ein bereits ausgeführter Satz kann trotz Hinweis bewusst dokumentiert werden. Der Hinweis legt kein sicheres Trainingsgewicht fest. Freitext wird nicht medizinisch interpretiert.

## Startseite und Pläne
Die Stecknadel in **Pläne** kennzeichnet deinen **Startplan**. Der Wochenplan hat Vorrang. Ohne Anheften folgt die Startseite der nächsten Position deiner Planliste nach dem letzten abgeschlossenen Plan. Das legt keine Trainingstage oder Erholungspausen fest.

**Neuer Plan**: leer beginnen, die letzte Einheit übernehmen oder eine bestehende Grundvorlage wählen. Übernommene abgeschlossene Arbeitssätze erhalten unabhängige Satzvorgaben; die Kopie öffnet sich zur Anpassung. Vorlagen sind Beispiele.

## Verlauf und Statistik
Das Dreieck neben einem Training startet es erneut. Im geöffneten Verlauf führt der Stift neben einem Satz zu **Satz korrigieren**. Erst **Korrektur speichern** übernimmt den Entwurf. **Mit vorherigem Training vergleichen** zeigt Arbeitssätze nebeneinander; andere Ausführung oder Vorgaben werden gekennzeichnet.

**Das zeigt dein Verlauf** fasst vergleichbare Entwicklungen im ausgewählten Zeitraum zusammen. Fehlende Daten erzeugen keine Kraft-Prozentzahl. Körpergewicht wird nicht als Fett- oder Muskeländerung ausgelegt. **Diese Woche vergleichen** öffnet den separaten Wochenvergleich.

## Backup
Ein Hinweis erscheint nach mindestens drei neuen abgeschlossenen Trainings oder sieben neuen Gewichtseinträgen, wenn der letzte JSON-Export mindestens 14 Tage zurückliegt. Ohne bisherigen Export reicht die Zahl neuer Einträge. Während des Trainings und im Demo-Modus bleibt er verborgen.

**Backup herunterladen** startet den JSON-Download. Lege die Datei anschließend auf deinem Gerät ab. Das Kreuz blendet den Hinweis für sieben Tage aus. Es gibt keine Hintergrundbenachrichtigung.
