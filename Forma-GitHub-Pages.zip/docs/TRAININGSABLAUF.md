# Weniger Schritte · 4REPS 1.24.0

## Training
**Unterbrechen** hält die Trainingszeit und eine laufende Satzpause an; **Fortsetzen** setzt beides fort. Die Unterbrechung bleibt beim Schließen der App erhalten. Sie zählt nicht zur Trainingsdauer; gewöhnliche Satzpausen zählen weiter dazu. Ein App-Wechsel allein unterbricht das Training nicht.

Unter **Ansicht & Check-in** findest du Layout, Einzelansicht und Check-in. **Workout verwerfen** steht oben, **Workout beenden** ganz unten.

Satz abhaken: Die gespeicherte Pause startet und der nächste offene Satz wird sichtbar. Drei Minuten bleiben der Standard. Unter **Mehr → So trainierst du → Nach dem Abhaken zum nächsten Satz** lässt sich der automatische Wechsel abschalten.

**Wie vorheriger Satz / Wie letzte Einheit** übernimmt abweichende Werte direkt. Bei Zeitübungen werden nur Sekunden kopiert. **Rückgängig** ist danach erreichbar. Der Coach zeigt seine Kernaussage; **Warum?** öffnet die Begründung, längere Details sind separat aufklappbar. Wichtige Warnungen bleiben sichtbar.

Fehlende Wiederholungen/Sekunden müssen ergänzt werden. Bei Nullgewicht, auffälligen Lastsprüngen oder markierten Schmerzen prüfst du die Eingabe vor dem Speichern. Ein bereits ausgeführter Satz kann trotz Hinweis bewusst dokumentiert werden. Der Hinweis legt kein sicheres Trainingsgewicht fest. Freitext wird nicht medizinisch interpretiert.

## Startseite und Pläne
Die Stecknadel in **Pläne** kennzeichnet deinen **Startplan**. Der Wochenplan hat Vorrang. Ohne Anheften folgt die Startseite der nächsten Position deiner Planliste nach dem letzten abgeschlossenen Plan. Das legt keine Trainingstage oder Erholungspausen fest.

**Neuer Plan**: leer beginnen, die letzte Einheit übernehmen oder eine bestehende Grundvorlage wählen. Übernommene abgeschlossene Arbeitssätze erhalten unabhängige Satzvorgaben; die Kopie öffnet sich zur Anpassung. Vorlagen sind Beispiele.

## Eigene Übungen
Unter **Übungen → Eigene** eine Übung öffnen und **Eigene Übung bearbeiten** antippen. Vier Grundangaben stehen direkt bereit; Hinweise und weitere Muskeln findest du unter **Weitere Angaben**. Erst **Änderungen speichern** übernimmt den Entwurf. Name und Zuordnung gelten auch für frühere Einträge; Satzwerte bleiben erhalten.

**Dein Gerät & Gewichtsschritt → Als eigene Gerätevariante anlegen** übernimmt die Angaben einer vorhandenen Übung zur Anpassung. Die neue Variante hat einen eigenen Verlauf. [Details](EIGENE-UEBUNGEN.md).

## Verlauf und Statistik
Die Suche findet Training, Übungen, englische Namen und Notizen. Unter **Filter** wählst du Zeitraum, Übung oder Plan. Zunächst erscheinen 30 Einheiten; **Weitere Workouts anzeigen** lädt die nächsten.

Im geöffneten Workout stehen Trainingszeit, abgeschlossene Sätze und tatsächlich trainierte Übungen im Vordergrund. **Übungen & Sätze** klappt die Details und Vergleiche auf. Bestwerte erscheinen, wenn es einen geeigneten früheren Vergleich gibt.

Das Dreieck neben einem Training startet es erneut. Im geöffneten Verlauf führt der Stift neben einem Satz zu **Satz korrigieren**. Erst **Korrektur speichern** übernimmt den Entwurf. **Mit vorherigem Training vergleichen** zeigt Arbeitssätze nebeneinander; andere Ausführung oder Vorgaben werden gekennzeichnet.

**Das zeigt dein Verlauf** fasst vergleichbare Entwicklungen im ausgewählten Zeitraum zusammen. Fehlende Daten erzeugen keine Kraft-Prozentzahl. Körpergewicht wird nicht als Fett- oder Muskeländerung ausgelegt. **Diese Woche vergleichen** öffnet den separaten Wochenvergleich.

## Backup
Ein Hinweis erscheint nach mindestens drei neuen abgeschlossenen Trainings oder sieben neuen Gewichtseinträgen, wenn der letzte JSON-Export mindestens 14 Tage zurückliegt. Ohne bisherigen Export reicht die Zahl neuer Einträge. Während des Trainings und im Demo-Modus bleibt er verborgen.

**Backup herunterladen** startet den JSON-Download. Lege die Datei anschließend auf deinem Gerät ab. Das Kreuz blendet den Hinweis für sieben Tage aus. Es gibt keine Hintergrundbenachrichtigung.

Backupnamen folgen dem lokalen Datum, z. B. **4REPS-Backup-29-10-2026.json**. Demo-, Cloud- und lokale Sicherungsstände sind im Namen gekennzeichnet.
