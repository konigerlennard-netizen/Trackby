# Fortschrittsberechnung · Version 1.1.0

Stand: 28.09.2026. Coachingregeln 1.0.0 bleiben unverändert. Das Dashboard ist eine deskriptive Auswertung, keine medizinische Beurteilung und keine direkte Messung tatsächlicher Maximalkraft.

## Zeitraum und Darstellung

1 Tag (Datum wählbar), letzte 7 Kalendertage, 1/3/6 Kalendermonate, 1 Jahr, Gesamt und eigener Zeitraum. Start inklusiv, Ende exklusiv am Folgetag um 00:00 in der Geräte-Zeitzone. Monatsenden werden auf das letzte gültige Datum begrenzt. Sommer-/Winterzeit wird über Kalenderoperationen berücksichtigt. Workouts gehören zum Tag ihres Starts. Nur abgeschlossene Workouts werden ausgewertet; ein einzelner Messwert bleibt ein Punkt, ohne Trendbehauptung. Fehlende Tage werden nicht aufgefüllt.

Die Auswahl auf der Startseite wird in die vollständige Fortschrittsseite und deren Details übernommen. Die zusätzliche Trainingsstatistik und das Diagramm in der Übungsbibliothek besitzen eigene Zeitraumwahlen. Alle Auswertungen reagieren ohne Neuladen. Rohwerte werden nicht aus der Historie entfernt, nur aus der Vergleichsserie ausgeschlossen.

## Optionales Körpergewicht

Einträge: ID, Gewicht in kg, lokaler Messzeitpunkt als Unix-Zeit, optionale Notiz. kg/lb ist reine Anzeige-/Eingabeumrechnung. Einträge lassen sich über einen Diagrammpunkt oder die Eintragsliste bearbeiten und über die Punktdetails mit Bestätigung löschen. Es gibt keine Zielgewichte, BMI-Kategorien, Körperbewertungen, Erinnerungsserien, Kalorienvorgaben oder positive/negative Farbcodierung der Gewichtsrichtung.

Alle gespeicherten Punkte im Zeitraum werden angezeigt. Die Differenz zwischen erstem und letztem Eintrag ist ausdrücklich nur eine Messwertdifferenz. Für die gestrichelte Linie werden zuerst Tagesmediane gebildet, damit mehrere Messungen an einem Tag nicht mehr Gewicht erhalten. Ein gleitender Median der Tagesmediane über sieben Kalendertage wird nur mit mindestens drei Messtagen angezeigt. Für die geglättete Periodenänderung werden die ersten und letzten sieben Tage separat zusammengefasst: je mindestens drei Messtage, keine überlappenden Fenster. Ein einzelner Tag oder ein dünn besetzter Zeitraum liefert keinen künstlichen Trend. Das ist eine transparente Glättungsentscheidung, keine validierte Messung von Fett-, Muskel- oder Flüssigkeitsveränderungen.

## Leistungskennzahlen

Standard für geeignete Übungen mit externer Last: bestes geschätztes 1RM pro Übungsposition im abgeschlossenen Workout. Formel Epley: `Last × (1 + Wiederholungen / 30)`. Nur normale abgeschlossene Arbeitssätze, positive Last, 2–10 Wiederholungen. Eine bekannte Reserve über 3 schließt den Satz aus. Ein fehlender RIR kann für einen als Schätzung gekennzeichneten Rohwert noch angezeigt werden, verhindert aber den Prozentvergleich, wenn er den besten Satz betrifft. RPE wird als `10 − RPE` interpretiert, wenn kein RIR vorhanden ist. Reserve wird nicht rechnerisch auf die Wiederholungen addiert.

„Beste Leistung pro Workout“ verwendet bei geeigneten Übungen dieselbe Kennzahl; es ist keine zweite unabhängige Kraftmessung. Zusätzlich: höchstes Arbeitsgewicht, höchste Wiederholungszahl, normales Arbeitsvolumen und Anzahl normaler Arbeitssätze. Volumen ist `Σ Last × Wiederholungen`, keine eigenständige Kraftkennzahl. Warm-up, Back-off und Drop-Sätze werden im Detail angezeigt, aber nicht in diese Kennzahlen gerechnet.

Wenn keine geeignete 1RM-Schätzung vorliegt, kann die Wiederholungszahl bei gleicher externer Last verglichen werden. Dann müssen alle normalen Arbeitssätze dieselbe Referenzlast haben; die Basis wird neben der Prozentzahl genannt. Bei Körpergewichts-, unterstützten und zeitbasierten Übungen wird keine pauschale Kraftprozentzahl ausgegeben. Deren Rohwerte bleiben nutzbar; wechselndes Körpergewicht wird nicht stillschweigend zur Last addiert.

## Vergleichbare Serie

Ausgehend vom letzten Punkt im Zeitraum wird rückwärts eine ununterbrochene Serie gebildet. Ein Kontextwechsel oder fehlender erforderlicher Wert unterbricht sie. Geprüft werden:

- identische Übung, Techniknotiz, Position im Workout, Ziel-Satzanzahl, tatsächliche Arbeitssatzanzahl, Wiederholungsrange, RIR-Ziel, geplante Pause, Supersatzstatus und Tempo-/ROM-Notizen;
- bekannte Reserve des verwendeten besten Satzes, höchstens 3 RIR und höchstens 1 RIR Abstand zur aktuellen Referenz;
- keine dokumentierten Schmerzen/Krankheit im jeweiligen Workout beziehungsweise Übung;
- vollständig erfasste tatsächliche Zwischenpausen auf beiden Seiten oder auf beiden Seiten fehlend. Falls erfasst: Abweichung des Medians höchstens 30 Sekunden oder 25 % der aktuellen Pause (größerer Wert). Bei fehlenden Pausen wird die Unsicherheit genannt und nur die identische geplante Pause berücksichtigt;
- höchstens ein Beitrag je Workout. Mehrere Einheiten desselben Tages reichen nicht allein für eine Trendbewertung.

Nicht erfasste Geräte-/Griff-/Technikänderungen kann die App nicht erkennen. Vergleichbarkeit bedeutet nicht identische reale Bedingungen. Das gilt besonders für subjektiv geschätzten RIR und Unterschiede zwischen Geräten. Diese Grenzen stehen der Anzeige einer Prozentzahl entgegen, wenn erforderliche Informationen fehlen; die App erfindet keine Ersatzdaten.

## Prozent und Einordnung

Mindestens vier vergleichbare Einheiten an mindestens drei Kalendertagen. Bei 4–5 Einheiten wird der Median der ersten zwei mit dem Median der letzten zwei verglichen; ab sechs Einheiten werden jeweils drei verwendet. Die beiden Fenster überlappen nicht. Prozentwert: `(Endmedian / Anfangsmedian − 1) × 100`, mit `≈` und einer Nachkommastelle. Er beschreibt diese Kennzahl im ausgewählten Zeitraum, nicht eine exakt bekannte biologische Veränderung. Ein Planfilter wird vor der Berechnung angewandt.

Die folgenden Schwellen sind **Produktheuristiken, keine wissenschaftlich validierten individuellen Grenzwerte**:

| Zustand | Bedingung |
| --- | --- |
| Längerfristig niedrigere Werte | Mindestens 8 Einheiten über mindestens 28 Tage; alle letzten 4 liegen jeweils unter 97 % des Medians der 4 davor. |
| Einzelner niedrigerer Wert | Letzter Wert unter 94 % des Medians der vorherigen; die zwei unmittelbar davor liegen mindestens bei 97 % dieses Medians. |
| Positive Entwicklung | Geglättete Änderung über +3 %, soweit kein vorrangiger Hinweis greift. |
| Aktuell niedrigere Werte | Änderung unter −3 %, noch ohne hinreichenden Nachweis eines längerfristigen Abfalls. |
| Stabil mit mehr Reserve | Änderung innerhalb ±3 %, Median der angegebenen Reserve um mindestens 1 höher. |
| Länger stabil / mögliches Plateau | Mindestens 6 Einheiten über 42 Tage, Änderung innerhalb ±3 %, Gesamtspannweite höchstens 6 %, kein entsprechender Reserveanstieg. Kein automatischer Handlungsbedarf. |
| Schwankende Tageswerte | Änderung innerhalb ±3 %, größere Gesamtspannweite. |
| Ungefähr stabil | Übrige Fälle innerhalb ±3 %. |

Der Coach erhöht aufgrund dieser Anzeigen weder Last noch Satzanzahl automatisch. Ein negativer Tageswert ist kein persönliches Urteil.

## Persönliche Rekorde

Aus den ursprünglichen Workout-Sätzen neu berechnet, keine verlustanfällige zweite Datenkopie: höchstes normales Arbeitsgewicht, Wiederholungsrekord je Gewicht, höchstes geeignetes e1RM, größtes normales Arbeitsvolumen und bester e1RM-Leistungssatz. Detailrekorde beziehen sich auf die gesamte Aufzeichnung mit passender letzter Technik-/Tempo-/ROM-Notiz, nicht nur den sichtbaren Zeitraum. Ändern oder Löschen eines Workouts aktualisiert die Rekorde. Prozent gegenüber einem vorherigen e1RM-Rekord wird nur bei vorhandenem früheren passenden Rohwert angezeigt und ist von der geglätteten Fortschrittsprozentzahl getrennt. Größeres Volumen kann einfach durch zusätzliche Sätze entstehen.

## Wissenschaftlicher Kontext

- Mitter et al. (2022), *Reproducibility of strength performance and strength-endurance profiles: A test-retest study*. [DOI 10.1371/journal.pone.0268074](https://doi.org/10.1371/journal.pone.0268074). 24 trainierte Erwachsene, 15 Männer/9 Frauen, vier Labortermine in 11 Tagen, Bankdrücken. Test-Retest-Studie, keine Langzeitintervention. Ergebnisse zeigen Wiederholbarkeit, zugleich Messschwankungen und Grenzen allgemeiner Last-Wiederholungsmodelle. Kleine, übungsbezogene Stichprobe; keine Validierung unserer Medianfenster oder Prozentgrenzen. Evidenz für allgemeine Vorsicht: begrenzt bis mittel.
- Halperin et al. (2022; online 2021), *Accuracy in Predicting Repetitions to Task Failure in Resistance Exercise: A Scoping Review and Exploratory Meta-analysis*. [DOI 10.1007/s40279-021-01559-x](https://doi.org/10.1007/s40279-021-01559-x). 12 Studien, 414 gesunde Teilnehmende, unterschiedlicher Trainingsstatus; vollständige Dauerverteilung hier nicht extrahiert. Im Mittel wurde etwa eine mögliche Wiederholung unterschätzt, mit sehr hoher Heterogenität. Trainingsstatus beseitigte die Ungenauigkeit nicht. Stützt die vorsichtige Verwendung von RIR, nicht dessen mathematisch exakte Korrektur. Im Gegensatz zu einzelnen Studien mit Erfahrungseffekten zeigt die Meta-Regression keinen klaren Trainingserfahrungseffekt. Abstract und Verlagsinformationen geprüft; keine vollständige neue systematische Recherche.

Ergänzende gezielte Recherche: 28.09.2026. Hauptrecherche und allgemeine Trainingsprinzipien bleiben in [EVIDENCE.md](EVIDENCE.md) dokumentiert. Die bestehenden Coachingregeln ändern sich durch das Dashboard nicht.

## Speicherung und Update

IndexedDB auf dem Gerät, weiterhin ohne Account oder Upload der Messwerte. Zustandsschema 2 ergänzt `bodyWeights`; Schema 1 wird beim Lesen validiert und verlustfrei übernommen. Die nächste Speicherung schreibt Schema 2. Ein alter App-Tab kann Schema 2 nicht als Schema 1 validieren und überschreibt neue Felder deshalb nicht. Backupformat 2 enthält Gewichte, Version-1-Backups bleiben importierbar. Alte App-Versionen können neue Backups nicht lesen. Ein Import ersetzt den gesamten Stand nach Bestätigung, mit lokaler Rückfallsicherung.
