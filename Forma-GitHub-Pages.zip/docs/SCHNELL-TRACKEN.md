# Training erfassen · 4REPS 1.24.0

Gewicht und Wiederholungen direkt in die Satzfelder eingeben. Die zusätzliche Plus/Minus-Schnelleingabe ist entfernt, auch aus Layout-Auswahl und Vorschau. Bereits gespeicherte Layouts bleiben gültig.

**Wie vorheriger Satz / Wie letzte Einheit** übernimmt passende vorhandene Werte weiterhin. Weitere Satzangaben öffnet die Zusatzfelder.

Oben steht **Workout verwerfen** mit Rückfrage. Ganz unten öffnet **Workout beenden** den Abschlussdialog. Bestätige ihn mit **Workout speichern**.

Unter **Pause: 3:00 → Timer speichern** speicherst du die Pausendauer dauerhaft.

## Ersteinrichtung

Ohne bisherige Workouts erscheint auf Heute ein optionaler Einstieg. **Einrichten** öffnet Gewichtseinheit, Trainingserfahrung, allgemeinen Gewichtsschritt und die Zuordnung vorhandener Pläne zu Wochentagen. **Einrichtung speichern** übernimmt die Auswahl gemeinsam. **Später** blendet den Einstieg aus.

Unter **Mehr → So trainierst du → Einrichtung öffnen** lässt sich die Einrichtung jederzeit erneut aufrufen. Bereits erfasste Workouts werden nicht verändert. Nur die im Entwurf bearbeiteten Einstellungen und Wochentage werden gespeichert; andere parallele Änderungen bleiben bestehen. Widersprüchliche Änderungen werden gemeldet.

## Wochenvergleich

Unter **Mehr → Statistiken** steht der Vergleich der aktuellen Woche mit der Vorwoche. Beide Zeiträume beginnen am Montag und reichen bis zum gleichen lokalen Wochentag und derselben Uhrzeit. Die Berechnung berücksichtigt Zeitumstellungen.

Gezählt werden abgeschlossene Workouts nach Startdatum, die bis zum jeweiligen Vergleichszeitpunkt beendet waren. Laufende Einheiten zählen noch nicht mit. Arbeitssätze schließen Aufwärm-, Back-off- und Drop-Sets aus. Das Lastvolumen verwendet wie die bestehende Statistik externe Last beziehungsweise Zusatzgewicht mal Wiederholungen, einschließlich abgeschlossener Back-off- und Drop-Sets. Unterstützungsgewichte und Zeitübungen werden nicht als externes Lastvolumen gezählt. Die Zahlen beschreiben deine Aufzeichnungen; ein höherer Wert ist nicht automatisch besser.

## Update

Die passende Forma-GitHub-Pages.zip wie bisher ersetzen. Erwartete Version: 1.24.0. Automatisierte Ergebnisse stehen in TESTING.md. Kein echter Handy- oder interaktiver Browsertest.
