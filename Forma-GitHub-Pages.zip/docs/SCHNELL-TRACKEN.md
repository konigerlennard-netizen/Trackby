# Pausentimer speichern ab 1.14.0

Im Workout **Pause: 3:00 → gewünschte Dauer → Timer speichern** wählen. Bei aktivierter Automatik genügt anschließend der Haken am Satz. Die Einstellung bleibt auch für nächste Trainings gespeichert. **+30s** am laufenden Timer gilt nur für diese eine Pause.

# Einfachere Darstellung ab 1.13.0

Öffne in der Trainingskarte **Mit + / − anpassen**, um die großen Schnellregler zu verwenden. Auf dem Handy stehen Gewicht und Wiederholungen untereinander; Gewichtszahl und Einheit bleiben in derselben Zeile. Zusätzliche Satzwerte öffnest du über **Weitere Satzangaben**. Nach dem Abhaken startet die aktivierte Pausenautomatik mit **3:00 Minuten**.

# Schneller trainieren und erfassen · 4REPS 1.12.0

## Schnellbuttons im Workout

Unter der Satzeingabe steht **Nächster Satz** mit großen Plus/Minus-Tasten. Die Tasten ändern jeweils den nächsten offenen Satz dieser Übung. Die normalen Eingabefelder bleiben für direkte Zahlenangaben verfügbar.

- Gewicht verwendet den allgemeinen Gewichtsschritt oder deine Einstellung für diese Übung. **Gewichtsschritt ändern** speichert die Auswahl auch für spätere Workouts.
- Der Gewichtsschritt wird intern wie bisher in kg gespeichert. Bei lb wird die Anzeige umgerechnet; die Auswahl bietet dazu passende lb-Schritte an.
- Wiederholungen ändern sich einzeln. Bei Zeitübungen ändern die Tasten die Dauer um fünf Sekunden; dort gibt es keine Gewichtsschritte.
- Bei Übungen mit Unterstützung heißt das Feld **Hilfe**. Mehr Hilfe bedeutet mehr Unterstützung durch das Gerät. Bei Körpergewichtsübungen wird das Zusatzgewicht geändert.

**Letzten Satz übernehmen** kopiert Gewicht und Wiederholungen aus einem früheren abgeschlossenen Satz desselben Satztyps in dieser Einheit. **Aus letzter Einheit** verwendet den entsprechenden Satz desselben Typs aus der vorherigen Einheit. Aufwärm- und Arbeitssätze werden nicht vermischt. Die verfügbaren Werte stehen direkt auf der Taste. RIR/RPE, Notizen, Pausen und Zeitmarken werden nicht mitkopiert; bei Zeitübungen wird nur die Dauer übernommen.

Nach dem Kopieren erscheint **Rückgängig**. Es funktioniert, solange Gewicht und Wiederholungen seitdem nicht weiter geändert wurden und der Satz noch offen ist. Schnellaktionen ändern niemals einen bereits abgeschlossenen oder entfernten Satz. Schnelle aufeinanderfolgende Plus/Minus-Tipps werden auf dem jeweils zuletzt gespeicherten Wert ausgeführt.

Ist die Schnelleingabe ausgeblendet, aktiviere sie unter **Layout bearbeiten → Workout → Schnelle Satzeingabe**. Die gewählte Reihenfolge deiner Workout-Bereiche bleibt erhalten.

## Ersteinrichtung

Ohne bisherige Workouts erscheint auf Heute ein optionaler Einstieg. **Einrichten** öffnet Gewichtseinheit, Trainingserfahrung, allgemeinen Gewichtsschritt und die Zuordnung vorhandener Pläne zu Wochentagen. **Einrichtung speichern** übernimmt die Auswahl gemeinsam. **Später** blendet den Einstieg aus.

Unter **Mehr → So trainierst du → Einrichtung öffnen** lässt sich die Einrichtung jederzeit erneut aufrufen. Bereits erfasste Workouts werden nicht verändert. Nur die im Entwurf bearbeiteten Einstellungen und Wochentage werden gespeichert; andere parallele Änderungen bleiben bestehen. Widersprüchliche Änderungen werden gemeldet.

## Wochenvergleich

Unter **Mehr → Statistiken** steht der Vergleich der aktuellen Woche mit der Vorwoche. Beide Zeiträume beginnen am Montag und reichen bis zum gleichen lokalen Wochentag und derselben Uhrzeit. Die Berechnung berücksichtigt Zeitumstellungen.

Gezählt werden abgeschlossene Workouts nach Startdatum, die bis zum jeweiligen Vergleichszeitpunkt beendet waren. Laufende Einheiten zählen noch nicht mit. Arbeitssätze schließen Aufwärm-, Back-off- und Drop-Sets aus. Das Lastvolumen verwendet wie die bestehende Statistik externe Last beziehungsweise Zusatzgewicht mal Wiederholungen, einschließlich abgeschlossener Back-off- und Drop-Sets. Unterstützungsgewichte und Zeitübungen werden nicht als externes Lastvolumen gezählt. Die Zahlen beschreiben deine Aufzeichnungen; ein höherer Wert ist nicht automatisch besser.

## Prüfung und Update

Automatisierte Tests prüfen unter anderem schnelle Mehrfachtipps, parallele Eingaben, kg/lb, Satztypen, Rückgängig, Einrichtungs-Konflikte, Neustart/Backup und lokale Wochenabschnitte. Ergebnisse und Grenzen stehen in TESTING.md und RELEASE_VALIDATION.json. Die neue Bedienung wurde hier nicht auf einem echten Handy oder in einem echten Browser getestet.

Für das Update die passende **Forma-GitHub-Pages.zip** unter demselben Namen wie bisher ersetzen. Nach dem erfolgreichen GitHub-Lauf in der App nach Updates suchen; erwartet wird **1.12.0**.
