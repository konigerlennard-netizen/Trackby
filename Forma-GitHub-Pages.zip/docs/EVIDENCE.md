# Wissenschaftliche Grundlage von Forma

**Literaturrecherche: 22.–23. September 2026. Regeln: 1.0.0.**

**Gezielte Ergänzung 30.09.2026:** Übungsvarianten/Kreuzheben und veröffentlichte Leistungsreferenzen geprüft. Kein erneuter Vollreview der Trainingsliteratur. Für den optionalen Leistungsvergleich sind Population, Stichprobe, Zeitraum, Tabellenfehler, Ausschlüsse und Abgleich mit einer neueren Studie vollständig in [COMPARISON_METHOD.md](COMPARISON_METHOD.md) dokumentiert. Vergleichsregeln 1.0.0 sind von den Trainings-Coachingregeln getrennt.

**Ergänzung am 28. September 2026:** Quellen zu Wiederholungs-/1RM-Schätzungen und der Unsicherheit subjektiver Reserve für das Fortschrittsdashboard geprüft. Studiendaten und Grenzen: [PROGRESS_METHOD.md](PROGRESS_METHOD.md). Diese Ergänzung ist keine erneute Vollprüfung des gesamten Quellenregisters. Die dort beschriebenen Vergleichsschwellen sind ausdrücklich Produktheuristiken; Coachingregeln 1.0.0 bleiben unverändert.

**Übungsbibliothek am 28. September 2026 ergänzt:** Gezielte Prüfung zu engem/breitem Rudern und Ellenbogenführung; siehe E21/E22 und die Einordnung unter Anatomie. Keine erneute Vollrecherche aller Themen.

Forma ist ein Trainingslogbuch mit transparenten, vorsichtigen Entscheidungshilfen. Es bewertet weder Aussehen noch Körpergewicht und erstellt keine Ernährungs- oder Kalorienziele. Es gibt keine Pflicht zur Steigerung und keine automatische Erhöhung des Trainingsumfangs.

## Recherche und Grenzen

Gezielte Recherche nach systematischen Reviews, Meta-Analysen, kontrollierten Studien und Fachgesellschaftskonsensen in PubMed/PMC sowie auf Verlags- und Fachgesellschaftsseiten. Suchbegriffe umfassten resistance training, progression, volume, frequency, repetitions in reserve, failure, rest intervals, range of motion, muscle length, autoregulation, deload, sleep und youth. Neuere Übersichten wurden mit einschlägigen älteren Arbeiten verglichen. Produktseiten dienten ausschließlich der Konkurrenzanalyse, nicht als wissenschaftliche Belege.

Dies ist eine **strukturierte, gezielte Recherche, kein registrierter systematischer Review** mit vollständigem Screening und doppelter Datenextraktion. Einige Quellen waren nur als Abstract zugänglich. „NR“ bedeutet unten: in den tatsächlich eingesehenen Informationen nicht zuverlässig extrahiert; nicht, dass die Originalarbeit diesen Wert nicht berichtet. Fehlende Stichprobengrößen und Zeitspannen wurden nicht geschätzt. Diese Lücken begrenzen die Bewertung. Quellenangaben sind keine Behauptung einer medizinischen Validierung der App.

Evidenzstärke bezeichnet hier eine qualitative Produkteinordnung, keine nachträgliche formale GRADE-Bewertung: **hoch** = breite, relativ konsistente Synthese für die allgemeine Aussage; **mittel** = begrenzte oder heterogene Synthese; **niedrig** = kleine Einzelstudien, indirekte Evidenz oder Expertenkonsens. Die Sicherheit eines individuellen App-Vorschlags ist davon getrennt.

Die meisten Trainingsstudien untersuchen Erwachsene, häufig junge Männer. Resultate sind nicht automatisch auf Minderjährige, Erkrankungen, Rehabilitation oder hochtrainierte Athleten übertragbar. Für Jugendliche stehen fachkundige Anleitung, kontrollierbare Belastung, Freude an Bewegung und die gesamte Sportbelastung im Vordergrund. Die App fordert keine Maximalversuche, kein Training bis zum Versagen und keine zusätzlichen Einheiten zur Erfüllung einer Serie.

## Quellenregister

### E01 · Überblick / ACSM

Currier et al. (2026), *Resistance Training Prescription for Muscle Function, Hypertrophy, and Physical Performance in Healthy Adults: An Overview of Reviews*. ACSM-Positionspapier. [Volltext](https://pmc.ncbi.nlm.nih.gov/articles/PMC12965823/) · DOI [10.1249/MSS.0000000000003897](https://doi.org/10.1249/MSS.0000000000003897).

- Design/Population: Übersicht über 137 systematische Reviews, insgesamt über 30.000 Teilnehmende; gesunde Erwachsene ab 18, viele Untrainierte. Überschneidende Primärstudien möglich; die Zahl ist keine unabhängige Megastichprobe.
- Dauer: zugrunde liegende Interventionen überwiegend 6–52 Wochen; Literatursuche bis Oktober 2024.
- Einordnung: hoch für den allgemeinen Nutzen von Krafttraining; variabel für einzelne Stellschrauben. Keine individuelle optimale Trainingsdosis ableitbar. Publikationsjahr 2026 bedeutet nicht vollständige Abdeckung der Forschung bis 2026.
- Anwendung: einfache, fortführbare Pläne; keine Behauptung, eine komplexe Methode sei zwingend überlegen. Erwachsenenbefunde werden nicht als Jugendleitlinie ausgegeben.

### E02 · Last, Sätze, Frequenz

Currier et al. (2023), Netzwerk-Meta-Analyse. [PubMed](https://pubmed.ncbi.nlm.nih.gov/37414459/) · DOI [10.1136/bjsports-2023-106807](https://doi.org/10.1136/bjsports-2023-106807).

- Kraft: 178 Studien, n=5.097; Hypertrophie: 119 Studien, n=3.364. Gesunde Erwachsene mit unterschiedlicher Trainingserfahrung; Studienlängen heterogen, vollständige Spanne hier NR.
- Höhere Lasten begünstigen besonders die Leistung bei schweren Krafttests. Muskelaufbau ist mit unterschiedlichen Lastbereichen möglich; mehrere Sätze schneiden oft günstig ab.
- Evidenz mittel–hoch für diese allgemeinen Unterschiede; Netzwerkvergleiche und Rangfolgen sind kein persönliches Optimum. Trainingsstatus, Anstrengung und Messverfahren unterscheiden sich.
- Anwendung: frei einstellbare Wiederholungsrange, keine Aussage „8–12 ist für alle optimal“.

### E03 · Progression durch Last oder Wiederholungen

Plotkin et al. (2022), *Progressive overload without progressing load?* [PeerJ](https://doi.org/10.7717/peerj.14142) · [PubMed](https://pubmed.ncbi.nlm.nih.gov/36199287/).

- Randomisierte Untersuchung, 43 rekrutiert, 38 abgeschlossen; trainierte Erwachsene, 8 Wochen Unterkörpertraining. Progression über Wiederholungen versus Last.
- Beide Wege ermöglichten Anpassungen. Kleine Stichprobe, kurze Laufzeit und spezifische Übungen begrenzen Schlussfolgerungen.
- Evidenz mittel für die Brauchbarkeit beider Wege, niedrig für konkrete Double-Progression-Schwellen.
- Anwendung: Wiederholungen stabilisieren ist ein legitimer nächster Schritt. „Alle Sätze in zwei bzw. drei Einheiten oben, dann höchstens 5 %“ ist **unsere vorsichtige Produktheuristik**, nicht das Resultat dieses Trials.

### E04 · Volumen und Frequenz

Pelland et al. (online 2025, Zeitschriftenausgabe 2026), *The Resistance Training Dose Response*. [PubMed](https://pubmed.ncbi.nlm.nih.gov/41343037/) · DOI [10.1007/s40279-025-02344-w](https://doi.org/10.1007/s40279-025-02344-w).

- Mehrstufige Meta-Regression: 67 Studien, n=2.058; 79,1 % Männer, mittleres Alter etwa 25 Jahre. Trainingsstatus gemischt, Dauer unterschiedlich; vollständige Spanne NR.
- Mehr Volumen kann mit mehr Anpassung einhergehen, mit abnehmendem Zusatznutzen. Direkte und indirekte Sätze wurden unterschiedlich modelliert.
- Evidenz mittel: Meta-Regression zeigt Gruppenbeziehungen, keine Kausalformel für einen einzelnen Nutzer. Eine rechnerische halbe Beteiligung entspricht keiner exakt halben biologischen Wirkung.
- Anwendung: direkte Sätze pro Muskel transparent zählen, sekundäre Beteiligung nicht als präzise Dosis ausgeben. Keine automatische Satzsteigerung und keine starre „optimale“ Wochenzahl.

### E05 · Nähe zum Versagen / RIR

Robinson et al. (2024), explorative Meta-Regression. [PubMed](https://pubmed.ncbi.nlm.nih.gov/38970765/).

- Erwachsenenstudien zu Kraft und Hypertrophie; Trainingsstatus und Dauer heterogen. Gesamt-n und vollständige Dauer hier NR. RIR wurde teilweise aus Studienbeschreibungen geschätzt.
- Nähe zum Versagen steht besonders bei Hypertrophie mit Ergebnissen in Beziehung; für Kraft ist der Zusammenhang anders. Daraus folgt keine Pflicht zum Muskelversagen und kein universeller optimaler RIR-Wert.
- Evidenz mittel für die Einordnung, niedrig für exakte individuelle Schwellen. Geschätzte Reserve, Last, Ermüdung und Trainingsstatus erschweren die Interpretation.
- Anwendung: RIR/RPE optional; RIR 0 blockiert Laststeigerung. RPE 8 ≈ 2 RIR gilt nur für die verwendete krafttrainingsspezifische Skala.

### E06 · Pausenzeiten

Singer et al. (2024), systematischer Review und Bayesianische Meta-Analyse. [Volltext](https://www.frontiersin.org/journals/sports-and-active-living/articles/10.3389/fspor.2024.1429789/full) · DOI 10.3389/fspor.2024.1429789.

- 9 Studien, 19 Messungen; überwiegend Männer, trainierte und untrainierte sowie jüngere und ältere Erwachsene; 5–10 Wochen. Eindeutiges gepooltes Personen-n hier nicht übernommen.
- Leichte Vorteile längerer gegenüber sehr kurzen Pausen sind möglich; Unsicherheitsintervalle überlappen. Kein Beleg für eine universell optimale 120-Sekunden-Pause.
- Evidenz mittel. Unterschiedliche Übungen, Lasten und Volumenerhaltung können Unterschiede erklären.
- Anwendung: bei dokumentierter kurzer Pause und starkem Satzabfall längere Pause prüfen. 25 % Abfall und 120 Sekunden sind Heuristiken. Unbekannte Pausen bleiben unbekannt.

### E07 · Split versus Ganzkörper

Ramos-Campo et al. (2024), systematischer Review/Meta-Analyse. [PubMed](https://pubmed.ncbi.nlm.nih.gov/38595233/) · DOI [10.1519/JSC.0000000000004774](https://doi.org/10.1519/JSC.0000000000004774).

14 Studien, n=392 gesunde Erwachsene; Status und Laufzeiten unterschiedlich, genaue Dauer NR. Bei vergleichbarem Volumen kein klarer genereller Vorteil eines Splits für Kraft oder Muskelaufbau. Evidenz mittel. Anwendung: Ganzkörper, Upper/Lower oder Push/Pull/Legs sind Organisationsformen; Alltag und weitere Sportarten zählen. Die App vergibt keine Punkte für mehr Trainingstage.

### E08 · Muskellänge und regionale Anpassung

Varović et al. (2025), Bayesianischer systematischer Review/Meta-Analyse. [PubMed](https://pubmed.ncbi.nlm.nih.gov/40570881/) · DOI [10.1055/a-2615-4935](https://doi.org/10.1055/a-2615-4935).

12 Studien mit jungen Erwachsenen; Gesamt-n, Statusverteilung und Dauer im eingesehenen Abstract NR. Für die untersuchten regionalen Messstellen überwiegend kleine Unterschiede zwischen längeren und kürzeren mittleren Muskellängen; die Längenkontraste waren begrenzt. Evidenz mittel, keine allgemeine Widerlegung möglicher Vorteile langer Muskellängen. Anwendung: ROM und Übungsvariante dokumentieren, keinen pauschalen ROM-Sieger festlegen.

### E09 · Lange Teilwiederholungen

Wolf et al. (2025), kontrollierte Untersuchung *Lengthened partial repetitions elicit similar…* [PubMed](https://pubmed.ncbi.nlm.nih.gov/39959841/) · DOI [10.7717/peerj.18904](https://doi.org/10.7717/peerj.18904).

Trainierte Erwachsene, 8 Wochen, Oberkörper; exaktes n hier NR. Ähnliche Anpassungen bei den untersuchten langen Teilwiederholungen und vollständiger ROM. Evidenz niedrig–mittel; konkrete Übungen, Messstellen und kurze Dauer. Kontrast zu pauschalen Schlussfolgerungen älterer ROM-Reviews: „Teilwiederholung“ beschreibt sehr unterschiedliche Trainingsabschnitte. Forma bevorzugt eine kontrollierbare, standardisierte und beschwerdefreie Ausführung, ohne extreme Dehnung zu verlangen.

### E10 · Vollständige ROM

Grgic et al. (2021), systematischer Review/Meta-Analyse. [PubMed](https://pubmed.ncbi.nlm.nih.gov/34170576/).

Erwachseneninterventionen, kleine heterogene Literatur; n und vollständige Dauer hier NR. Vollständige ROM zeigte Vorteile für manche Kraft- und Unterkörperbefunde. Evidenz mittel mit Grenzen bei Muskel, Messort und Definition der Teil-ROM. Gemeinsam mit E08–E09 interpretieren: reduzierte ROM bei kurzen Muskellängen ist nicht dasselbe wie lange Teilwiederholungen. Keine automatische Steigerung der ROM anhand eines Videos.

### E11 · Maschinen und freie Gewichte

Haugen et al. (2023), systematischer Review/Meta-Analyse. [PubMed](https://pubmed.ncbi.nlm.nih.gov/37582807/) · DOI [10.1186/s13102-023-00713-4](https://doi.org/10.1186/s13102-023-00713-4).

Gesunde Erwachsene 18–60 Jahre, Studien ab 6 Wochen; Status gemischt, Gesamt-n hier NR. Kraftanpassungen sind teilweise test- und gerätespezifisch; kein universeller Hypertrophievorteil einer Kategorie. Evidenz mittel. Anwendung: Maschinen, Kabel, Multipresse, Lang- und Kurzhantel auswählbar. Gerätegewichte und Hebelverhältnisse nicht miteinander gleichsetzen; eine neue Gerätevariante als neuer Vergleichskontext.

### E12 · Übungsreihenfolge

Nunes et al. (2021; online 2020), Review/Meta-Analyse. [PubMed](https://pubmed.ncbi.nlm.nih.gov/32077380/) · DOI [10.1080/17461391.2020.1733672](https://doi.org/10.1080/17461391.2020.1733672).

Erwachsene, verschiedene Trainingsniveaus; Gesamt-n und Laufzeitspanne hier NR. Früh trainierte Übungen können bei der spezifischen Kraftentwicklung profitieren; keine klare generelle Hypertrophieüberlegenheit einer Reihenfolge. Evidenz mittel. Anwendung: Prioritäten dürfen die Reihenfolge bestimmen, ein Leistungsabfall nach Umordnung wird nicht direkt als Plateau interpretiert.

### E13 · Aufwärmen

Ribeiro et al. (2021), systematischer Review zum Aufwärmen und Krafttraining. [Originalartikel](https://revistas.rcaap.pt/motricidade/article/view/21143).

Überwiegend akute Leistungstests; Gesamt-n, Statusverteilung und Einzelprotokolldauer hier NR. Befunde abhängig vom Aufwärmprotokoll. Evidenz niedrig–mittel für eine konkrete universelle Satzfolge. Anwendung: Aufwärmsätze separat erfassen, kontrolliert an Bewegung und Belastung herantasten, keine ermüdenden Pflichtprotokolle. Akute Leistung ist kein Nachweis langfristiger Verletzungsverhütung.

### E14 · Autoregulation

Hickmott et al. (2022), systematischer Review/Meta-Analyse. [Volltext](https://pmc.ncbi.nlm.nih.gov/articles/PMC8762534/) · DOI [10.1186/s40798-021-00404-9](https://doi.org/10.1186/s40798-021-00404-9).

15 Studien (6 zur Last-, 9 zur Volumenregulation), unterschiedliche RIR/RPE- und Geschwindigkeitsprotokolle; hauptsächlich Kraftresultate. Gesamt-n und Zeitspanne hier NR. Evidenz mittel für Autoregulation als mögliche Methode, niedrig für unser konkretes Regelwerk. Eine subjektive Tagesformskala ist keine Leistungsdiagnostik. Anpassungen bleiben freiwillig.

### E15 · Deload-Konsens

Bell et al. (2023), Delphi-Studie. [Volltext](https://pmc.ncbi.nlm.nih.gov/articles/PMC10511399/) · DOI [10.1186/s40798-023-00633-0](https://doi.org/10.1186/s40798-023-00633-0).

Drei Befragungsrunden, Runde 2 n=29, Runde 3 n=21 Fachpersonen. Keine Trainingsintervention und kein RCT. Evidenz niedrig für konkrete Effekte. Dokumentiert fachliche Praxis, beweist aber weder einen optimalen Rhythmus noch eine optimale Reduktion. Anwendung: Entlastung bei länger anhaltender Ermüdung erwägen, kein automatischer Deload alle vier Wochen.

### E16 · Deload-Intervention

Coleman et al. (2024), randomisierte Untersuchung. [PubMed](https://pubmed.ncbi.nlm.nih.gov/38274324/).

39 trainierte junge Erwachsene (29 Männer, 10 Frauen), 9 Wochen; eine Woche Trainingsunterbrechung gegenüber durchgehendem Training. Die untersuchte vollständige Unterbrechung ist nicht identisch mit allen gebräuchlichen Deload-Formen. Evidenz niedrig für universelle Empfehlungen. Zusammen mit E15: Konsens zur Praxis ist keine Garantie für bessere Anpassungen. Die App schreibt kein festes Unterbrechungsprotokoll vor.

### E17 · Schlaf und Leistung

Craven et al. (2022), systematischer Review/Meta-Analyse. [Volltext](https://pmc.ncbi.nlm.nih.gov/articles/PMC9584849/) · DOI [10.1007/s40279-022-01706-y](https://doi.org/10.1007/s40279-022-01706-y).

Akuter Schlafverlust, unterschiedliche sportliche Tests und Bedingungen, häufig auf höchstens 6 Stunden beschränkter Schlaf; Gesamt-n hier NR. Evidenz mittel für mögliche Leistungseinbußen, niedrig für die Vorhersage einer einzelnen Einheit. Akute Experimente sind keine Langzeitdiagnostik. Anwendung: Schlaf und Energie als freiwillige Kontextdaten, keine rechnerische Gewichtskorrektur aus einer Nacht.

### E18 · Jugendliche

Lloyd et al. (2014), internationaler Konsens zu Krafttraining im Jugendalter. [PubMed](https://pubmed.ncbi.nlm.nih.gov/24055781/) · DOI [10.1136/bjsports-2013-092952](https://doi.org/10.1136/bjsports-2013-092952).

Fachgesellschafts-/Expertenkonsens, keine einzelne Stichprobe oder Interventionsdauer. Fachkundige Anleitung, angepasste Belastung und Technik stehen im Vordergrund. Evidenzart: Konsens auf Forschungsgrundlage. Anwendung: keine Maximalkrafttests, Wettkampf-Ranglisten oder Verpflichtung zum Überbieten früherer Leistungen. Bei Jugendlichen Erwachsenenstudien nur mit expliziter Übertragungsgrenze verwenden.

### E19 · Krankheit / Wiedereinstieg

Schwellnus et al. (2022), IOC-Konsens zu akuten Atemwegserkrankungen bei Athleten. [PubMed](https://pubmed.ncbi.nlm.nih.gov/35863871/) · DOI [10.1136/bjsports-2022-105759](https://doi.org/10.1136/bjsports-2022-105759).

Konsens, keine einzelne Versuchsstichprobe oder Dauer. Individueller Verlauf ist entscheidend; die App besitzt keine Untersuchung oder Diagnose. Anwendung: Krankheitseingabe blockiert Progression und fordert keine Rückkehr nach einer festen Zahl von Tagen. Die allgemeine Zweiwochenregel bei Trainingsabwesenheit ist eine vorsichtige App-Heuristik, keine medizinische Freigabe.

### E20 · 1RM-Schätzung

Reynolds et al. (2006), *Prediction of one repetition maximum strength from multiple repetition maximum testing and anthropometry*. [Originalarbeit](https://www.unm.edu/~rrobergs/478RMStrengthPrediction.pdf). Ergänzend: [Studie zur Vorhersage mit Wiederholungen und Last-Geschwindigkeit (2020)](https://pubmed.ncbi.nlm.nih.gov/32740290/).

Validierungsstudien mit spezifischen Übungen und Stichproben; diese Recherche übernimmt keine universelle Fehlerquote. Stichprobendetails wurden hier nicht vollständig extrahiert. Forma verwendet die etablierte Epley-Näherung `Last × (1 + Wiederholungen / 30)`, ausschließlich bei geeigneten Übungen mit externer Last und 2–10 abgeschlossenen Wiederholungen. Evidenz mittel für grobe Schätzung, niedrig für individuelle Genauigkeit. Reserve, Technik und Übung verändern den Fehler; kein tatsächliches 1RM und kein Auftrag zum Maximalversuch.

### E21 · Rudern: Griff und Ellenbogenführung

Vasconcelos et al. (2023), *Effect Of Different Grip Position And Shoulder-Abduction Angle On Muscle Strength And Activation During The Seated Cable Row*. [Originalarbeit](https://journal.iusca.org/index.php/Journal/article/view/190) · DOI [10.47206/ijsc.v3i1.190](https://doi.org/10.47206/ijsc.v3i1.190).

- Akuter Vergleich von sieben Bedingungen mit 21 freizeitsportlich trainierten Erwachsenen (11 Männer, 10 Frauen; mittleres Alter 28 bzw. 27 Jahre). Isometrische Kraftmessung und dynamische Oberflächen-EMG; keine mehrwöchige Trainingsintervention.
- Körpernahe Oberarme gingen mit höherer gemessener Latissimusaktivität einher; stärker seitlich geführte Oberarme mit höherer Aktivität von Trapez und hinterem Deltamuskel.
- Niedrige Evidenz für langfristige Trainingsentscheidungen: kleine Stichprobe, akute Aktivierung statt Muskelwachstum, Kabelübung. Griffposition und Oberarmstellung sind keine austauschbaren Variablen. Keine direkte Prüfung der Multipresse.

### E22 · Enges versus breites Rudern

Padovan et al. (online 2025, Ausgabe 2026), *High-Density Surface Electromyography Excitation of Prime Movers in the Narrow vs. Wide Grip Seated Row Exercise*. [Originalarbeit](https://jhk.termedia.pl/High-Density-Surface-Electromyography-Excitation-of-Prime-Movers-in-the-Narrow-vs,209550,0,2.html) · DOI [10.5114/jhk/209550](https://doi.org/10.5114/jhk/209550).

- Akuter Vergleich bei 14 krafttrainingserfahrenen Männern, beide Varianten mit 8-RM-Last; hochauflösendes Oberflächen-EMG in konzentrischer und exzentrischer Phase. Keine langfristige Hypertrophiestudie.
- Enges Rudern zeigte mehr gemessene Latissimusaktivität; breites Rudern mehr Aktivität in den untersuchten Trapezanteilen. Der Befund unterstützt die grobe Fokuseinteilung aus E21, ohne eine isolierte Beanspruchung zu belegen.
- Niedrige Evidenz für langfristige Überlegenheit: kleine, ausschließlich männliche Stichprobe, übungsspezifischer Akutvergleich. Einzelne Schulterbefunde stimmen nicht vollständig mit E21 überein; deshalb keine allgemeine Rangliste für alle beteiligten Muskeln.

## Umsetzung nach Themen

| Thema | Entscheidung in Forma | Grenze / Quelle |
|---|---|---|
| Progressive Overload | Wiederholungen, kontrollierte Ausführung, Reserve und Last berücksichtigen | Eine Steigerung pro Einheit ist nicht erforderlich; E01–E03 |
| Double Progression | Zuerst vergleichbare Leistung über mehrere Einheiten, kleine freiwillige Lastoption | Exakte Schwellen sind Heuristiken; E03/E14 |
| Volumen pro Muskel | Abgeschlossene direkte Sätze zeigen; Warm-up getrennt | Keine exakte Zahl „effektiver Sätze“, kein indirekter Satzfaktor als Naturgesetz; E04 |
| Frequenz / Splits | Wochenplan und letzte Belastung anzeigen | Zeit seit Training ist kein Erholungsnachweis; E04/E07 |
| Kraft / Hypertrophie / Reprange | Zielrange frei wählbar, gleiche Messbedingungen vergleichen | Trainingsziel und Anstrengung modifizieren Ergebnisse; E02/E05 |
| Muskelversagen | Nie nötig, um einen Vorschlag freizuschalten | RIR ist eine subjektive Schätzung; E05 |
| Pausen / Satzabfall | Timer und optional tatsächliche Pause; Supersätze aus Pausenregel ausnehmen | Abschlussabstand enthält Satzdauer und ist keine Pause; E06 |
| Reihenfolge | Sortierung speichern und beim Vergleich berücksichtigen | Priorisierte Übung zuerst ist eine Option; E12 |
| ROM / Teilwiederholungen | ROM-Notiz, Technikvariante und Verlauf trennen | Lange Teilwiederholungen, kurze Teilwiederholungen und vollständige ROM nicht vermengen; E08–E10 |
| Tempo / konzentrisch / exzentrisch | Notieren und möglichst konstant halten; keine Tempo-Vorgabe | Kein universelles 2–0–1-Optimum; E01, E08–E10 |
| Widerstandsprofil / Muskellänge | Gerätespezifische Varianten unterscheiden | 2D-Video liefert weder innere Muskelkraft noch Widerstandsmoment; E08–E11 |
| Maschine / freie Gewichte / Kabel / Multipresse | Gleichwertige Bibliothekskategorien; keine Gewichte geräteübergreifend vergleichen | Spezifität und Unterschiede zwischen Geräten; E11 |
| Isolation / Mehrgelenk | Haupt- und sekundäre Muskeln kennzeichnen | Schematische Zuordnung ist keine individuelle Aktivierungsmessung; E01/E04 |
| Warm-up | Eigener Satztyp, aus PR und Progression ausgeschlossen | Keine Zusage zur Verletzungsprävention; E13 |
| Ermüdung / Deload | Kontext zuerst, optionale Entlastung; keine starre Kalenderpflicht | Begrenzte direkte Evidenz; E15/E16 |
| Plateau / Variation | Vier stabile Vergleichseinheiten sind nur ein Hinweis; Übungswechsel optional | Keine validierte Plateau-Diagnose, kein willkürlicher Wechselautomat; E01/E14 |
| Bereitschaft / Schlaf | Optionaler subjektiver Check-in, konservative Empfehlung | Keine Diagnose oder Prozentberechnung; E17 |
| Schmerz / Krankheit | Keine Progression, schmerzhafte Bewegung beenden, bei starken/anhaltenden Beschwerden abklären | Kein individuelles Rehabilitationsprogramm; E18/E19 |
| Erfahrung / individuelle Historie | Anfänger: mehr Vergleichseinheiten; frühere erfolgreiche Lastschritte begrenzen Vorschlag | Keine lernende kausale Volumenoptimierung; E03/E14 |

## Anatomie und Übungsbibliothek

**Erweiterung 1.3.0:** 275 Übungen mit stabilen Varianten-IDs. Die Muskelzuordnungen sind funktionell-anatomische Orientierung, keine aus EMG abgeleiteten Wachstumsversprechen. Für Sumo ist die veränderte Knie-/Hüftmechanik berücksichtigt; Stiff-Leg und RDL werden anhand der beschriebenen Kniebeugung und Startposition getrennt. Die Bezeichnungen sind in der Praxis nicht einheitlich. Trap Bar und Langhantel erhalten keine Umrechnungsfaktoren.

- **Escamilla et al. (2000)**, 24 männliche Wettkampfheber (12 Sumo, 12 konventionell), akute dreidimensionale biomechanische Analyse: Varianten unterscheiden sich in Positionen und Weg. Keine Trainingsintervention. [DOI 10.1097/00005768-200007000-00013](https://doi.org/10.1097/00005768-200007000-00013).
- **Escamilla et al. (2002)**, 13 männliche College-Footballspieler, akuter EMG-Vergleich von Sumo/konventionellem Kreuzheben mit 12RM-Last: stützt eine unterschiedliche Beteiligung von Kniestreckern. Kleine, spezifische Population; keine direkte Aussage über Muskelwachstum. [DOI 10.1097/00005768-200204000-00019](https://doi.org/10.1097/00005768-200204000-00019).
- **Swinton et al. (2011)**, 19 männliche Powerlifter, akuter Vergleich gerader/hexagonaler Stange bei 10–80 % 1RM: unterschiedliche Gelenkmomente und in dieser Stichprobe höhere Hex-Bar-Maximallast. Keine Überlegenheit hinsichtlich Verletzungsrisiko oder langfristigem Wachstum nachgewiesen. [DOI 10.1519/JSC.0b013e3181e73f87](https://doi.org/10.1519/JSC.0b013e3181e73f87).
- **Camara et al. (2016)**, 20 trainierte Männer, akuter Straight-/Hex-Bar-Vergleich, fand im Gegensatz zu Swinton keinen signifikanten 1RM-Unterschied. Deshalb kein pauschaler Trap-Bar-Bonus oder Konversionsfaktor. [PubMed 26840440](https://pubmed.ncbi.nlm.nih.gov/26840440/).

Evidenzstärke für die hier benötigte **biomechanische Unterscheidung**: begrenzt bis mittel; für langfristige Überlegenheit oder individuelle Sicherheit aus diesen Studien: nicht ableitbar. Weitere Bibliothekseinträge sind nachvollziehbare biomechanische Übertragungen, keine separat untersuchten Interventionen.

Die Muskelgrafiken sind selbst erstellte schematische SVGs. Haupt-/Nebenmuskelzuordnung folgt den Bewegungsfunktionen (z. B. Ellenbogenstreckung/Trizeps, Schulterabduktion/Deltamuskel, Knieextension/Quadrizeps). Grafiken zeigen keine Aktivierungsprozentwerte, keine genaue regionale Fasernutzung und keine Körperbewertung. Griffe, Gelenkstellung, individuelle Anatomie und Maschine beeinflussen die Belastung. Eine externe fachliche Einzelprüfung aller Bibliothekseinträge steht noch aus; Korrekturen müssen versioniert werden.

**Rudervarianten (Bibliothek 1.1.1):** „Eng“ beschreibt hier körpernahe Ellenbogen und einen Zug zum unteren Bauch, „breit“ seitlicher geführte Ellenbogen und einen höheren Zugweg. „Latissimus-Fokus“ beziehungsweise „Fokus oberer Rücken“ sind praktische, bedingte Zuordnungen, keine Isolation. Die Ausführungshinweise nennen deshalb auch Rumpfwinkel, Abstützung und Zugrichtung. E21/E22 unterstützen diese Orientierung für Kabelrudern; die Übertragung auf Multipresse, Langhantel, T-Bar und andere Maschinen ist eine biomechanische Ableitung, kein direkter Wirksamkeitsnachweis. EMG-Unterschiede beweisen keine langfristigen Wachstumsunterschiede.

Neue Varianten besitzen eigene IDs für Historie, PRs und Coaching. Bestehende allgemeine Rudereinträge werden nicht nachträglich einer Griffvariante zugeordnet. Der bereits vorhandene breite Kabelzug-Eintrag behält seine ID `wide-row` und damit seine Historie; sein deutscher Name und die Beschreibung werden präzisiert. Bisherige Leistungsdaten werden nicht umgerechnet. Die primäre Zuordnung bleibt „Oberer Rücken“; sekundär werden auch Latissimus und Trapez ausdrücklich aufgeführt.

## Widersprüche ausdrücklich erhalten

1. **Muskellänge:** Einzelstudien und manche Synthesen sprechen für Vorteile bestimmter Übungen bei längeren Muskellängen; E08 fand bei seinen regionalen Vergleichen überwiegend kleine Unterschiede. Unterschiedliche Kontraste, Messorte und Designs können nebeneinander zutreffende Ergebnisse ergeben. Keine pauschale Überlegenheit jeder gedehnten Position.
2. **Versagen:** Mehr Anstrengung kann bei manchen Zielen und Lasten sinnvoll sein; daraus folgt kein Zusatznutzen jedes Satzes bis zum absoluten Versagen. Ermüdung und Messfehler gehören zur Einordnung.
3. **Volumen:** Durchschnittlich größere Dosis kann Anpassung fördern; ein Individuum mit anderer Gesamtbelastung profitiert nicht zwingend von mehr. Deshalb keine automatische Satzsteigerung.
4. **Deload:** Experten nutzen Entlastung, während spezifische kontrollierte Interventionen nicht jede behauptete Anpassungsverbesserung bestätigen. Praxisplausibilität bleibt von Wirksamkeitsnachweis getrennt.

## Aktualisierungen

`evidence.ts` enthält die sichtbaren Quellen, `coach.ts` die Regeln, `COACHING_RULES.md` deren genaue Bedingungen. Änderungen erfordern erneute Literaturprüfung, Datum/Regelversion, Changelog, relevante Tests und einen sichtbaren Versionshinweis. Historische Workouts behalten `coachVersion`; Empfehlungen werden aus den aktuellen Regeln neu berechnet. Ein vollständiger historischer Empfehlungs-Audit-Trail ist noch nicht implementiert. Es gibt keine heimlichen Online-Regelupdates und keine Behauptung laufender automatischer Recherche.
