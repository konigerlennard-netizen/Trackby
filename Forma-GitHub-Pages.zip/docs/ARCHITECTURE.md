## Ergänzung 1.5.0: freiwillige Cloud-Sicherung

Das bisherige Datenmodell und der IndexedDB-Name bleiben unverändert (Schema 3). `cloud-store.ts` hält ausschließlich Verbindung, Konto-Bindung, Sync-Metadaten und Auth-Tokens in einer getrennten IndexedDB je App-Pfad. Trainings-Backups exportieren diese Daten nicht.

`cloud-model.ts` validiert öffentliche Konfiguration und Cloud-Daten, bildet einen SHA-256-Vergleich ohne lokale Revision, Timer und Exportzeitpunkt und entscheidet zwischen Upload, Download, gleichem Stand und Konflikt. `cloud.ts` verwendet den dynamisch geladenen offiziellen Supabase-Client. `CloudBridge` läuft nur bei persönlichen Daten; Uploads hängen nie an einer lokalen Speichertransaktion. Abgleich im Vordergrund, nach lokalen Commits und Online-Rückkehr; während Eingabefeldern und Modals kein automatischer Download. Bei zwei geänderten Ständen ist eine ausdrückliche Auswahl nötig. Keine automatische Zusammenführung.

`supabase/setup.sql`: zwei RLS-geschützte Tabellen, genau ein Head je Benutzer, atomarer Vergleich einer UUID-Version, zehn ältere Snapshots. `forma_save` läuft mit den Rechten des Benutzers (`SECURITY INVOKER`), nicht mit Adminrechten. Parallele Schreibversuche mit veralteter Version schlagen fehl. Anonyme Requests dürfen keine Daten lesen oder schreiben. Cloud-Übernahmen prüfen die lokale Revision innerhalb derselben IndexedDB-Transaktion; ein aktives Workout blockiert Ersetzung, der bisherige Stand wird als `pre-import` gesichert.

Voraussetzungen, Datenschutz, Provider-Konfiguration und Grenzen: [CLOUD-SYNC.md](CLOUD-SYNC.md). Die früheren Architekturabschnitte beschreiben den weiterhin funktionierenden lokalen Kern; „keine Accounts“ gilt für die Nutzung ohne freiwillige Cloud.

# Architektur und Datenmodell

## Erweiterung 1.3: Bibliothek und optionale Referenzen

`extra-exercises.ts` ergänzt die Basisbibliothek ohne vorhandene IDs zu ersetzen. Muskeln, Equipment, Bewegungsmuster und Messart bleiben typisiert; Suchaliase werden gemeinsam in Auswahl, Bibliothek und Fortschritt genutzt. Varianten haben eigene Datensätze und eigene Trainingshistorien.

`comparison.ts` enthält reine Funktionen für Quellen-/Gruppenauswahl, Satzprüfung, relative Leistung und grobe Perzentilbereiche. `reference-data.json` ist ein versionierter, nachvollziehbar extrahierter Satz aggregierter Tabellenzellen. `Comparison.tsx` wird erst bei Aufruf geladen; das PWA-Precache hält auch diesen Chunk für offline vor. Die Ansicht schreibt keine Vergleichsprofile in IndexedDB und verändert keine Coachingregeln. Datenformat und JSON-Backup bleiben 3. Künftige Referenzquellen brauchen explizite Populations-, Varianten- und Qualitätsregeln; fehlende Zellen werden nicht durch einen globalen Durchschnitt ersetzt.

## Laufzeit

React 19 + TypeScript + Vite. Statische Single-Page-App, Hash-Navigation. Kein App-Backend, keine API-Schlüssel, keine Authentifizierung. Installierte Radix/shadcn-Primitives liefern Dialoge, Selects und Menüs; Lucide Icons; Recharts wird bei Bedarf nachgeladen. Kleine CSS-Animationen statt zusätzlicher Motion-Laufzeit. Native IndexedDB mit expliziten Transaktionen statt einer zusätzlichen Datenbankbibliothek.

Der Standalone-Weg ist `index.html` → `features/forma/main.tsx` → `vite.pwa.config.ts` → `dist/`. Der Export enthält ausschließlich die benötigten React-Komponenten und die Vite-Werkzeuge. Next, Vinext, Sites, Cloudflare-Server und Auth-Endpunkte werden weder beim Bauen noch zur Laufzeit benötigt. `app/globals.css` ist ein Stylesheet; es existieren keine serverseitigen App-Routen.

## Schichten

| Modul | Zuständigkeit |
|---|---|
| types.ts / schema.ts | Domänentypen und Laufzeitvalidierung |
| exercises.ts | versionierte Basisbibliothek, Vorlagen und getrennte Beispieldaten |
| repository.ts | IndexedDB, atomare Änderungen, Import-Rücknahme, JSON-Export |
| planning.ts | individuelle Satzvorgaben, Änderung der Satzanzahl und Übernahme erledigter Arbeitssätze als Plan |
| coach.ts | pure Empfehlung, Verlauf, PRs, Schätzwerte; keine UI und kein Netzwerk |
| progress.ts | Zeitraumgrenzen, Gewichtsmediane, vergleichbare Leistung, Trendheuristiken und Detail-PRs |
| Progress / PeriodPicker | Startübersicht, Fortschrittsansicht, Gewichtseingabe und interaktive Übungsdiagramme |
| evidence.ts | sichtbare Quellen und Einordnungen |
| App / Workout / Plans / History / Exercises / Stats / Settings | Oberflächen und Benutzeraktionen |
| Video / pose.worker / video-math | lokale, optional geladene Videoanalyse und reine Zyklusauswertung |
| scripts/build-pwa.mjs | statischer Build, gehashter Offline-Cache und Service Worker |

## Datenmodell

`AppState` schema=3 enthält:

- `workouts[]`: UUID, Start/Ende, Vorlage, Name, Notiz, optionaler Check-in, Regelversion, geordnete Übungsinstanzen.
- `WorkoutExercise`: stabile Übungs-ID plus Snapshot der Ziel-Sätze/Range/RIR/Pause, Supersatz-Gruppe, Gerätenotiz/Technik, Schmerzflag und Sätze.
- `SetLog`: UUID, kg, Wiederholungen (bei Zeitübungen Sekunden), optional RIR/RPE, Typ, Status/Zeitstempel, optional Startmarkierung, tatsächliche Pause, Tempo-/ROM-/Freitextnotiz.
- `templates[]`: eigene Vorgaben und geordnete Übungen, `updatedAt`. Optionale `setTargets[]` enthalten pro geplantem Satz `weight` in kg und `reps`; `null` bedeutet feldweise Rückgriff auf die vorherige Leistung. Ohne Verlauf gelten 0 kg und das untere Ende der Zielrange. Anzahl und Reihenfolge entsprechen `targetSets`. Beim Start entstehen unabhängige Satzdatensätze; Änderungen überschreiben den Plan nicht.
- `customExercises[]`: deutsche/englische Namen, Equipment, Bewegungsmuster, Haupt-/Nebenmuskeln, Hinweise und Lastmodus.
- `settings`: Einheit, Theme, Erfahrung, Lastschritt in kg, Wochentag→Template-ID, Favoriten und Übungsnotizen.
- `videos[]`: Dateiname, Übungs-ID, Messmethode, Zeitreihe und Zyklen; **keine Originalvideos**.
- `bodyWeights[]`: UUID, kg als interne Einheit, Messzeitpunkt, optionale Notiz. Mehrere Einträge am Tag sind zulässig. Keine Ziele oder Bewertungen des Körpers.
- `timerEnd`: absolute Uhrzeit; `revision`: monoton steigender Speicherstand.

PRs und Coachingdaten werden deterministisch aus den gespeicherten Sätzen abgeleitet. Deshalb keine auseinanderlaufenden separaten PR-Tabellen. Zahlenvorgaben sind Daten, wissenschaftliche Regeln sind Code, Darstellung ist UI.

## Verlässliche Speicherung

IndexedDB `forma-v1:<kodierter App-Pfad>`, Object Store `state`, Schlüssel `main`. Demo separat unter `forma-demo-v1:<kodierter App-Pfad>`. Bei `/forma/` lautet der Pfad `%2Fforma%2F`. Derselbe Pfad unter `index.html` verwendet dieselbe Datenbank. Domains sind durch die Browser-Origin bereits getrennt; mehrere Projekte auf demselben GitHub-Host erhalten zusätzlich getrennte Namen. Ein Umzug von einer älteren oder anderen Adresse erfolgt bewusst per JSON. Fortschrittswerte, PRs und Coachingempfehlungen werden aus den dauerhaft gespeicherten Trainingsdaten berechnet. Jede Änderung liest innerhalb **derselben Readwrite-Transaktion** den aktuellen Stand, klont ihn, wendet die Änderung an, validiert ihn und schreibt atomar. Bestätigung erst nach `transaction.oncomplete`. Gleichzeitige Änderungen unterschiedlicher Tabs überschreiben nicht pauschal einen veralteten UI-Snapshot; BroadcastChannel signalisiert neue Revisionen. Bei konkurrierenden Änderungen desselben Feldes gewinnt die zuletzt ausgeführte Transaktion. Es gibt noch keine Zusammenführung von gleichzeitigen Offline-Änderungen mehrerer Geräte.

Das Snapshot-Modell hält Import/Export atomar und einfach. Es validiert/schreibt derzeit den Gesamtzustand pro Änderung; bei sehr großen Datenbeständen ist eine Migration zu eigenen Stores für Workouts/Sätze erforderlich. 20.000 Workouts ist eine Importgrenze, keine getestete Performancezusage. Kein Benchmark mit jahrelangen Datenbeständen. Bei Speicherfehlern erscheint eine dauerhafte Fehlermeldung; keine Meldung, dass die Änderung gespeichert sei. Bestehende beschädigte Daten werden nicht still ersetzt.

JSON-Import: max. 25 MB, explizites Format/Version, Zod-Prüfung, ID-/Referenz-/Werteprüfung, maximal eine aktive Einheit. Vor dem Ersetzen wird `pre-import` in derselben Transaktion gesichert. Rücknahme tauscht die Stände. Browserdaten können trotzdem durch Nutzer, privates Surfen oder Speicherdruck verloren gehen: regelmäßige externe Backups bleiben nötig.

## Offline und Updates

Build erzeugt eine vollständige Liste der lokalen App-/Chunk-/Icon-/Dokumentdateien und einen Inhaltshash. Service Worker installiert den Cache atomar. Die Cache-Namen enthalten den kodierten App-Pfad; ein Update entfernt ausschließlich ältere Caches dieser App und niemals Datenbanken oder Caches anderer Projektpfade. GETs innerhalb des App-Pfads werden aus Cache bedient, Navigation aus `index.html`. Hash-Routing funktioniert auch auf GitHub Pages ohne Server-Rewrites. Code, Bibliothek, Regeln, Diagramme und Training stehen nach erfolgreichem Online-Erststart offline bereit. Kein Caching privater Serverantworten, da es keinen Trainingsserver gibt.

Neue Versionen warten; die Oberfläche bietet Aktualisierung erst außerhalb einer aktiven Einheit an. Version 1.2 migriert den logischen Datenstand 1 → 2 → 3 beim validierten Lesen und vor jeder Änderung: `bodyWeights: []` wird bei v1 ergänzt; v2 erhält die neue Schemaversion für optionale Satzvorgaben. Vorhandene Workouts und Einstellungen bleiben erhalten. Die physische IndexedDB-Version bleibt 1. Backups in Formatversion 1, 2 und 3 sind lesbar; neue Exporte verwenden 3. Alte App-Tabs können den neuen Stand wegen ihrer Schema-Prüfung nicht überschreiben und sollten geschlossen werden. Künftige Schemaänderungen brauchen ebenso explizite Migrationen. Der Cache enthält keine Modelldateien von Drittanbietern; automatische Videoanalyse braucht derzeit eine Verbindung. Timer prüft tatsächliche Uhrzeit beim Wiederöffnen, wird aber im iOS-Hintergrund nicht zuverlässig akustisch ausgelöst.

## Video

MediaPipe Tasks Vision 0.10.21, versionierte JS-/WASM-URL; Pose Landmarker Lite float16 Modell. Erst bewusste Analyseaktion lädt Dateien von jsDelivr/Google. CPU-Inferenz im Worker, Sampling etwa 5 Bilder/s, längste Bildbreite 640 px, Begrenzung auf 120 s / 150 MB. Gelenkwinkel aus Pixelkoordinaten (Bildseitenverhältnis berücksichtigt), Mindest-Sichtbarkeit, mindestens 65 % auswertbare Frames. Medianfilter, Hysterese und Lückenprüfung zählen klare Zyklen. Schwellen sind technische Heuristiken, nicht klinisch validiert. Keine 3D-Kinematik, Gelenkmomente, Symmetriediagnose oder Verletzungserkennung. Manuelle Markierung funktioniert ohne Modell.

Die Ursprungsdatei wird nur über eine lokale Object-URL gelesen. Sie wird nicht hochgeladen und nicht dauerhaft kopiert. Ergebnisse und Vergleichswerte bleiben lokal. Die tatsächliche Modellqualität muss mit repräsentativen realen Videos pro Zielgerät weiter geprüft werden.

## Spätere Cloud-Synchronisation

Keine Kontenattrappen in v1. Ausbau in getrennten Schritten:

1. Schema migrieren: Entitäten mit `updatedAt`, Tombstones und Geräte-/Änderungs-ID; eigene Stores + Outbox.
2. Repository-Interface um Sync-Adapter ergänzen; lokale Eingabe bleibt sofort verfügbar.
3. Konflikte auf Feldebene und importierte IDs behandeln, Versionen nicht blind überschreiben.
4. Authentifizierung (Apple/Google) isoliert hinzufügen; Serverzugriff immer nutzergebunden.
5. Optionale clientseitige Verschlüsselung, Key-Recovery und Backup-Restore gemeinsam entwerfen. Keine erfundene Verschlüsselungszusage.
6. Upload von Video nur mit eigenständiger bewusster Einwilligung; lokale Verarbeitung bleibt Standard.

## Bekannte Produktgrenzen

Kein validiertes personalisiertes Dosis-/Erholungsmodell. Kein automatisches Lesen medizinischer Bedeutung aus Notizen. Fortschritte können durch andere Geräte/Technik verfälscht werden. Die anatomischen Schemata ersetzen keine fachliche Prüfung. Native iOS-Installation, Speicherdruck, Screenreader und reale Videoerkennung müssen zusätzlich auf Hardware getestet werden; siehe TESTING.md.
