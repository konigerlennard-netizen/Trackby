# Pausentimer einmal speichern · 4REPS 1.16.0

1. Im laufenden Workout auf **Pause: 3:00** tippen. Alternativ: **Mehr → So trainierst du → Timer einstellen**.
2. **3:00** wählen oder Minuten und Sekunden selbst eingeben. Drei Minuten sind vorausgewählt.
3. **Nach jedem Satz automatisch starten** einschalten. Optional **Bildschirm während der Pause anlassen** aktivieren.
4. **Timer speichern** drücken. Dauer, Automatik und Display-Option werden gemeinsam gespeichert.

Danach reicht der Haken an deinem Satz. Der Timer startet jedes Mal mit deiner gespeicherten Dauer – bei allen Übungen und beim nächsten Training. Auch nach dem Schließen und erneuten Öffnen der App bleibt die Einstellung erhalten. Ein bereits laufender Countdown wird beim Speichern nicht zurückgesetzt.

Am laufenden Timer öffnet das Einstellungs-Symbol denselben Dialog. **+30s** verlängert nur die aktuelle Pause. Wenn du eine neue Dauer für alle nächsten Sätze möchtest, verwende **Timer speichern**.

Nach dem Abhaken kannst du mit **Rückgängig** den Satz wieder öffnen. Seine übrigen Eingaben bleiben erhalten. Die zugehörige unveränderte Pause wird beendet; eine bereits verlängerte oder neu gestartete andere Pause bleibt erhalten. Auch das Wiederöffnen eines älteren Satzes löscht nicht mehr die Pause eines späteren Satzes. **Nächster offener Satz** bringt dich zur nächsten noch offenen Eingabe in deiner Übungsreihenfolge.

**Gemessene Pause** in den Satzdetails ist eine optionale Angabe über deine tatsächliche Pause. Sie ist nicht die Timer-Einstellung und muss nicht für jeden Satz ausgefüllt werden. Alte gemessene Pausen bleiben erhalten.

Wenn die Pause im Hintergrund abläuft, zeigt die App den Ablaufhinweis beim Zurückkehren an. **Bei gesperrtem Bildschirm gibt es keinen zuverlässigen Alarm.** Die Display-Option hält nur während einer laufenden Pause und bei sichtbarer App den Bildschirm an, wenn das Gerät dies erlaubt. Sie entsperrt kein Handy. Energiesparmodus oder fehlende Browserunterstützung können die Anfrage verhindern; der Status steht am Timer. Bei Ende, Ausblenden der App oder Abschalten der Option gibt die App ihre Anforderung frei. Die Einstellung kann mehr Akku verbrauchen.

Gespeicherte Dauer und Display-Option sind in JSON-Backups enthalten. Beim Import eines älteren Backups ohne Timer-Einstellung gilt wieder der Standard von drei Minuten; ohne Display-Einstellung bleibt diese aus. Über **Letzten Import rückgängig machen** lässt sich der vorherige Stand einschließlich deiner Timer-Einstellungen wiederherstellen.

Für das Update die passende iPhone- oder Android-Ausgabe unter dem bisherigen Dateinamen **Forma-GitHub-Pages.zip** bei GitHub ersetzen. Namenszusätze vor dem Hochladen entfernen. Nach dem erfolgreichen Lauf in der App nach Updates suchen; die Versionsanzeige muss **1.16.0** lauten. Unter derselben Website-Adresse bleiben deine Trainingsdaten erhalten. Website-Daten nicht löschen.
