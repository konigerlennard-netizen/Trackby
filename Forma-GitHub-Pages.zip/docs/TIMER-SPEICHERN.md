# Pausentimer einmal speichern · 4REPS 1.14.0

1. Im laufenden Workout auf **Pause: 3:00** tippen. Alternativ: **Mehr → So trainierst du → Timer einstellen**.
2. **3:00** wählen oder Minuten und Sekunden selbst eingeben. Drei Minuten sind vorausgewählt.
3. **Nach jedem Satz automatisch starten** einschalten und **Timer speichern** drücken.

Danach reicht der Haken an deinem Satz. Der Timer startet jedes Mal mit deiner gespeicherten Dauer – bei allen Übungen und beim nächsten Training. Auch nach dem Schließen und erneuten Öffnen der App bleibt die Einstellung erhalten. Ein bereits laufender Countdown wird beim Speichern nicht zurückgesetzt.

Am laufenden Timer öffnet das Einstellungs-Symbol denselben Dialog. **+30s** verlängert nur die aktuelle Pause. Wenn du eine neue Dauer für alle nächsten Sätze möchtest, verwende **Timer speichern**.

**Gemessene Pause** in den Satzdetails ist eine optionale Angabe über deine tatsächliche Pause. Sie ist nicht die Timer-Einstellung und muss nicht für jeden Satz ausgefüllt werden. Alte gemessene Pausen bleiben erhalten.

Wenn die Pause im Hintergrund abläuft, zeigt die App den Ablaufhinweis beim Zurückkehren an. Das ist keine Systembenachrichtigung bei gesperrtem Bildschirm.

Die gespeicherte Dauer ist in JSON-Backups enthalten. Beim Import eines älteren Backups ohne Timer-Einstellung gilt wieder der Standard von drei Minuten. Über **Letzten Import rückgängig machen** lässt sich der vorherige Stand einschließlich deiner Timerdauer wiederherstellen.

Für das Update die passende iPhone- oder Android-Ausgabe unter dem bisherigen Dateinamen **Forma-GitHub-Pages.zip** bei GitHub ersetzen. Namenszusätze vor dem Hochladen entfernen. Nach dem erfolgreichen Lauf in der App nach Updates suchen; die Versionsanzeige muss **1.14.0** lauten.
