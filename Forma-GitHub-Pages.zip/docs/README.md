> Version 1.8.5: Das bereitgestellte gläserne 4R-Motiv ist jetzt das App-Icon für iPhone und Android sowie das Browser-Symbol. Die Funktionen und die korrigierte Satzübersicht aus 1.8.4 bleiben erhalten.

# 4REPS · Workout & Coach · Standalone 1.8.5

Eine deutschsprachige, local-first Workout-PWA für iPhone, Android und Desktop. Schnelle Satzeingabe, vorherige Leistungen, eigene Trainingspläne und nachvollziehbare Coachingregeln. Ohne Account, Werbung oder Tracking. Kein Körpervergleich und keine Kalorienziele.

**Fertige Website veröffentlichen:** [START-HIER.md](START-HIER.md). Kein ChatGPT-Sites-Account, API-Schlüssel oder Backend erforderlich. Der Produktionsordner enthält alle App-Dateien; nur die optionale automatische Videoanalyse lädt ihr Modell bei Bedarf online.

**Trackby ist bereits online?** Für den vorhandenen ZIP-Workflow genügt der Austausch einer Datei: [UPDATE-IPHONE.md](UPDATE-IPHONE.md). Kein neues Repository und kein zweites Paket erforderlich.

## App-Icon ab 1.8.5

Das bereitgestellte Originalmotiv wird ohne Neuzeichnung auf weißem Hintergrund verwendet. iPhone: Apple-Touch-Icon mit 180 × 180 px. PWA: 192-/512-px-Icons und eine gepolsterte 512-px-Ausgabe für maskierbare Android-Symbole. Browser: 32-/64-px-PNG. Neue Dateipfade vermeiden die Wiederverwendung derselben Icon-URL; ein bereits installiertes Symbol wird trotzdem durch das Betriebssystem verwaltet. Keine Zusage einer sofortigen Aktualisierung bestehender Verknüpfungen.

Das unveränderte Original liegt im Quellcode unter `assets/branding/4reps-glass-original.jpeg`. `python3 scripts/generate-icons.py` erzeugt mit Inkscape die benötigten Dateigrößen und Kompatibilitätsdateien. Name, Manifest-ID, App-Adresse und Datenspeicher bleiben unverändert. Das JPEG hat einen weißen Hintergrund; der Glaseindruck gehört zum Bild und ist keine dynamische Transparenz zum Hintergrund des Handys.

## Oberfläche

Die Abbildungen zeigen das frühere Forma-Grundlayout von 1.6.0. Die neue 4REPS-Startseite, Farboptionen, Fotohintergründe und die große Gewichtsansicht sind darin noch nicht zu sehen; neue Gerätescreenshots liegen noch nicht vor.

![Forma 1.6.0 – Kalender und Trainingspläne auf dem iPhone](docs/today-mobile.png)
![Forma 1.6.0 – Desktop-Übersicht](docs/today-desktop.png)
![Forma 1.6.0 – gezielte Übungssuche](docs/exercise-search.png)

Screenshots zeigen die tatsächliche Oberfläche; ggf. sichtbare Beispieltrainings sind ausdrücklich Demo-Daten.

## Oberfläche ab 1.8.3

- **Beide Ausgaben:** Zeitraumlabels bleiben auf einer Zeile; Tag und eigener Zeitraum haben begrenzte Datumsfelder mit nativer Datumsauswahl. Auf Touch-Handys mit höchstens 600 px Bildschirmhöhe steht im Querformat dieselbe Fünf-Tab-Navigation rechts untereinander statt der Desktop-Seitenleiste. Klare Übungszeilen mit Gerät, letztem Leistungssatz und farbiger kg-/Wiederholungsdifferenz samt Prozentwert. Die Berechnungsbasis bleibt sichtbar; es werden keine neuen Leistungswerte erfunden.
- **Android:** eigene Material-orientierte Auswahlfenster, große auswählbare Zeilen, Suche bei langen Listen, flächige Buttons, Navigation mit aktivem Symbolhintergrund. Auswahl/Abbrechen, Browser-Zurück und Fokus-Rückgabe verwenden dieselben Komponenten wie der Rest der App. Keine externen Schriften.
- **iPhone:** vorhandene Glasnavigation und bisherige native Auswahl in Trainingsformularen bleiben; auch die Zeitraumsteuerung verwendet wieder die native iOS-Auswahl.
- **Start-/Updateabsicherung:** ein Ladebildschirm ist bereits ohne App-JavaScript sichtbar; bei Startfehlern oder längerer Ladezeit erscheint ein Reparaturlink. `repair.html` läuft unabhängig vom App-Bundle und erneuert auf Wunsch nur Service Worker und App-Caches des aktuellen Pfads. IndexedDB und Hintergrundbilder werden nicht angefasst. Ein noch nicht aktiviertes Update lädt die Seite nicht blind neu.
- Beide Ausgaben verwenden dieselben bisherigen Datenbanknamen. Auf derselben Adresse bleiben bestehende Daten lesbar; auf einem anderen Gerät oder einer anderen Adresse sind sie nicht automatisch vorhanden. JSON-Backup oder bereits eingerichtete Cloud-Verbindung verwenden.

### Zwei Produktionsausgaben bauen

```sh
npm ci
npm run typecheck
npm test
node scripts/test.mjs --android
npm run build
npm run test:pwa
npm run build:android
npm run test:pwa:android
python3 scripts/package-release.py
```

`dist/` enthält die iPhone-Ausgabe, `dist-android/` die Android-Ausgabe. Jede ist selbstständig auf GitHub Pages nutzbar. Pro Website-Adresse nur **eine** Ausgabe veröffentlichen; die beiden ZIPs nicht zusammen hochladen. Für getrennte Websites beide jeweils in einem eigenen Veröffentlichungsordner/Repository bereitstellen. Mehr unter [PLATTFORMEN.md](PLATTFORMEN.md).

## Neu in 1.7.2

Unter **Mehr → Dein Look → Farben & Hintergrund** öffnet **Eigenes Bild** direkt die Fotoauswahl, auch zum Austauschen eines vorhandenen Bildes. Der doppelte Button darunter entfällt. Abbrechen oder ein nicht lesbares Foto verändert den bisherigen Hintergrund nicht. Während der Verarbeitung erscheint eine kurze Statusmeldung; Entfernen und die übrigen Hintergrundoptionen bleiben erhalten. Keine Änderung an Datenbanken, Datenformaten oder Training.

## Neu in 1.7.1

- Kopfzeile und Seitenleiste zeigen den Namen 4REPS in einer durchgehenden Textzeile; das getrennte 4-Symbol mit zusätzlichem Abstand entfällt.
- Eigenes überarbeitetes Icon mit vollständigem Schriftzug für den iPhone-Home-Bildschirm, das PWA-Manifest und Browser-Lesezeichen. Apple-Touch-Icon in 180 × 180 px; zusätzlich 192-/512-px- und Maskable-Icons sowie SVG-/PNG-Favicon. Neue Dateipfade unterscheiden das überarbeitete Icon von bisherigen Dateien.
- Keine Änderungen an Trainingsfunktionen, Speichernamen, Datenformat, App-Adresse oder Manifest-ID. Der bereitgestellte ZIP-Dateiname bleibt für deinen GitHub-Workflow gleich.
- Eine bereits installierte iPhone-Verknüpfung kann noch das alte Icon zeigen. Die tatsächliche Icon-Aktualisierung auf iOS wurde hier nicht getestet; bitte keine App-/Website-Daten dafür löschen.

## Neu in 1.7.0

- Fortschritt steht als kompaktes Widget ganz oben auf Heute. Der doppelte Knopf in der Kopfzeile entfällt. Auf dem iPhone folgt der kleinere Kalender darunter, auf breiten Bildschirmen daneben; die Trainingspläne bleiben anschließend erreichbar.
- Körpergewicht und Diagramm öffnen weiterhin die große Detailansicht. Die vollständige Kraftübersicht zeigt zunächst fünf Übungen, eigene schematische Gerätesymbole und jeweils fünf weitere auf Wunsch. Suche, Filter und Sortierung berücksichtigen weiterhin die ganze Liste.
- Unter **Mehr → Dein Look → Farben & Hintergrund** zwischen Ohne, YOU VS YOU und Eigenes Bild wählen. Ein Foto aus der Galerie wird lokal verkleinert und separat in IndexedDB gespeichert; kein Upload. Es bleibt auf diesem Gerät auch nach erneutem Öffnen verfügbar.
- **Das Hintergrundfoto ist nicht im JSON-Backup und nicht in der Cloud enthalten.** Auf einem anderen Gerät bitte erneut auswählen. Die Hintergrundwahl selbst ist eine gesicherte Einstellung. Das Originalfoto wird nicht verändert. JPEG/PNG/WebP; HEIC/HEIF nur, wenn der Browser es dekodieren kann.
- Neuer Name und eigene 4REPS-Icons. App-Adresse, Manifest-ID und bisherige Trainingsdatenbank bleiben gleich. Die Lieferdatei heißt für den bestehenden GitHub-Workflow weiterhin `Forma-GitHub-Pages.zip`.
- TypeScript und 123 Tests für bestehende Funktionen, neue Ansicht und getrennten Bildspeicher; zusätzlicher Produktionsbuild und PWA-Artefaktcheck. Kein neuer echter Browser- oder iPhone-Test in dieser Umgebung (siehe TESTING.md).

## Neu in 1.6.3

- Gewichtsänderungen als Wertepaar: kg als Hauptwert, Prozent kleiner darunter. Plus standardmäßig grün, Minus sanft rot; beide Farben frei anpassbar. Null bleibt neutral.
- Körpergewicht: erster und letzter Eintrag im gewählten Zeitraum; Einzelmessungen erzeugen keine Prozentänderung. Wert und Diagramm öffnen die große Detailseite.
- Übungen: kg- und Prozentdifferenz beschreiben dieselben geglätteten e1RM-Vergleichswerte. Beschriftung „geschätztes 1RM“ auch auf der Startseite; Wiederholungsvergleiche bleiben in Wdh. statt erfundenen kg.
- Wechsel zu lb ändert nur die Anzeigeeinheit, nicht den Prozentsatz. Keine neuen Abhängigkeiten, keine Speicher- oder Schemaänderung.
- Typprüfung, 113 Tests sowie Produktions-/PWA-Prüfung; kein neuer echter Browser- oder iPhone-Test in dieser Umgebung (siehe TESTING.md).

## Neu in 1.6.2

- Körpergewichtswert oder Diagramm auf Heute/Mein Fortschritt antippen: eigene Detailseite mit großem Diagramm, Zeitraumwahl, erster/letzter Messung, Messwertdifferenz und direkt sichtbaren Einträgen einschließlich Notizen und Bearbeiten.
- Einzelne Messpunkte lassen sich auswählen. Leere Zeiträume und einzelne Werte erzeugen weiterhin keinen erfundenen Trend. Die Liste zeigt zunächst 20 Einträge; weitere sind nachladbar.
- Plus-Werte standardmäßig grün, Minus-Werte rot; auch Prozentwerte der einzelnen Übungen. Unter Mehr → Dein Look → Farben & Hintergrund → Farben für Plus & Minus unabhängig anpassbar. Beim Körpergewicht zeigen die Farben nur die Zahlenrichtung.
- Mehr enthält weiterhin Look, Trainingseinstellungen, JSON-Sicherungen, optionale Cloud und Updateprüfung. Demo-Einstieg und Installationsblock entfallen. Datenoptionen sind eingeklappt, Datenschutz und Coach-Quellen unter Über Forma erreichbar.
- Datenbank und Backupversion bleiben gleich; neue Farbwerte sind optionale Felder. Alte Backups und gespeicherte Einstellungen bleiben lesbar. Kein erneuter Import bei einem Update auf derselben App-Adresse.

## Neu in 1.6.0

- Startseite mit antippbarem Wochenkalender, optionaler Monatsansicht, geplanten Einheiten und direktem Trainingsstart. Tageswahl speichert keine falschen Workout-Daten: neu gestartete Trainings beginnen immer heute.
- Eigene Pläne stehen direkt darunter. Fortschritt ist über einen direkten Knopf oben und weiterhin als kompakte Übersicht erreichbar.
- Keine automatischen Rückblicke auf letzte Workouts/Übungen, keine Studienboxen auf der Startseite und kein externer Leistungsvergleich.
- Bibliothek und Übungsauswahl zeigen zunächst fünf Treffer; „Alle … Übungen anzeigen“ öffnet den Rest. Suche und Filter berücksichtigen immer die gesamte Bibliothek.
- Coach-Erklärungen bleiben kurz und nachvollziehbar. Quellen und Regeln sind inzwischen unter „Mehr → Über Forma → Über Forma & den Coach“ erreichbar.
- Keine automatische Internetrecherche; geprüfte Erkenntnisse gelangen über dokumentierte Updates in den Coach. Siehe [EVIDENCE.md](EVIDENCE.md).

## Neu in 1.5.1

Die feste Navigation wurde während der alten Seitenüberblendung zeitweise vom Seiteninhalt verdeckt. Der Übergang animiert jetzt ausschließlich den Inhalt. Navigation und Timer bleiben darüber; der bewegliche Glasregler und die übrigen Animationen bleiben erhalten. Keine Datenmigration und kein erneuter Import beim Update auf derselben Adresse nötig.

## Neu in 1.4.1

Sanftere Seitenwechsel, zusammenhängende Schließanimationen und ein ruhigerer Glasregler. „Mein Fortschritt“ gehört jetzt eindeutig zu „Heute“: kompakte Übersicht auf der Startseite, vollständige Auswertung über „Alle Fortschritte anzeigen“. Der doppelte Eintrag unter „Mehr“ entfällt. Datenformat und Speicherung bleiben gleich.

Die Versionsnummer steht direkt oben unter „Mehr“. Für Trackby genügt weiterhin die vollständige `Forma-GitHub-Pages.zip`; nicht entpacken und kein neues Repository anlegen.

## Neu in 1.4

Einheitliche dunkle Flächen, zurückhaltendes Glasmaterial, eine direkt ziehbare Auswahl in der unteren Navigation und nach unten schließbare Sheets. Große Eingabefelder und die kompakte Satzansicht bleiben auch bei 320 Pixel Breite erreichbar. Reduzierte Bewegung und helle Darstellung werden berücksichtigt.

Behoben wurden verlorene schnelle Gewicht-/Wiederholungsschritte, ungeschützte Planentwürfe, widersprüchliche historische RIR/RPE-Einträge und offene Dialoge nach „Zurück“. Countdown und Trainingsdauer aktualisieren nur noch ihre eigenen Komponenten. **Mehr → Nach App-Update suchen** ergänzt die automatische Prüfung bei Rückkehr zur App.

Speicherformat, Übungs-IDs und Coachingregeln sind unverändert. Der Versionswechsel 1.3.2 → 1.4.0 wurde mit erhaltenen Trainingsdaten geprüft. [Ausgangsprüfung](AUDIT.md), [Designsystem](DESIGN.md) und [abschließende Tests](TESTING.md) dokumentieren Änderungen und Grenzen. Ein Test auf einem physischen iPhone bleibt offen.

## Funktionen

- Freie Workouts und editierbare Templates; Wochenplan, Sortierung und Supersatz-Gruppen.
- Eigenes Gewicht und eigene Wiederholungen für jeden Satz, auch schon im Trainingsplan. Leere Planfelder übernehmen beim Start die letzte Leistung; feste Vorgaben haben Vorrang. Satzdetails im Workout öffnen zusätzliche große Eingabefelder.
- 300 Basisübungen mit deutschem/englischem Namen, Muskeln, Equipment, Bewegungsmuster, Suche, Filtern, Favoriten und eigenen Übungen. Unter anderem konventionelles, Sumo-, rumänisches, Stiff-Leg- und Trap-Bar-Kreuzheben, 19 getrennte eGym-Einträge, Reverse Preacher Curls und Überkopf-Trizepsstrecken. Enges/breites Rudern erhält je Gerät getrennte Leistungsverläufe. [Gerätevarianten und Grenzen](EXERCISE_CATALOG.md).
- Vorherige Sätze direkt sichtbar; kg/lb, Schnellschritte, Wiederholungen, optional RIR/RPE, Satztypen, Notizen, Tempo und ROM.
- Lokale Speicherung nach Änderungen, Wiederaufnahme aktiver Trainings, Pausentimer mit gespeicherter Endzeit.
- Historie öffnen, wiederholen, korrigieren oder als Vorlage speichern.
- Interaktive Diagramme, direkte Sätze pro Muskel, Häufigkeit, Dauer, Lastvolumen, vorsichtige 1RM-Schätzung und persönliche Bestwerte.
- „Mein Fortschritt“ direkt oben auf der Startseite: freiwillige Gewichtserfassung mit interaktivem Diagramm und kompakte Leistungsübersicht.
- Vollständige Fortschrittsansicht mit Zeitraumwahl (1 Tag bis Gesamt, auch eigene Grenzen), Suche, Favoriten, Sortierung und Filtern nach Muskel, Gerät und Plan.
- Übungsdetails mit antippbaren Trainingspunkten, wählbaren Kennzahlen, Historie und PRs. Prozentwerte beruhen auf vergleichbaren Arbeitssätzen, keine erfundene Präzision bei fehlenden Daten.
- Coach mit transparenten Regeln, Gründen, Quellen und Datengrundlage; erkennt mögliche Stagnation und berücksichtigt Beschwerden/Tagesform.
- Eigene schematische Muskelgrafiken; Dark/Light Mode und reduzierte Bewegung.
- JSON-Backup mit validiertem Import und Rücknahme des letzten Imports.
- PWA-Manifest, Icons, Service Worker, Offline-App-Shell und lokale Regeln.
- Experimentelle lokale Videoanalyse und manuelle Wiederholungsmarkierung. Details und Grenzen weiter unten.

## Sofort auf dem iPhone verwenden

1. Den bereitgestellten öffentlichen HTTPS-Link in **Safari** öffnen.
2. **Teilen → Zum Home-Bildschirm → Hinzufügen** auswählen.
3. 4REPS über das neue Icon starten, zunächst mit Internet.
4. Unter **Mehr** warten, bis „Offline-Dateien sind für diese Version bereit“ erscheint.
5. Eigenen Plan erstellen oder Beispielplan anpassen und trainieren.
6. Unter **Mehr → JSON exportieren** regelmäßig eine Datei in „Dateien“ sichern.

Möglichst vor dem ersten echten Training installieren: Safari und die Home-Bildschirm-App können unterschiedliche Datenspeicher verwenden. Bei einem Wechsel aus Safari erst exportieren, dann in der installierten App importieren. Ein Wechsel der Domain erzeugt ebenfalls einen neuen lokalen Speicher. Private Browserfenster sind kein zuverlässiger dauerhafter Speicherort.

## Entwicklung

Voraussetzung: Node.js 24 LTS (mindestens 22.13) und npm. Ein reproduzierbarer `package-lock.json` liegt bei.

```sh
npm ci
npm run dev
```

```sh
npm run verify
npm run preview
```

`verify` prüft TypeScript, Daten-/Coaching-/Speichertests, den Produktionsbuild und die PWA-Dateien. `build` erzeugt **dist/** mit der vollständigen statischen Website. Die Quellcode-`index.html` ist der Vite-Einstieg, nicht die fertige Website. Nicht per `file://` öffnen.

Optionaler Browsertest:

```sh
npx playwright install chromium webkit
npm run test:browser
npm run test:refinement
npm run test:motion
FORMA_ENGINE=webkit npm run test:refinement
npm run test:update
```

## GitHub Pages

**Ohne eigenen Build:** `Forma-GitHub-Pages.zip` entpacken, den gesamten Inhalt direkt in das Hauptverzeichnis eines öffentlichen GitHub-Repositorys laden. Unter **Settings → Pages → Source → Deploy from a branch → main → / (root)** veröffentlichen. `assets/`, Icons, Manifest und `sw.js` mit hochladen. Anleitung: [START-HIER.md](START-HIER.md).

**Mit Quellcode:** Inhalt von `Forma-Quellcode.zip`, einschließlich `.github/workflows/pages.yml`, ins Repository übernehmen. **Settings → Pages → Source → GitHub Actions** auswählen. Der mitgelieferte Workflow installiert per `npm ci`, führt `npm run verify` aus und veröffentlicht ausschließlich `dist/`. Er läuft bei Änderungen auf `main` oder manuell unter Actions.

Die App verwendet relative Assetpfade und Hash-Navigation: auch `https://BENUTZER.github.io/forma/` funktioniert ohne Server-Rewrites. IndexedDB- und Cache-Namen sind zusätzlich nach App-Verzeichnis getrennt. Keine Sites-Server, Auth-Dienste, Datenbankdienste oder geheimen Umgebungsvariablen notwendig. Andere statische HTTPS-Hosts können denselben `dist/`-Ordner ausliefern.

Unter **Settings → Pages** steht nach dem erfolgreichen Deployment die öffentliche HTTPS-Adresse. Auf dem iPhone in Safari öffnen und über **Teilen → Zum Home-Bildschirm** installieren. Die Veröffentlichung bei GitHub erfolgt durch dich; dieser Export legt kein Repository in deinem Konto an.

Vor dem Umzug unter der bisherigen Forma-Adresse **JSON exportieren**. In der neuen installierten App **JSON importieren**. Trainingsdaten liegen auf deinem Gerät und sind nicht Bestandteil dieser Quellcode-/Website-Archive. Backups nicht ins öffentliche Repository laden.

## Datenschutz und Datensicherung

Freiwillige Körpergewichtseinträge bleiben ebenfalls lokal und sind im JSON-Backup enthalten. Version 1.7.0 liest vorhandene Daten und Backups der Formate 1–3; Workouts werden dabei nicht verändert. Neue Backups verwenden Formatversion 3 und enthalten individuelle Satzvorgaben. Vor einem Update eine Sicherung anlegen, anschließend alte App-Tabs schließen und die angebotene Aktualisierung übernehmen. Bei gleicher Adresse und derselben Installation ist kein erneuter Import nötig.

Trainingsdaten, Check-ins, persönliche Notizen, Pläne und Analysewerte liegen standardmäßig in IndexedDB auf dem Gerät. Keine Analyse-/Werbe-SDKs und keine Datenübertragung an einen Trainingsserver. Der Hostinganbieter erhält technisch übliche Abruf-/Verbindungsinformationen beim Laden der App. Externe wissenschaftliche Links öffnen nur nach Anklicken.

Videos werden als lokale Datei gelesen und nicht hochgeladen. Erst „Modell laden & analysieren“ ruft JS-/WASM-Dateien bei jsDelivr und ein Pose-Modell bei Google ab; diese Anbieter erhalten übliche Verbindungsdaten, aber keine Videobilder. Die Originalaufnahme bleibt außerhalb der Datenbank in deinen Fotos/Dateien. JSON enthält Analyse-Metadaten, keine Videos.

Browserdaten können bei Gerätewechsel, Löschen von Website-Daten oder Speicherdruck verloren gehen. Die App kann dauerhafte Speicherung anfragen, aber nicht garantieren. JSON-Backups sind nicht verschlüsselt und können private Notizen enthalten: bewusst sichern und teilen. Import ersetzt nach Vorschau und Bestätigung den aktuellen Stand; der vorherige Stand bleibt für „Letzten Import rückgängig machen“ erhalten. Kein Cloud-Backup in v1.

## Offline und Timer

Nach erfolgreichem Cacheaufbau funktionieren Tracking, Übungen, Vorlagen, Historie, Statistiken und lokale Coachingregeln ohne Netzwerk. Erster Start und neue App-Version brauchen Internet. Video-Modelldateien sind nicht Teil des Offline-Caches. Eine wartende App-Aktualisierung wird außerhalb eines aktiven Workouts angeboten.

Der Timer läuft anhand der Uhrzeit weiter. iOS kann Webseiten im Hintergrund anhalten: **kein verlässlicher Ton, keine garantierte Vibration und keine Push-Erinnerung bei gesperrtem Bildschirm**. Eine tatsächliche Satzpause wird nur bei markiertem Satzstart oder manueller Eingabe gespeichert; die Zeit zwischen zwei Satzabschlüssen wäre ungenau.

## Videoanalyse: experimentell

MediaPipe Pose Landmarker Lite, Verarbeitung im lokalen Worker, keine Serveranalyse. Geeignete seitliche Aufnahmen können grobe vollständige Bewegungszyklen, 2D-Amplitude und Zyklusdauer liefern; Gelenkpunkte und Zeitreihe werden gezeigt. Vergleiche sind nur bei ähnlicher Kamera, Bewegung und Seite sinnvoll. Automatische Auswertung höchstens 2 Minuten/150 MB, etwa 5 Bilder/s.

Keine zuverlässige Symmetrieanalyse, biomechanische Diagnose, Gelenkbelastungsberechnung oder Verletzungserkennung. Sichtbarkeits-/Bewegungsgrenzen lehnen ungeeignete Aufnahmen ab. Wiederholungen selbst am Video überprüfen. Posequalität auf echten iPhones und repräsentativen Trainingsvideos ist noch nicht validiert. Manueller Zähler ist die Alternative, wenn Modell, Format oder Browser nicht funktionieren.

## Wissenschaft und technische Dokumentation

- [EVIDENCE.md](EVIDENCE.md): gezielte Recherche, Primärquellen, Studiendaten, Widersprüche und Übertragungsgrenzen.
- [COACHING_RULES.md](COACHING_RULES.md): alle Regeln, Reihenfolge und konkrete Heuristiken.
- [PROGRESS_METHOD.md](PROGRESS_METHOD.md): Leistungskennzahlen, Vergleichbarkeit, Körpergewichtsverlauf, Trendregeln und Grenzen.
- [PRODUCT.md](PRODUCT.md): Prioritäten, Konkurrenzanalyse, Bedienflüsse, Designentscheidungen.
- [ARCHITECTURE.md](ARCHITECTURE.md): Datenmodell, Speicherung, Offline und spätere Cloud-Architektur.
- [TESTING.md](TESTING.md): ausgeführte Tests, offene Hardwaretests und reproduzierbare Abnahme.
- [LICENSES.md](LICENSES.md): eigene Assets und Drittanbieter.
- [CHANGELOG.md](CHANGELOG.md): nachvollziehbare Änderungen.

## Bekannte Einschränkungen und nächster Ausbau

Dies ist eine benutzbare erste Version mit begrenzter Testabdeckung, kein klinisch validiertes Coachingprodukt. iPhone-Hardware-/Safari-Abnahme, Speicherdruck, VoiceOver und reale Poseerkennung müssen noch gesondert geprüft werden. Regeln ersetzen keine qualifizierte Trainingsanleitung. Freitext wird nicht medizinisch interpretiert: Schmerzen zusätzlich explizit markieren. App empfiehlt weder zusätzliche Einheiten noch pauschal mehr Volumen. Andere Sportarten sind Kontext, werden noch nicht vollständig erfasst.

Weitere Schritte: echte iPhone-Abnahme, bessere Übungsanleitungen nach fachlichem Review, feinere Video-Benchmarks, größere Datenbestände über getrennte IndexedDB-Stores, optional verschlüsselte Synchronisation. Keine Account-/Login-Attrappen in dieser Version.
