# 4REPS 1.26.0 · Einfacher trainieren

Deutschsprachige Workout-PWA für iPhone, Android und Desktop. Trainingsdaten bleiben standardmäßig lokal; kein Account nötig.

## Neu

- Fortschritt aufgeräumt: Suche und Sortierung direkt sichtbar, zusätzliche Filter aufklappbar und gemeinsam rücksetzbar.
- Leistungsdiagramme mit Achsenabstand sowie klar benannten Einzelwerten und gleichen Werten. Keine doppelte Änderungsanzeige und keine unpassenden 1RM-Karten.
- Neue Pläne aus Vorlagen oder dem letzten Training erst beim abschließenden Speichern anlegen.
- Körpergewicht mit aufklappbarer Notiz, präzisem Datenerhalt und zehn Sekunden Rückgängig nach Speichern oder Löschen.

Die gespeicherte Pause, vier Layouts, Trainingsunterbrechung und bisherigen Plan-/Verlauffunktionen bleiben erhalten. [Neue Bedienung](FORTSCHRITT-BEARBEITEN.md) · [Pläne & Verlauf](PLAENE-UND-VERLAUF.md) · [Layout](LAYOUT.md).

## Update

Für deinen bestehenden ZIP-Workflow nur die passende **Forma-GitHub-Pages.zip** ersetzen, ohne Namenszusatz. Pro Website-Adresse eine Ausgabe verwenden. **Forma-Quellcode.zip** enthält den bearbeitbaren Quellcode. Die Dateien wurden hier nicht veröffentlicht.

Nach erfolgreichem Deployment in der App unter **Mehr** nach Updates suchen. Erwartete Version: **1.26.0**. Bei derselben Adresse und demselben Browser-/PWA-Speicher bleiben die Daten erhalten. Website-Daten nicht löschen. [Update-Anleitung](UPDATE-IPHONE.md) · [Erstveröffentlichung](START-HIER.md) · [Plattformen](PLATTFORMEN.md).

## Daten und Grenzen

Änderungen liegen lokal in IndexedDB. JSON-Backups enthalten Training und Einstellungen. Ein eigenes Hintergrundfoto bleibt separat auf diesem Gerät; es gehört nicht zum JSON-Backup oder zur Cloud. [Optionale Cloud-Sicherung](CLOUD-SYNC.md).

Der Coach verwendet dokumentierte Regeln, keine laufende KI-Abfrage. Ein Lastsprung-Hinweis prüft die Eingabe und bestimmt kein sicheres Trainingsgewicht. Die Planreihenfolge ist keine Erholungsempfehlung. [Coach-Regeln](COACHING_RULES.md) · [Quellen](EVIDENCE.md) · [Statistikmethode](PROGRESS_METHOD.md).

Die experimentelle Videoanalyse arbeitet lokal. Das Modell wird bei Bedarf geladen; Originalvideos bleiben auf deinem Gerät. Kameraperspektive und Zählung prüfen; keine vollständige Technikbewertung. [Videoanalyse](VIDEO_ANALYSIS.md) · [Benchmarks](VIDEO_BENCHMARK.md).

Ein Pausenalarm bei gesperrtem Handy ist nicht garantiert. Bei Rückkehr kann eine verpasste Meldung angezeigt werden. Bildschirm-Wachhaltung ist optional und vom Gerät abhängig.

## Entwicklung

Node.js ab 22.13.0 und npm. Abhängigkeiten sind im package-lock.json festgehalten.

```sh
npm ci
npm run dev
```

```sh
npm run typecheck
npm test
node scripts/test.mjs --android
npm run build
npm run test:pwa
npm run build:android
npm run test:pwa:android
python3 scripts/package-release.py
```

Die iPhone-Website liegt in dist/, Android in dist-android/. Die Quellcode-index.html ist der Vite-Einstieg. [Architektur](ARCHITECTURE.md) · [Lizenzen](LICENSES.md) · [Änderungen](CHANGELOG.md).

Automatisierte Ergebnisse: [TESTING.md](TESTING.md), RELEASE_VALIDATION.json. Kein interaktiver Browser- oder realer Handytest dieser Version. Gerätetests bleiben insbesondere für Tastatur, Scrollen, Touch, Offline-Lebenszyklus und Videoerkennung offen.
