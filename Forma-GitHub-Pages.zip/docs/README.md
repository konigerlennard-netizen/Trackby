# Forma · Workout & Coach · Standalone 1.3.2

Eine deutschsprachige, local-first Workout-PWA für iPhone und Desktop. Schnelle Satzeingabe, vorherige Leistungen, eigene Trainingspläne und nachvollziehbare Coachingregeln. Ohne Account, Werbung oder Tracking. Kein Körpervergleich und keine Kalorienziele.

**Fertige Website veröffentlichen:** [START-HIER.md](START-HIER.md). Kein ChatGPT-Sites-Account, API-Schlüssel oder Backend erforderlich. Der Produktionsordner enthält alle App-Dateien; nur die optionale automatische Videoanalyse lädt ihr Modell bei Bedarf online.

**Trackby ist bereits online?** Für den vorhandenen ZIP-Workflow genügt der Austausch einer Datei: [UPDATE-IPHONE.md](UPDATE-IPHONE.md). Kein neues Repository und kein zweites Paket erforderlich.

## Oberfläche

![Forma – mobiler Fortschritt](docs/progress-mobile.jpg)
![Forma – Fortschrittsdashboard](docs/progress-desktop.jpg)

Screenshots zeigen die tatsächliche Oberfläche; ggf. sichtbare Beispieltrainings sind ausdrücklich Demo-Daten.

## Funktionen

- Freie Workouts und editierbare Templates; Wochenplan, Sortierung und Supersatz-Gruppen.
- Eigenes Gewicht und eigene Wiederholungen für jeden Satz, auch schon im Trainingsplan. Leere Planfelder übernehmen beim Start die letzte Leistung; feste Vorgaben haben Vorrang. Satzdetails im Workout öffnen zusätzliche große Eingabefelder.
- 300 Basisübungen mit deutschem/englischem Namen, Muskeln, Equipment, Bewegungsmuster, Suche, Filtern, Favoriten und eigenen Übungen. Unter anderem konventionelles, Sumo-, rumänisches, Stiff-Leg- und Trap-Bar-Kreuzheben, 19 getrennte eGym-Einträge, Reverse Preacher Curls und Überkopf-Trizepsstrecken. Enges/breites Rudern erhält je Gerät getrennte Leistungsverläufe. [Gerätevarianten und Grenzen](EXERCISE_CATALOG.md).
- Optional unter „Mehr → Leistungsvergleich“: veröffentlichte Median-/Perzentilreferenzen aus Kraftdreikampf-Wettkämpfen für geeignete freie Langhantelübungen. Auswahl nach Altersgruppe **oder** Gewichtsklasse, relative Kraft und vorsichtige Einordnung vorhandener Arbeitssätze. Keine erfundenen Maschinenwerte oder Trainingsjahreskorrekturen; fehlende oder widersprüchliche Daten werden angezeigt. Alle Grenzen und Quellen: [COMPARISON_METHOD.md](COMPARISON_METHOD.md).
- Vorherige Sätze direkt sichtbar; kg/lb, Schnellschritte, Wiederholungen, optional RIR/RPE, Satztypen, Notizen, Tempo und ROM.
- Lokale Speicherung nach Änderungen, Wiederaufnahme aktiver Trainings, Pausentimer mit gespeicherter Endzeit.
- Historie öffnen, wiederholen, korrigieren oder als Vorlage speichern.
- Interaktive Diagramme, direkte Sätze pro Muskel, Häufigkeit, Dauer, Lastvolumen, vorsichtige 1RM-Schätzung und persönliche Bestwerte.
- „Mein Fortschritt“ direkt oben auf der Startseite: freiwillige Gewichtserfassung mit interaktivem Diagramm und kompakte Leistungsübersicht.
- Vollständige Fortschrittsansicht mit Zeitraumwahl (1 Tag bis Gesamt, auch eigene Grenzen), Suche, Favoriten, Sortierung und Filtern nach Muskel, Gerät und Plan.
- Übungsdetails mit antippbaren Trainingspunkten, wählbaren Kennzahlen, Historie und PRs. Prozentwerte beruhen auf vergleichbaren Arbeitssätzen, keine erfundene Präzision bei fehlenden Daten.
- Coach mit transparenten Regeln, Gründen, Quellen und Datengrundlage; erkennt mögliche Stagnation und berücksichtigt Beschwerden/Tagesform.
- Eigene schematische Muskelgrafiken; Dark/Light Mode und reduzierte Bewegung.
- JSON-Backup mit validiertem Import und Rücknahme des letzten Imports; separater Demo-Modus.
- PWA-Manifest, Icons, Service Worker, Offline-App-Shell und lokale Regeln.
- Experimentelle lokale Videoanalyse und manuelle Wiederholungsmarkierung. Details und Grenzen weiter unten.

## Sofort auf dem iPhone verwenden

1. Den bereitgestellten öffentlichen HTTPS-Link in **Safari** öffnen.
2. **Teilen → Zum Home-Bildschirm → Hinzufügen** auswählen.
3. Forma über das neue Icon starten, zunächst mit Internet.
4. Unter **Mehr** warten, bis „Offline-Dateien sind für diese Version bereit“ erscheint.
5. Eigenen Plan erstellen oder Beispielplan anpassen und trainieren.
6. Unter **Mehr → JSON exportieren** regelmäßig eine Datei in „Dateien“ sichern.

Möglichst vor dem ersten echten Training installieren: Safari und die Home-Bildschirm-App können unterschiedliche Datenspeicher verwenden. Bei einem Wechsel aus Safari erst exportieren, dann in der installierten App importieren. Ein Wechsel der Domain erzeugt ebenfalls einen neuen lokalen Speicher. Private Browserfenster sind kein zuverlässiger dauerhafter Speicherort.

## Entwicklung

Voraussetzung: Node.js 24 LTS (mindestens 22.13) und npm. Ein reproduzierbarer `package-lock.json` liegt bei.

```sh
npm ci
npm run dev
```

```sh
npm run verify
npm run preview
```

`verify` prüft TypeScript, Daten-/Coaching-/Speichertests, den Produktionsbuild und die PWA-Dateien. `build` erzeugt **dist/** mit der vollständigen statischen Website. Die Quellcode-`index.html` ist der Vite-Einstieg, nicht die fertige Website. Nicht per `file://` öffnen.

Optionaler Browsertest:

```sh
npx playwright install chromium
npm run test:browser
```

## GitHub Pages

**Ohne eigenen Build:** `Forma-GitHub-Pages.zip` entpacken, den gesamten Inhalt direkt in das Hauptverzeichnis eines öffentlichen GitHub-Repositorys laden. Unter **Settings → Pages → Source → Deploy from a branch → main → / (root)** veröffentlichen. `assets/`, Icons, Manifest und `sw.js` mit hochladen. Anleitung: [START-HIER.md](START-HIER.md).

**Mit Quellcode:** Inhalt von `Forma-Quellcode.zip`, einschließlich `.github/workflows/pages.yml`, ins Repository übernehmen. **Settings → Pages → Source → GitHub Actions** auswählen. Der mitgelieferte Workflow installiert per `npm ci`, führt `npm run verify` aus und veröffentlicht ausschließlich `dist/`. Er läuft bei Änderungen auf `main` oder manuell unter Actions.

Die App verwendet relative Assetpfade und Hash-Navigation: auch `https://BENUTZER.github.io/forma/` funktioniert ohne Server-Rewrites. IndexedDB- und Cache-Namen sind zusätzlich nach App-Verzeichnis getrennt. Keine Sites-Server, Auth-Dienste, Datenbankdienste oder geheimen Umgebungsvariablen notwendig. Andere statische HTTPS-Hosts können denselben `dist/`-Ordner ausliefern.

Unter **Settings → Pages** steht nach dem erfolgreichen Deployment die öffentliche HTTPS-Adresse. Auf dem iPhone in Safari öffnen und über **Teilen → Zum Home-Bildschirm** installieren. Die Veröffentlichung bei GitHub erfolgt durch dich; dieser Export legt kein Repository in deinem Konto an.

Vor dem Umzug unter der bisherigen Forma-Adresse **JSON exportieren**. In der neuen installierten App **JSON importieren**. Trainingsdaten liegen auf deinem Gerät und sind nicht Bestandteil dieser Quellcode-/Website-Archive. Backups nicht ins öffentliche Repository laden.

## Datenschutz und Datensicherung

Freiwillige Körpergewichtseinträge bleiben ebenfalls lokal und sind im JSON-Backup enthalten. Version 1.3.2 liest vorhandene Daten und Backups der Formate 1–3; Workouts werden dabei nicht verändert. Neue Backups verwenden Formatversion 3 und enthalten individuelle Satzvorgaben. Vor einem Update eine Sicherung anlegen, anschließend alte App-Tabs schließen und die angebotene Aktualisierung übernehmen.

Trainingsdaten, Check-ins, persönliche Notizen, Pläne und Analysewerte liegen standardmäßig in IndexedDB auf dem Gerät. Keine Analyse-/Werbe-SDKs und keine Datenübertragung an einen Trainingsserver. Der Hostinganbieter erhält technisch übliche Abruf-/Verbindungsinformationen beim Laden der App. Externe wissenschaftliche Links öffnen nur nach Anklicken.

Videos werden als lokale Datei gelesen und nicht hochgeladen. Erst „Modell laden & analysieren“ ruft JS-/WASM-Dateien bei jsDelivr und ein Pose-Modell bei Google ab; diese Anbieter erhalten übliche Verbindungsdaten, aber keine Videobilder. Die Originalaufnahme bleibt außerhalb der Datenbank in deinen Fotos/Dateien. JSON enthält Analyse-Metadaten, keine Videos.

Browserdaten können bei Gerätewechsel, Löschen von Website-Daten oder Speicherdruck verloren gehen. Die App kann dauerhafte Speicherung anfragen, aber nicht garantieren. JSON-Backups sind nicht verschlüsselt und können private Notizen enthalten: bewusst sichern und teilen. Import ersetzt nach Vorschau und Bestätigung den aktuellen Stand; der vorherige Stand bleibt für „Letzten Import rückgängig machen“ erhalten. Kein Cloud-Backup in v1.

## Offline und Timer

Nach erfolgreichem Cacheaufbau funktionieren Tracking, Übungen, Vorlagen, Historie, Statistiken und lokale Coachingregeln ohne Netzwerk. Erster Start und neue App-Version brauchen Internet. Video-Modelldateien sind nicht Teil des Offline-Caches. Eine wartende App-Aktualisierung wird außerhalb eines aktiven Workouts angeboten.

Der Timer läuft anhand der Uhrzeit weiter. iOS kann Webseiten im Hintergrund anhalten: **kein verlässlicher Ton, keine garantierte Vibration und keine Push-Erinnerung bei gesperrtem Bildschirm**. Eine tatsächliche Satzpause wird nur bei markiertem Satzstart oder manueller Eingabe gespeichert; die Zeit zwischen zwei Satzabschlüssen wäre ungenau.

## Videoanalyse: experimentell

MediaPipe Pose Landmarker Lite, Verarbeitung im lokalen Worker, keine Serveranalyse. Geeignete seitliche Aufnahmen können grobe vollständige Bewegungszyklen, 2D-Amplitude und Zyklusdauer liefern; Gelenkpunkte und Zeitreihe werden gezeigt. Vergleiche sind nur bei ähnlicher Kamera, Bewegung und Seite sinnvoll. Automatische Auswertung höchstens 2 Minuten/150 MB, etwa 5 Bilder/s.

Keine zuverlässige Symmetrieanalyse, biomechanische Diagnose, Gelenkbelastungsberechnung oder Verletzungserkennung. Sichtbarkeits-/Bewegungsgrenzen lehnen ungeeignete Aufnahmen ab. Wiederholungen selbst am Video überprüfen. Posequalität auf echten iPhones und repräsentativen Trainingsvideos ist noch nicht validiert. Manueller Zähler ist die Alternative, wenn Modell, Format oder Browser nicht funktionieren.

## Wissenschaft und technische Dokumentation

- [EVIDENCE.md](EVIDENCE.md): gezielte Recherche, Primärquellen, Studiendaten, Widersprüche und Übertragungsgrenzen.
- [COACHING_RULES.md](COACHING_RULES.md): alle Regeln, Reihenfolge und konkrete Heuristiken.
- [PROGRESS_METHOD.md](PROGRESS_METHOD.md): Leistungskennzahlen, Vergleichbarkeit, Körpergewichtsverlauf, Trendregeln und Grenzen.
- [PRODUCT.md](PRODUCT.md): Prioritäten, Konkurrenzanalyse, Bedienflüsse, Designentscheidungen.
- [ARCHITECTURE.md](ARCHITECTURE.md): Datenmodell, Speicherung, Offline und spätere Cloud-Architektur.
- [TESTING.md](TESTING.md): ausgeführte Tests, offene Hardwaretests und reproduzierbare Abnahme.
- [LICENSES.md](LICENSES.md): eigene Assets und Drittanbieter.
- [CHANGELOG.md](CHANGELOG.md): nachvollziehbare Änderungen.

## Bekannte Einschränkungen und nächster Ausbau

Dies ist eine benutzbare erste Version mit begrenzter Testabdeckung, kein klinisch validiertes Coachingprodukt. iPhone-Hardware-/Safari-Abnahme, Speicherdruck, VoiceOver und reale Poseerkennung müssen noch gesondert geprüft werden. Regeln ersetzen keine qualifizierte Trainingsanleitung. Freitext wird nicht medizinisch interpretiert: Schmerzen zusätzlich explizit markieren. App empfiehlt weder zusätzliche Einheiten noch pauschal mehr Volumen. Andere Sportarten sind Kontext, werden noch nicht vollständig erfasst.

Weitere Schritte: echte iPhone-Abnahme, bessere Übungsanleitungen nach fachlichem Review, feinere Video-Benchmarks, größere Datenbestände über getrennte IndexedDB-Stores, optional verschlüsselte Synchronisation. Keine Account-/Login-Attrappen in dieser Version.
