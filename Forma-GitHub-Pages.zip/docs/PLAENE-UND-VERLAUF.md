# Pläne und Verlauf · 4REPS 1.26.0

## Pläne übersichtlich halten

In **Trainingspläne** nach Plan- oder Übungsnamen suchen. Über **… → Pläne verwalten → Reihenfolge ändern** die aktiven Pläne verschieben. Diese Reihenfolge gilt auch auf der Startseite und für die Trainingsrotation; sie ist keine Empfehlung zur Erholung.

Das Menü **…** einer Plankarte enthält Startplan, Kopieren, Exportieren, Rücknahme, Archivieren und Löschen. Archivieren entfernt den Plan aus der aktiven Auswahl und seinen Wochen-/Startplan-Zuordnungen. Übungen, Verlauf und die eigene Workout-Ansicht bleiben erhalten. Im **Archiv** lässt sich der Plan wieder aktivieren; Wochentage anschließend bei Bedarf neu zuordnen.

**Neuer Plan** öffnet nach Vorlagenauswahl, leerem Start oder Übernahme des letzten Trainings zunächst einen Entwurf. Erst **Plan speichern** legt ihn an. Verwerfen erzeugt keinen Plan; ungespeicherte Entwürfe sind nicht für einen Neustart gesichert. [Details](FORTSCHRITT-BEARBEITEN.md).

Beim Bearbeiten zunächst die gewünschte Übung aufklappen. Satzvorgaben sind direkt darin erreichbar, Coach-Ziele und Notizen bleiben eingeklappt. Änderungen gelten erst nach **Plan speichern**. Ein laufendes Workout behält seine bereits geladenen Vorgaben.

Nach einer gespeicherten Änderung erscheint im Planmenü **Letzte Planänderung zurücknehmen**. Genau eine vorherige Fassung wird gespeichert. Nach der Rücknahme lässt sich dieselbe Aktion nutzen, um zur gerade ersetzten Fassung zurückzuwechseln. Die Historie wird dabei nicht geändert. Plankopien bekommen eigene Übungspositionen und behalten die planbezogene Ansicht, aber keine Vorfassung und keinen Archivstatus.

## Einzelnen Plan weitergeben

1. Auf der Plankarte **… → Als Plandatei speichern** wählen.
2. Optional **Notizen und eigene Hinweise mitgeben** aktivieren.
3. **Plandatei speichern** antippen. Die JSON-Datei kannst du anschließend selbst weitergeben.

Die Datei enthält nur diesen Plan, Satzvorgaben, benötigte eigene Übungsdefinitionen und eine gegebenenfalls gespeicherte planbezogene Workout-Ansicht. Ohne den Schalter bleiben Plan-/Übungsnotizen sowie eigene Ausführungstexte, Tipps und Fehlerhinweise leer. Namen und Geräteangaben sind Teil des Plans. Trainingsverlauf, persönliche Übungsnotizen, Videos und globale Einstellungen werden nicht exportiert.

Zum Einlesen **Trainingspläne → … oben → Plan importieren** wählen. Nach der Dateiauswahl zeigt die App Name und Übungen zur Vorschau. **Plan hinzufügen** legt immer einen neuen Plan an. Bestehende Pläne und Trainings werden nicht ersetzt. Deine gespeicherte globale Pause gilt auch für den importierten Plan.

Identische eigene Übungsdefinitionen mit derselben Kennung werden wiederverwendet. Widersprechen sich Definitionen, erhält die importierte Übung eine neue Kennung. Gleiche Namen werden unterscheidbar benannt; unterschiedliche Übungen und ihre Leistungen werden nicht stillschweigend zusammengeführt. Dateien über 2 MB, ungültige Vorgaben und unbekannte Übungen werden abgewiesen. Ein vollständiges JSON-Backup gehört weiterhin in den Backup-Bereich der Einstellungen.

## Abgeschlossene Workouts bearbeiten

Unter **Verlauf → Workout öffnen → Workout bearbeiten** lassen sich Name, Datum, Notizen, Übungen, Reihenfolge und Sätze korrigieren. Die Übungsbereiche sind aufklappbar. Gewicht und Wiederholungen stehen zusammen mit **Erfasst** in einer Zeile. Satztyp, RIR/RPE, gemessene Pause, Tempo, Bewegungsumfang und Notiz stehen unter **Satzdetails**.

Neu ergänzte Sätze sind zunächst nicht erfasst. Werte eintragen und **Erfasst** erst aktivieren, wenn du den Satz tatsächlich absolviert hast. Manuell nachgetragene Abschlüsse bekommen den Endzeitpunkt des Workouts; eine tatsächliche Start-/Ausführungsdauer wird nicht erfunden. RIR und RPE sind Alternativen.

Eine Datumsänderung verschiebt Start, Ende und vorhandene Satzzeitpunkte gemeinsam. Trainingsdauer, gemessene Satzpausen und ausgeschlossene Unterbrechungen bleiben erhalten. Ein verschobenes Workout darf nicht in der Zukunft enden; eine am gewählten Datum durch die Zeitumstellung nicht existierende Startuhrzeit wird abgewiesen.

Nach **Änderungen speichern** erscheint acht Sekunden lang **Rückgängig**. Beim Löschen gibt es nach der Bestätigung zehn Sekunden lang dieselbe Aktion. Eine Rücknahme überschreibt keine späteren Änderungen und erzeugt keine doppelten Workouts. Nach Ablauf bleiben die vorhandenen lokalen Sicherungsstände und deine exportierten Backups als separate Wiederherstellungswege.

Korrekturen wirken sich auf Statistiken, Bestwerte und darauf aufbauende Coach-Auswertungen aus. Ein geändertes Workout bleibt dieselbe Einheit. Ein anderes gleichzeitig laufendes Training und sein Timer werden nicht verändert.

## Eigene Übungen direkt auswählen

In der Übungsauswahl für Workout, Plan und Verlauf gibt es **Eigene** und **Eigene Übung anlegen**. Dein Suchtext wird als Namensvorschlag übernommen. Nach dem Speichern wird die Übung direkt ausgewählt. Schlägt das Hinzufügen fehl, bleibt die neue Übungsdefinition für einen erneuten Versuch gespeichert.

**Zuletzt** sortiert nach tatsächlicher letzter Verwendung. Zunächst werden fünf Treffer angezeigt; weitere folgen in Schritten von zwanzig. Suche und Filter beziehen sich immer auf die vollständige Bibliothek.

## Speicherung

Die Änderungen sind in lokalen Daten, vollständigen JSON-Backups und im vorhandenen Cloud-Abgleich enthalten. Archivstatus und eine Vorfassung sind optionale Planfelder; Datenbank- und Backupversion bleiben unverändert. Ein separater lokaler Metadatensatz schützt sie vor älteren offenen Tabs. Hat ein älterer Tab den Planinhalt geändert, wird eine nicht mehr passende Vorfassung nicht wieder eingesetzt. Bei einem ausdrücklichen Gesamtimport oder Reset wird entfernte Information nicht aus diesem Metadatensatz zurückgeholt.

Kein interaktiver Browser- oder echter Handytest dieser Version. Die automatisierten Ergebnisse stehen in TESTING.md und RELEASE_VALIDATION.json.
