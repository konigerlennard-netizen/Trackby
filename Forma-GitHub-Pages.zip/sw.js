// Generated with content hashes. Cache and database namespaces are app-specific.
const PREFIX='forma:'+encodeURIComponent(new URL(self.registration.scope).pathname)+':';
const CACHE=PREFIX+'891209b1c7b5';
const FILES=["apple-touch-icon-4reps-171.png","apple-touch-icon-4reps-185.png","apple-touch-icon-4reps-186.png","apple-touch-icon-4reps-187.png","apple-touch-icon-4reps-188.png","apple-touch-icon-4reps-189.png","apple-touch-icon-4reps.png","apple-touch-icon.png","assets/ChangeValue-BTDHDr4O.js","assets/CloudBridge-B3TjA5Jn.js","assets/CloudSettings-CzGyfBj6.js","assets/ExercisePicker-HXzQlcl-.js","assets/Exercises-BtR9dJBk.js","assets/History-Cq4jvYDT.js","assets/LayoutEditor-BjUZKIzC.js","assets/LineChart-lY3_vbAI.js","assets/MiniWeightChart-0NG89L1v.js","assets/Plans-PSxn4zHF.js","assets/Progress-CfpB4mwn.js","assets/ProgressHome-ByWbKftd.js","assets/Settings-Beyu357O.js","assets/Stats-UC_ULOfh.js","assets/StrengthRow-h2DKwTVk.js","assets/Video-93QKHirc.js","assets/WeightChart-Cdf1LXDv.js","assets/Workout-BJEpWD0U.js","assets/arrow-left-DQuVrviG.js","assets/arrow-up-m8C_GAnE.js","assets/background-image-BsbB_5A_.js","assets/circle-check-Bjr-EFmd.js","assets/cloud-DIndrCyU.js","assets/copy-BffL-02C.js","assets/dist-uBKottsp.js","assets/exercise-search-BPrEquUG.js","assets/history-tools-BhPyvJaK.js","assets/index-DMly5gjQ.js","assets/index-UUrKwNsf.css","assets/pencil-uh2EW7_J.js","assets/pose-runtime-vWpZRptn.js","assets/pose.worker-DY_w1buG.js","assets/refresh-cw-Cg0XkoXN.js","assets/star-CmRPvayK.js","assets/trash-DNoyLJ-9.js","assets/trophy-CgeH3PSU.js","assets/upload-BldZna32.js","assets/video-pose-Dj8UpxMy.js","assets/vision_bundle-CKHlh6Iq.js","cloud-config.json","docs/ARCHITECTURE.md","docs/AUDIT.md","docs/CHANGELOG.md","docs/CLOUD-SYNC.md","docs/COACHING_RULES.md","docs/COMPARISON_METHOD.md","docs/DESIGN.md","docs/EINFACH-TRAINIEREN.md","docs/EVIDENCE.md","docs/EXERCISE_CATALOG.md","docs/LAYOUT.md","docs/LICENSES.md","docs/PLATTFORMEN.md","docs/PRODUCT.md","docs/PROGRESS_METHOD.md","docs/README.md","docs/SCHNELL-TRACKEN.md","docs/START-HIER.md","docs/TESTING.md","docs/THIRD_PARTY_NOTICES.txt","docs/TIMER-SPEICHERN.md","docs/TRAININGSABLAUF.md","docs/UPDATE-IPHONE.md","docs/VIDEO_ANALYSIS.md","docs/VIDEO_BENCHMARK.md","docs/docs/desktop.jpg","docs/docs/exercise-search.png","docs/docs/mobile.jpg","docs/docs/progress-desktop.jpg","docs/docs/progress-mobile.jpg","docs/docs/today-desktop.png","docs/docs/today-mobile.png","docs/supabase/setup.sql","favicon-4reps-171.png","favicon-4reps-171.svg","favicon-4reps-185-64.png","favicon-4reps-185.png","favicon-4reps-186-64.png","favicon-4reps-186.png","favicon-4reps-187-64.png","favicon-4reps-187.png","favicon-4reps-188-64.png","favicon-4reps-188.png","favicon-4reps-189-64.png","favicon-4reps-189.png","favicon.svg","icon-192.png","icon-4reps-171-192.png","icon-4reps-171-512.png","icon-4reps-171-maskable.png","icon-4reps-185-192.png","icon-4reps-185-512.png","icon-4reps-185-maskable.png","icon-4reps-186-192.png","icon-4reps-186-512.png","icon-4reps-186-maskable.png","icon-4reps-187-192.png","icon-4reps-187-512.png","icon-4reps-187-maskable.png","icon-4reps-188-192.png","icon-4reps-188-512.png","icon-4reps-188-maskable.png","icon-4reps-189-192.png","icon-4reps-189-512.png","icon-4reps-189-maskable.png","icon-4reps-192.png","icon-4reps-512.png","icon-4reps-maskable.png","icon-4reps.svg","icon-512.png","icon-maskable.png","index.html","manifest.webmanifest"];
self.addEventListener('install',event=>event.waitUntil(
 caches.open(CACHE).then(cache=>cache.addAll(FILES.map(f=>new Request(new URL(f,self.registration.scope).href,{cache:'reload'}))))
));
self.addEventListener('activate',event=>event.waitUntil(
 // Preserve one previous build so an already-open tab can still load its chunks.
 caches.keys().then(keys=>{const old=keys.filter(k=>k.startsWith(PREFIX)&&k!==CACHE);return Promise.all(old.slice(0,-1).map(k=>caches.delete(k)))})
 .then(()=>self.clients.claim())
));
self.addEventListener('message',event=>{if(event.data?.type==='SKIP_WAITING')self.skipWaiting()});
self.addEventListener('fetch',event=>{
 const url=new URL(event.request.url),scope=new URL(self.registration.scope);
 if(event.request.method!=='GET'||url.origin!==scope.origin||!url.pathname.startsWith(scope.pathname))return;
 // The independent rescue page must stay reachable even with a broken app cache.
 if(url.pathname===new URL('repair.html',scope).pathname)return;
 const appPage=event.request.mode==='navigate'&&(url.pathname===scope.pathname||url.pathname===new URL('index.html',scope).pathname);
 const key=appPage?new URL('index.html',scope).href:event.request;
 event.respondWith((async()=>{
  try{
   const cache=await caches.open(CACHE),hit=await cache.match(key);
   if(hit)return hit;
   if((url.pathname.startsWith(new URL('assets/',scope).pathname)||url.pathname.startsWith(new URL('pose/',scope).pathname))){
    for(const name of (await caches.keys()).filter(k=>k.startsWith(PREFIX)&&k!==CACHE).reverse()){
     const old=await (await caches.open(name)).match(event.request);if(old)return old;
    }
   }
  }catch{/* Cache storage can fail independently of the network. */}
  const response=await fetch(event.request);
  // Optional, immutable model assets are cached only on use, never during installation.
  if(url.pathname.startsWith(new URL('pose/',scope).pathname)&&response.ok&&response.status===200){
   try{await (await caches.open(CACHE)).put(event.request,response.clone())}catch{/* An unavailable cache must not break online analysis. */}
  }
  return response;
 })());
});
