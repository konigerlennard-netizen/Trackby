// Generated with content hashes. Cache and database namespaces are app-specific.
const PREFIX='forma:'+encodeURIComponent(new URL(self.registration.scope).pathname)+':';
const CACHE=PREFIX+'cf2d0fea3b15';
const FILES=["apple-touch-icon.png","assets/CloudBridge-BqX8jM6q.js","assets/CloudSettings-2a7-pv9i.js","assets/Progress-DK2v0fj9.js","assets/Settings-4yt1-LE6.js","assets/Stats-DjBZ3QVp.js","assets/Video-D4y7jrpF.js","assets/charts-BUSUXc6d.js","assets/cloud-CTEd46Ns.js","assets/dist-b2BhzSK1.js","assets/download-Dh7uC7-u.js","assets/index-BlS-6GEe.js","assets/index-DEihQpVc.css","assets/pose.worker-BsSaYDOv.js","assets/rolldown-runtime-S-ySWqyJ.js","assets/upload-Cd73_yvl.js","cloud-config.json","docs/ARCHITECTURE.md","docs/AUDIT.md","docs/CHANGELOG.md","docs/CLOUD-SYNC.md","docs/COACHING_RULES.md","docs/COMPARISON_METHOD.md","docs/DESIGN.md","docs/EVIDENCE.md","docs/EXERCISE_CATALOG.md","docs/LICENSES.md","docs/PRODUCT.md","docs/PROGRESS_METHOD.md","docs/README.md","docs/START-HIER.md","docs/TESTING.md","docs/THIRD_PARTY_NOTICES.txt","docs/UPDATE-IPHONE.md","docs/docs/desktop.jpg","docs/docs/exercise-search.png","docs/docs/mobile.jpg","docs/docs/progress-desktop.jpg","docs/docs/progress-mobile.jpg","docs/docs/today-desktop.png","docs/docs/today-mobile.png","docs/supabase/setup.sql","docs/supabase-setup.sql","favicon.svg","icon-192.png","icon-512.png","icon-maskable.png","index.html","manifest.webmanifest"];
self.addEventListener('install',event=>event.waitUntil(
 caches.open(CACHE).then(cache=>cache.addAll(FILES.map(f=>new URL(f,self.registration.scope).href)))
));
self.addEventListener('activate',event=>event.waitUntil(
 caches.keys().then(keys=>Promise.all(keys.filter(k=>k.startsWith(PREFIX)&&k!==CACHE).map(k=>caches.delete(k))))
 .then(()=>self.clients.claim())
));
self.addEventListener('message',event=>{if(event.data?.type==='SKIP_WAITING')self.skipWaiting()});
self.addEventListener('fetch',event=>{
 const url=new URL(event.request.url),scope=new URL(self.registration.scope);
 if(event.request.method!=='GET'||url.origin!==scope.origin||!url.pathname.startsWith(scope.pathname))return;
 const appPage=event.request.mode==='navigate'&&(url.pathname===scope.pathname||url.pathname===new URL('index.html',scope).pathname);
 const key=appPage?new URL('index.html',scope).href:event.request;
 event.respondWith(caches.open(CACHE).then(async cache=>{
  const hit=await cache.match(key);return hit??fetch(event.request);
 }));
});
