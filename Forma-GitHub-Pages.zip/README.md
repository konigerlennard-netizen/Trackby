# Forma – fertige GitHub-Pages-Website

Dies ist die gebaute, eigenständige Website (1.3.1).

1. Den gesamten Inhalt dieses Ordners direkt ins Hauptverzeichnis eines öffentlichen GitHub-Repositorys hochladen.
2. Settings → Pages → Deploy from a branch → main → / (root) → Save.
3. Den Link unter Visit site auf dem iPhone in Safari öffnen: Teilen → Zum Home-Bildschirm.
4. Vorher in der alten Forma-App JSON exportieren, danach in der neuen App JSON importieren. Persönliche Backups nicht öffentlich hochladen.

Die vollständige Anleitung steht in [START-HIER.md](START-HIER.md), die App-Dokumentation in [docs/README.md](docs/README.md).

index.html, assets/, sw.js, Manifest und Icons gehören zusammen. Ein Build oder ChatGPT-Sites-Konto ist nicht erforderlich.

Trainingsdaten werden lokal in IndexedDB gespeichert. Die optionale automatische Videoanalyse lädt ihr Modell online; dein Video bleibt auf dem Gerät.

Den bearbeitbaren Quellcode enthält das separate Forma-Quellcode.zip. Dieser Ordner enthält keine persönlichen Trainingsdaten.
