# Forma 1.5.0 – fertige Website

Für dein bereits veröffentliches Trackby: Ersetze im Repository die bisherige
Datei durch genau diese Forma-GitHub-Pages.zip. Der ZIP-Name muss gleich bleiben,
ohne (2) oder ähnliche Zusätze. Dein vorhandener Entpack-/Pages-Workflow bleibt.
Eine einzige ZIP genügt. Danach den grünen Lauf abwarten und in Forma unter Mehr
nach Updates suchen. Die Versionsanzeige muss 1.5.0 lauten.

Bei gleicher Adresse/PWA bleiben die vorhandenen IndexedDB-Daten erhalten.
Website-Daten nicht löschen. Keine JSON-Backups öffentlich zu GitHub hochladen.

Neue Cloud-Sicherung: noch nicht verbunden. Unter Mehr → Cloud einrichten gibt
es die einmalige Supabase-Anleitung. Vorher speichert Forma wie bisher lokal.

Für eine Erstveröffentlichung ohne ZIP-Workflow: ZIP entpacken, alle Inhalte
inklusive assets/ und docs/ hochladen, Settings → Pages → Deploy from a branch
→ main → / (root). index.html gehört direkt ins Hauptverzeichnis.

Anleitungen: docs/UPDATE-IPHONE.md, docs/START-HIER.md, docs/CLOUD-SYNC.md.
Der gesonderte Quellcode ist nur für weitere Entwicklung nötig.
