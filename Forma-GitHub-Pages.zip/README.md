# 4REPS 1.19.0 – fertige Website

Dies ist die iPhone-Ausgabe. Android liegt als eigenes Paket vor. Nur eine Ausgabe
pro Website-Adresse hochladen. Details: docs/PLATTFORMEN.md.

Für dein bereits veröffentliches Trackby: Ersetze im Repository die bisherige
Datei durch genau diese Forma-GitHub-Pages.zip. Der ZIP-Name muss gleich bleiben,
ohne (2) oder ähnliche Zusätze. Dein vorhandener Entpack-/Pages-Workflow bleibt.
Eine einzige ZIP genügt. Danach den grünen Lauf abwarten und in 4REPS unter Mehr
nach Updates suchen. Die Versionsanzeige muss 1.19.0 lauten.

Falls die alte App weiß bleibt: nach Veröffentlichung repair.html unter derselben
App-Adresse öffnen und App-Dateien erneuern. Dabei wird keine Datenbank gelöscht.

Bei gleicher Adresse/PWA bleiben die vorhandenen IndexedDB-Daten erhalten.
Website-Daten nicht löschen. Keine JSON-Backups öffentlich zu GitHub hochladen.

Eine bestehende Cloud-Verbindung bleibt erhalten. Falls noch nicht eingerichtet,
speichert 4REPS wie bisher lokal. Die freiwillige Anleitung steht in CLOUD-SYNC.md.

Der neue Name ändert weder die App-Adresse noch deine gespeicherten Trainingsdaten.
Der gewählte Fotohintergrund bleibt nur auf diesem Gerät; er ist nicht im JSON-Backup
oder in der Cloud enthalten. Auf einem neuen Gerät bitte erneut auswählen.

Für eine Erstveröffentlichung ohne ZIP-Workflow: ZIP entpacken, alle Inhalte
inklusive assets/ und docs/ hochladen, Settings → Pages → Deploy from a branch
→ main → / (root). index.html gehört direkt ins Hauptverzeichnis.

Anleitungen: docs/UPDATE-IPHONE.md, docs/START-HIER.md, docs/CLOUD-SYNC.md.
Der gesonderte Quellcode ist nur für weitere Entwicklung nötig.
